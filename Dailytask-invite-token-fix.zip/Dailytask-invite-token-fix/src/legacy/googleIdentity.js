// googleIdentity.js — 2_4 Identity Simplification: Google-only helper module.
// সম্পূর্ণ নতুন, additive ফাইল — কোনো existing file/flow এখনো এই ফাইল import
// করে না, তাই বর্তমান app আচরণে কোনো পরিবর্তন নেই। Wiring হবে পরের
// sub-phase-গুলোতে(Sign Up §২.১, Google Sign-in §২.২, Invite-Link §৫.২,
// Profile Dropdown §৯.৪) — এখানে শুধু ভিত্তি(schema/helper) তৈরি হলো।
// Firestore Rules(firestore.rules) ইতিমধ্যে এই schema সাপোর্ট করে — এই
// module সেই একই shape/convention অনুসরণ করে(§৩ Data Schema, §১০.২ Email
// Normalization)।
import { dbModular as db, authModular as auth } from "./firebaseConfig.js";
import { doc, getDoc, setDoc, updateDoc, deleteDoc, writeBatch, deleteField } from "firebase/firestore";
import { signInWithPopup, GoogleAuthProvider } from "firebase/auth";
import { generateSecureCode } from "./appHelpers.js";

// §১০.২ — চূড়ান্ত সংজ্ঞা: শুধু trim+lowercase, dot/plus-stripping না
// (provider-specific জটিলতা এড়াতে owner-approved সিদ্ধান্ত)।
function normalizeEmail(email) {
  return (email || "").trim().toLowerCase();
}

// users/{googleUid} → { familyId, memberId }(§৩ schema)। Rules-এ শুধু
// নিজের uid নিজে read/write করতে পারে — তাই caller সবসময় নিজের
// auth.currentUser.uid-ই পাঠাবে(অন্য uid দিয়ে call করলে permission-denied)।
async function writeUserMapping(googleUid, familyId, memberId) {
  // §fix(১১ সেপ্টেম্বর ২০২৬) — `users/{uid}` collection পুরনো ফিচারেও
  // ব্যবহৃত(familyIdentity.js: saveUserFamilyCode(), schema
  // {familyCode, updatedAt})। আগে এখানে plain .set() পুরনো doc সম্পূর্ণ
  // overwrite করে ফেলত(অথবা উল্টো — পুরনো doc-এ familyId না থাকায়
  // loadUserMapping() fast-path মিস করত)। merge:true দিয়ে দুই schema
  // নিরাপদে সহাবস্থান করবে, কোনো ডেটা হারাবে না।
  await setDoc(doc(db, "users", googleUid), { familyId, memberId }, { merge: true });
}

// --- Startup-race retry(নতুন, ১৩ সেপ্টেম্বর ২০২৬, owner-reported
// ইনসিডেন্ট root-cause fix — কনসোল-লগ দিয়ে নিশ্চিত হওয়া গেছে) ---
// Diagnostic থেকে প্রমাণিত: App Check নিজে ঠিকই ছিল(getToken(true) সফল),
// কিন্তু signInExistingMemberByGoogle()/joinFamilyViaInviteLink()-এর
// একেবারে প্রথম, unguarded Firestore read(loadUserMapping) মাঝেমাঝে
// "permission-denied" দিয়ে ব্যর্থ হচ্ছিল — Google popup সফল হওয়ার ঠিক
// পরপরই App Check token attach হওয়ার একটা ছোট startup-race(পরের request-
// এই আবার সফল হয়)। ছোট delay দিয়ে একবার retry করলেই এই class-এর
// transient সমস্যা resolve হয়ে যায় — শুধু permission-denied/unavailable
// code-এ retry হয়(প্রকৃত authorization-denial retry করলেও একই থাকবে,
// unnecessary delay এড়াতে immediate propagate)।
async function withStartupRaceRetry(fn) {
  try {
    return await fn();
  } catch (err) {
    if (err && (err.code === "permission-denied" || err.code === "unavailable")) {
      await new Promise(r => setTimeout(r, 800));
      return await fn();
    }
    throw err;
  }
}

async function loadUserMapping(googleUid) {
  return withStartupRaceRetry(async () => {
    const snap = await getDoc(doc(db, "users", googleUid));
    return snap.exists() ? snap.data() : null;
  });
}

// familyMemberEmails/{normalizedEmail} → { familyId, memberId }(§৩,
// uniqueness enforce)। Rules-এ create-এর জন্য দুই বৈধ পথ আছে(claimed-self
// token-email match, অথবা admin batch-এ member.email সেট করার সাথে) —
// এই helper শুধু ref/read/delete shape দেয়, caller নিজে সঠিক context
// নিশ্চিত করবে যেন Rules pass করে।
function familyMemberEmailRef(normalizedEmail) {
  return doc(db, "familyMemberEmails", normalizedEmail);
}

async function lookupFamilyByEmail(email) {
  const key = normalizeEmail(email);
  return withStartupRaceRetry(async () => {
    const snap = await getDoc(familyMemberEmailRef(key));
    return snap.exists() ? { normalizedEmail: key, ...snap.data() } : null;
  });
}

// §Self-heal fix(owner-reported, ১৩ সেপ্টেম্বর ২০২৬): admin কর্তৃক
// handleRemoveMember() member doc delete করে, কিন্তু users/{uid} ও
// familyMemberEmails mapping cleanup করে না(Rules-restriction —
// admin অন্যের users/{uid} touch করতে পারে না, এবং claim-মুহূর্তে
// email field মুছে যাওয়ায় admin removed-member-এর email-ই জানে না)।
// ফলে এই দুই mapping stale/dangling থেকে যেতে পারে। এই helper দিয়ে
// signInExistingMemberByGoogle()/joinFamilyViaInviteLink() — দুটোতেই
// bind করার আগে target member সত্যিই এখনো বিদ্যমান কিনা যাচাই করা হয়,
// stale হলে trust না করে normal("no-match"-এর মতো) flow-এ পড়ে যায়।
async function fetchMemberData(familyId, memberId) {
  const snap = await getDoc(doc(db, "families", familyId, "members", memberId));
  return snap.exists() ? snap.data() : null;
}

// §Add-Member fix(১১ সেপ্টেম্বর ২০২৬, real gap): পুরনো createMemberWithKey()
// (Member Password-ভিত্তিক, memberData.js) google-only family-তে
// firestore.rules-এর `private/key` create rule(`!isGoogleOnly(familyId)`
// guard)-এ blocked হয়ে যাওয়ায় Dashboard-এর "Add Member" বাটন ভাঙা ছিল —
// দুটো real family-ই ইতিমধ্যে identityModel:"google-only"। এই ফাংশন 2_4
// §৫.১("Admin-added Proxy Member") pattern অনুসরণ করে: email দিয়ে unclaimed
// member তৈরি(googleUid:null), সদস্য পরে নিজে Google Sign-in করলে
// signInExistingMemberByGoogle()-এর email-match branch দিয়ে auto-claim হবে
// (একই ফাইলের নিচে, existing flow — নতুন কিছু লাগেনি)।
// memberId caller(app.js) আগে থেকে generate করে পাঠায়(optimistic local UI
// update-এর জন্য, পুরনো handleAddMember()-এর প্যাটার্নের সাথে সামঞ্জস্যপূর্ণ)।
// member doc + familyMemberEmails mapping একই batch-এ লেখা হয়(Rules-এর
// admin-create branch getAfter() দিয়ে member.email verify করে বলে batch/
// transaction আবশ্যক, আলাদা sequential write permission-denied দেবে)।
// email আগে থেকে অন্য কোনো(claimed/unclaimed) সদস্যের সাথে যুক্ত থাকলে —
// প্রথমে friendly pre-check(lookupFamilyByEmail), তারপরও race হলে Rules
// নিজেই reject করবে(familyMemberEmails doc already exists → update-branch,
// যা `allow update: if false`)।
async function addProxyMemberByAdmin(familyId, memberId, name, gender, email) {
  const normalizedEmail = normalizeEmail(email);
  if (!normalizedEmail || !normalizedEmail.includes("@")) {
    throw new Error("সঠিক ইমেইল ঠিকানা প্রয়োজন।");
  }
  const existing = await lookupFamilyByEmail(normalizedEmail);
  if (existing) {
    // §Bug-fix(owner-reported #২ — "family ত্যাগ/remove-এর পর একই email
    // পুনরায় ব্যবহারযোগ্য হওয়া উচিত"): আগে stale mapping(target member
    // ইতিমধ্যে remove/delete হয়ে গেছে)-কেও "already registered" ধরে
    // ভুলভাবে ব্লক করত — একই email কখনো reuse করা যেত না। এখন target
    // সত্যিই এখনো বিদ্যমান কিনা self-heal check(অন্য ফাংশনগুলোর একই
    // fetchMemberData() pattern reuse)।
    let existingMemberData;
    try {
      existingMemberData = await fetchMemberData(existing.familyId, existing.memberId);
    } catch (err) {
      throw new Error("যাচাই করতে সমস্যা হয়েছে, আবার চেষ্টা করুন।");
    }
    if (existingMemberData) {
      throw new Error("এই ইমেইল ইতিমধ্যে অন্য একজন সদস্যের সাথে যুক্ত আছে।");
    }
    // Stale(সত্যিই deleted) — same-family ও cross-family উভয় ক্ষেত্রেই
    // পরিষ্কার করে reuse খোলা হবে।
    // §Cross-family fix(১৪ সেপ্টেম্বর ২০২৬, owner-reported): আগে এখানে শুধু
    // same-family(`existing.familyId === familyId`) স্টেল-mapping cleanup
    // অনুমোদিত ছিল — cross-family stale হলে(অন্য family থেকে remove হওয়া
    // সদস্যের email) এই admin-এর permission না থাকায় ব্লক-ই থেকে যেত।
    // firestore.rules-এ orphaned-mapping delete guard যোগ হয়েছে(target
    // member সত্যিই আর বিদ্যমান না থাকলে যেকোনো authenticated user delete
    // করতে পারবে, লাইভ mapping অস্পৃশ্য) — তাই এখন same/cross-family
    // নির্বিশেষে(existingMemberData ইতিমধ্যে null যাচাই হয়ে গেছে উপরে)
    // একই delete-call নিরাপদে কাজ করবে।
    try {
      await deleteFamilyMemberEmail(normalizedEmail);
    } catch (err) {
      throw new Error("পুরনো তথ্য পরিষ্কার করতে সমস্যা হয়েছে, আবার চেষ্টা করুন।");
    }
  }
  const batch = writeBatch(db);
  const memberRef = doc(db, "families", familyId, "members", memberId);
  batch.set(memberRef, {
    name,
    gender: gender || "male",
    role: "member",
    email: normalizedEmail,
    googleUid: null,
    createdAt: Date.now(),
    updatedAt: Date.now()
  });
  batch.set(familyMemberEmailRef(normalizedEmail), { familyId, memberId });
  await batch.commit();
}

// §৫.৩ — family ত্যাগ/remove-এর সময় mapping cleanup। Claimed member-এর
// email field claim-মুহূর্তেই member-doc থেকে delete হয়ে যায়(§৪), তাই
// normalizedEmail caller-কেই আলাদাভাবে জানা/পাস করা লাগবে(reverse-query
// পরের sub-phase-এ familyId+memberId দিয়ে করা হবে, এখানে শুধু delete-primitive)।
async function deleteFamilyMemberEmail(normalizedEmail) {
  await deleteDoc(familyMemberEmailRef(normalizedEmail));
}

// existing isGoogleLinked()(familyIdentity.js)-এর মতোই সহজ accessor, কিন্তু
// circular-dependency এড়াতে এই ফাইল familyIdentity.js import করে না —
// শুধু firebaseConfig.js(leaf module) থেকেই auth নেয়।
function currentGoogleUid() {
  return auth.currentUser ? auth.currentUser.uid : null;
}

function currentGoogleEmail() {
  return auth.currentUser ? (auth.currentUser.email || null) : null;
}

// §২.৪ §২.২ — গুগল দিয়ে সাইন-ইন করুন(শুধু পুরনো সদস্যের জন্য)।
// Precondition(caller, §১০.৩): Google Sign-in(signInWithPopup) আগেই সফল
// হয়ে auth.currentUser এই ফাংশন কলের সময় সেই Google user।
//
// দুই ধাপে চেক(fastest-path আগে):
//   ১) users/{uid} আগে থেকেই থাকলে(returning claimed member) — সরাসরি
//      familyId/memberId পাওয়া যায়, কোনো নতুন write লাগে না।
//   ২) না থাকলে(প্রথমবার claim) — familyMemberEmails/{normalizedEmail}
//      lookup করে admin-added unclaimed member খুঁজে বের করা হয়, তারপর
//      সেই member doc-এ googleUid সেট + email field remove(একই write,
//      firestore.rules-এর নির্দিষ্ট claim-clause অনুযায়ী — email must
//      still match request.auth.token.email, তাই client-side এই চেক
//      করার দরকার নেই, Rules নিজেই server-verified email দিয়ে যাচাই
//      করবে) + users/{uid} mapping তৈরি(পরের বার fast-path কাজ করতে)।
//
// কোনো mapping/lookup না মিললে { matched: false } — caller(UI) তখন
// ২.৫ Screen C-এর "এই মেইল দিয়ে অদ্যাবধি সাইন ইন হয়নি..." বার্তা দেখাবে।
async function signInExistingMemberByGoogle() {
  if (!auth.currentUser) {
    return { matched: false, reason: "not-signed-in" };
  }
  const uid = auth.currentUser.uid;

  // ধাপ ১ — fast path(আগে থেকে claimed)।
  const existingMapping = await loadUserMapping(uid);
  if (existingMapping && existingMapping.familyId && existingMapping.memberId) {
    let staleCheckData;
    try {
      staleCheckData = await fetchMemberData(existingMapping.familyId, existingMapping.memberId);
    } catch (err) {
      return { matched: false, reason: "error", error: err.message };
    }
    if (staleCheckData) {
      return {
        matched: true,
        familyId: existingMapping.familyId,
        memberId: existingMapping.memberId,
        firstClaim: false
      };
    }
    // Stale mapping(admin আগে remove করেছেন) — নিজের(self-owned, Rules-
    // permitted) users/{uid} doc delete করে ধাপ ২-এ fresh চেষ্টা।
    try {
      await deleteDoc(doc(db, "users", uid));
    } catch (err) {
      console.error("[Google Sign-in] stale users mapping cleanup ব্যর্থ(non-fatal):", err.message);
    }
  }

  // ধাপ ২ — প্রথমবার claim(email-match)।
  const email = currentGoogleEmail();
  if (!email) {
    return { matched: false, reason: "no-email" };
  }
  const lookup = await lookupFamilyByEmail(email);
  if (!lookup || !lookup.familyId || !lookup.memberId) {
    return { matched: false, reason: "no-match" };
  }
  let targetMemberData;
  try {
    targetMemberData = await fetchMemberData(lookup.familyId, lookup.memberId);
  } catch (err) {
    return { matched: false, reason: "claim-failed", error: err.message };
  }
  if (!targetMemberData) {
    // Stale familyMemberEmails mapping(admin আগে remove করেছেন) — trust
    // না করে নতুন-ইউজার flow-এ পড়ে যাওয়া(mapping doc নিজে delete করার
    // permission caller-এর নেই বলে শুধু bypass করা হচ্ছে, harmless)।
    return { matched: false, reason: "no-match" };
  }
  const memberRef = doc(db, "families", lookup.familyId, "members", lookup.memberId);
  try {
    // Rules(claim-clause) নিজেই নিশ্চিত করে যে request.auth.token.email
    // resource-এ সংরক্ষিত member.email-এর সাথে মেলে — client এখানে আলাদা
    // pre-check করছে না(server-verified token-ই একমাত্র সত্যতা)।
    await updateDoc(memberRef, {
      googleUid: uid,
      email: deleteField(),
      updatedAt: Date.now()
    });
    await writeUserMapping(uid, lookup.familyId, lookup.memberId);
    return {
      matched: true,
      familyId: lookup.familyId,
      memberId: lookup.memberId,
      firstClaim: true
    };
  } catch (err) {
    console.error("[Google Sign-in] claim ব্যর্থ:", err.message);
    return { matched: false, reason: "claim-failed", error: err.message };
  }
}

// §২.৪ §১০.১/§৫.২ — Invite-Link token generation/rotate/revoke ও join।
// existing generateSecureCode()(appHelpers.js, FAMILY_CODE_CHARS ৩৩-char
// charset, ~৫.০৪ bit/char) reuse — নতুন generator লেখা হয়নি(§১০.১-এর
// নীতি অনুযায়ী)। দৈর্ঘ্য ২৬ বেছে নেওয়া হয়েছে যাতে ২৬×৫.০৪≈১৩১ bit(≥
// ন্যূনতম ১২৮-বিট এনট্রপি) এবং firestore.rules-এর token.size()>=22
// শর্তও(§১০.১) স্বয়ংক্রিয়ভাবে পূরণ হয়।
function generateInviteToken() {
  return generateSecureCode(26);
}

// Admin — নতুন/rotate(পুরনো থাকলেও overwrite, single-active-token মডেল)।
// §Security-fix(৩ নভেম্বর ২০২৬): token আর families/{id} root doc-এ নেই
// (root doc যেকোনো signed-in user পড়তে পারে → Family Code জানলেই token
// পড়ে join সম্ভব ছিল)। এখন families/{id}/inviteLinks/active — শুধু admin
// পড়তে/লিখতে পারে; join-যাচাই Rules নিজে ভেতরে করে।
function inviteLinkRef(familyId) {
  return doc(db, "families", familyId, "inviteLinks", "active");
}

async function rotateInviteLink(familyId) {
  const token = generateInviteToken();
  await setDoc(inviteLinkRef(familyId), { token, createdAt: Date.now(), revoked: false });
  return token;
}

// Admin — বর্তমান token পড়া(non-admin পারবে না, Rules-এ বন্ধ)। ব্যর্থ হলে null।
async function loadActiveInviteToken(familyId) {
  try {
    const snap = await getDoc(inviteLinkRef(familyId));
    return snap.exists() ? snap.data() : null;
  } catch {
    return null;
  }
}

// পুরনো root-field(activeInviteToken) একবার মুছে ফেলা — শুধু admin-এর ডিভাইস
// থেকে, best-effort। পুরনো token ইচ্ছাকৃতভাবে বাতিল(ফাঁসের সম্ভাবনা ছিল);
// admin নতুন লিংক শেয়ার করলে নতুন token তৈরি হবে।
let _legacyInviteCleanupTried = false;
async function removeLegacyInviteToken(familyId) {
  if (_legacyInviteCleanupTried) return;
  _legacyInviteCleanupTried = true;
  try {
    await updateDoc(doc(db, "families", familyId), {
      activeInviteToken: deleteField(),
      updatedAt: Date.now()
    });
  } catch (err) {
    console.error("[Invite-Link] legacy token cleanup ব্যর্থ(non-fatal):", err && err.message);
  }
}

// Admin — revoke। caller বর্তমান activeInviteToken object পাঠাবে(token/
// createdAt অক্ষুণ্ণ রাখতে, শুধু revoked flip)।
async function revokeInviteLink(familyId, activeInviteToken) {
  await setDoc(inviteLinkRef(familyId), {
    token: activeInviteToken.token,
    createdAt: activeInviteToken.createdAt,
    revoked: true
  });
}

// §৫.২ — Invite-Link click করে join(non-admin self-serve)। Precondition:
// Google Sign-in আগেই সফল(caller, §১০.৩)। এখানে token-validity pre-check
// শুধু দ্রুত friendly error দেখানোর জন্য — চূড়ান্ত সত্যতা সবসময়
// firestore.rules-এর নিজস্ব server-side check থেকেই আসে(client bypass
// করলেও Rules reject করবে)।
async function joinFamilyViaInviteLink(familyId, token, name, gender) {
  if (!auth.currentUser) {
    return { aborted: true, reason: "google-signin-required" };
  }
  const uid = auth.currentUser.uid;
  const familyRef = doc(db, "families", familyId);
  let familySnap;
  try {
    familySnap = await getDoc(familyRef);
  } catch (err) {
    return { aborted: true, reason: "error", error: err.message };
  }
  if (!familySnap.exists()) {
    return { aborted: true, reason: "family-not-found" };
  }
  // token-যাচাই এখন শুধু firestore.rules-এ(token আর client পড়তে পারে না);
  // ভুল/revoked token হলে নিচের setDoc permission-denied পাবে → "invalid-token"।

  // §Bug-fix(owner-reported — "১ email = ১ member" invariant, 2_4 §১):
  // আগে এখানে কোনো users/{uid} mapping-check ছিল না বলে একই Google
  // account বারবার(এমনকি একই invite-link repeat-click করেও) নতুন-নতুন
  // duplicate member তৈরি করতে পারত — নিচের self-create branch কখনো
  // familyMemberEmails mapping লিখত না বলে পরের বার lookup কিছুই খুঁজে
  // পেত না। signInExistingMemberByGoogle()-এর fast-path-এর একই
  // loadUserMapping() reuse করে প্রথমেই check করা হচ্ছে।
  const existingMapping = await loadUserMapping(uid);
  if (existingMapping && existingMapping.familyId && existingMapping.memberId) {
    // §Self-heal fix(owner-reported #২): target member সত্যিই এখনো
    // বিদ্যমান কিনা যাচাই — admin আগে remove করে থাকলে stale mapping
    // ভুলভাবে "অন্য family-র সদস্য" বলে block করে দিত।
    let existingMemberData;
    try {
      existingMemberData = await fetchMemberData(existingMapping.familyId, existingMapping.memberId);
    } catch (err) {
      return { aborted: true, reason: "error", error: err.message };
    }
    if (existingMemberData) {
      if (existingMapping.familyId === familyId) {
        // এই family-রই আগে থেকে সদস্য(পুরনো invite-link পুনরায় ব্যবহার) —
        // duplicate না বানিয়ে বিদ্যমান profile-এ সরাসরি সফল ধরা হচ্ছে।
        return { success: true, familyId, memberId: existingMapping.memberId, bound: true, alreadyMember: true };
      }
      // অন্য family-র সদস্য — system-wide ১ email = ১ member নীতিতে ব্লক।
      return { aborted: true, reason: "already-member-elsewhere" };
    }
    try {
      await deleteDoc(doc(db, "users", uid));
    } catch (err) {
      console.error("[Invite-Link] stale users mapping cleanup ব্যর্থ(non-fatal):", err.message);
    }
  }

  // পূর্ব-নিবন্ধিত email(rare edge-case, §৫.২) — নতুন member তৈরি না করে
  // বিদ্যমান(admin-added unclaimed) profile bind।
  const email = currentGoogleEmail();
  if (email) {
    const lookup = await lookupFamilyByEmail(email);
    if (lookup && lookup.familyId === familyId && lookup.memberId) {
      let targetMemberData;
      try {
        targetMemberData = await fetchMemberData(familyId, lookup.memberId);
      } catch (err) {
        return { aborted: true, reason: "error", error: err.message };
      }
      if (targetMemberData) {
        // §Bug-fix(owner-reported #১): email আগে থেকেই claimed(এই বা অন্য
        // কারো account দিয়ে) — আগে এখানে কোনো check ছিল না, তাই হয়
        // silent-mismatch অথবা generic error দেখাত। এখন স্পষ্ট branch।
        if (targetMemberData.googleUid) {
          if (targetMemberData.googleUid === uid) {
            return { success: true, familyId, memberId: lookup.memberId, bound: true, alreadyMember: true };
          }
          return { aborted: true, reason: "email-already-member" };
        }
        const memberRef = doc(familyRef, "members", lookup.memberId);
        try {
          await updateDoc(memberRef, {
            googleUid: uid,
            email: deleteField(),
            updatedAt: Date.now()
          });
          await writeUserMapping(uid, familyId, lookup.memberId);
          return { success: true, familyId, memberId: lookup.memberId, bound: true };
        } catch (err) {
          console.error("[Invite-Link] pre-registered bind ব্যর্থ:", err.message);
          return { aborted: true, reason: "error", error: err.message };
        }
      }
      // stale mapping(admin আগে remove করেছেন) — নিচের self-create
      // path-এ স্বাভাবিকভাবে পড়ে যাবে।
    } else if (lookup && lookup.familyId && lookup.familyId !== familyId) {
      // §Bug-fix: এই email ইতিমধ্যে ভিন্ন family-তে নিবন্ধিত থাকলেই শুধু
      // block — কিন্তু সেই target সত্যিই এখনো বিদ্যমান কিনা যাচাই করে
      // (stale mapping হলে ভুলভাবে block করবে না)। error হলে fail-safe
      // আগের(block) আচরণই বজায় থাকবে।
      let otherMemberData;
      try {
        otherMemberData = await fetchMemberData(lookup.familyId, lookup.memberId);
      } catch {
        otherMemberData = "unknown";
      }
      if (otherMemberData !== null) {
        return { aborted: true, reason: "already-member-elsewhere" };
      }
    }
  }

  // নতুন member — self-create(firestore.rules-এর invite-token clause,
  // role client পাঠাতে পারে শুধু "member", privilege-escalation guard)।
  const memberId = generateSecureCode(16);
  try {
    await setDoc(doc(familyRef, "members", memberId), {
      name: (name || "").trim(),
      gender: gender || null,
      googleUid: uid,
      role: "member",
      inviteTokenAttempt: token,
      createdAt: Date.now(),
      updatedAt: Date.now()
    });
    await writeUserMapping(uid, familyId, memberId);
    // §Bug-fix: familyMemberEmails mapping লেখা হচ্ছে(আগে হতো না) — যাতে
    // ভবিষ্যতে একই email দিয়ে আবার কোনো join চেষ্টা উপরের দুই check-এর
    // যেকোনো একটাতে ধরা পড়ে। isClaimedByGoogle() Rules-check ঠিক-উপরের
    // await-এ committed member.googleUid পড়েই pass করবে(sequential
    // read-after-write, transaction লাগে না)। ব্যর্থ হলেও(non-fatal) মূল
    // join সফলই থাকে — শুধু future-dedup convenience layer মিস হবে।
    if (email) {
      try {
        await setDoc(familyMemberEmailRef(normalizeEmail(email)), { familyId, memberId });
      } catch (err) {
        console.error("[Invite-Link] email-mapping write ব্যর্থ(non-fatal):", err.message);
      }
    }
    return { success: true, familyId, memberId, bound: false };
  } catch (err) {
    console.error("[Invite-Link] join ব্যর্থ:", err.message);
    if (err && err.code === "permission-denied") {
      return { aborted: true, reason: "invalid-token" };
    }
    return { aborted: true, reason: "error", error: err.message };
  }
}

// §৫.৩ — Family ত্যাগ(self-leave, claimed member)। firstAdminUid client-side
// pre-check(UX friendly-message) — চূড়ান্ত protection সবসময় firestore.rules-
// এর member-delete clause-এই enforced। মেম্বার doc delete + সংশ্লিষ্ট
// familyMemberEmails mapping(composite familyId+memberId reverse-query,
// ২.৪ §৩-এ নোট করা index প্রয়োজন) — একই batch-এ(atomic)।
async function leaveFamily(familyId, memberId) {
  if (!auth.currentUser) {
    return { aborted: true, reason: "not-signed-in" };
  }
  const uid = auth.currentUser.uid;
  const familyRef = doc(db, "families", familyId);
  let fam = null;
  try {
    const familySnap = await getDoc(familyRef);
    fam = familySnap.exists() ? familySnap.data() : null;
  } catch (err) {
    return { aborted: true, reason: "error", error: err.message };
  }
  if (fam && fam.firstAdminUid && fam.firstAdminUid === uid) {
    return { aborted: true, reason: "first-admin-must-transfer" };
  }
  try {
    // §Leave-Family fix(১৩ সেপ্টেম্বর ২০২৬, owner-reported "ব্যর্থ হয়েছে"):
    // আগে এখানে familyMemberEmails-এ .where(familyId).where(memberId) query
    // চালানো হতো — কিন্তু Rules-এ এই collection-এর "list" সম্পূর্ণ বন্ধ
    // (email-enumeration প্রতিরোধে, §১০.২ "allow list: if false") — তাই এই
    // query নিজেই সবসময় permission-denied দিত, batch.commit()-এ পৌঁছানোর
    // আগেই leaveFamily() পুরোপুরি ব্যর্থ হতো। Fix: query-এর বদলে নিজের
    // (claimed) Google account email দিয়ে normalizeEmail()-ভিত্তিক doc-id
    // সরাসরি "get"(Rules-এ অনুমোদিত, list শুধু বন্ধ get না) — তারপর
    // familyId/memberId মিলে কিনা cross-verify করে তবেই delete করা হয়(অন্য
    // family/member-এর mapping ভুলবশত মুছে ফেলা থেকে রক্ষা)। Invite-link
    // দিয়ে join করা সদস্যদের(কখনো email-mapping তৈরিই হয়নি) জন্য
    // mapSnap.exists false হবে, স্বাভাবিকভাবে skip — আগের behavior অক্ষুণ্ণ।
    let mappingRef = null;
    try {
      const myEmail = auth.currentUser.email;
      if (myEmail) {
        const emailKey = normalizeEmail(myEmail);
        const mapSnap = await getDoc(doc(db, "familyMemberEmails", emailKey));
        if (mapSnap.exists() && mapSnap.data().familyId === familyId && mapSnap.data().memberId === memberId) {
          mappingRef = mapSnap.ref;
        }
      }
    } catch {}
    const batch = writeBatch(db);
    batch.delete(doc(familyRef, "members", memberId));
    if (mappingRef) {
      batch.delete(mappingRef);
    }
    // §fix(১১ সেপ্টেম্বর ২০২৬, ProfileDropdownGoogle wiring-এর সময় ধরা
    // পড়েছে): আগে users/{uid} mapping এখানে delete হতো না — leave-এর পর
    // এই একই device পরের বার Google sign-in করলে loadUserMapping()
    // fast-path(signInExistingMemberByGoogle()) পুরনো(এখন-deleted)
    // familyId/memberId-ই ফেরত দিত, dead-end/permission-denied তৈরি হতো।
    // এটা নিজের(request.auth.uid==uid) doc, Rules ইতিমধ্যে self-delete
    // অনুমোদিত — কোনো Rules change লাগেনি।
    batch.delete(doc(db, "users", uid));
    await batch.commit();
    return { success: true };
  } catch (err) {
    console.error("[Leave Family] ব্যর্থ:", err.message);
    return { aborted: true, reason: "error", error: err.message };
  }
}

// §৯.৪ "প্রোফাইল এডিট" — claimed member নিজে নাম/জেন্ডার বদলাতে পারবেন
// (firestore.rules: isClaimedByGoogle + affectedKeys hasOnly ['name',
// 'gender','updatedAt'])।
async function editOwnProfile(familyId, memberId, name, gender) {
  if (!auth.currentUser) {
    return { aborted: true, reason: "not-signed-in" };
  }
  try {
    await updateDoc(doc(db, "families", familyId, "members", memberId), {
      name: (name || "").trim(),
      gender: gender || null,
      updatedAt: Date.now()
    });
    return { success: true };
  } catch (err) {
    console.error("[Profile Edit] ব্যর্থ:", err.message);
    return { aborted: true, reason: "error", error: err.message };
  }
}

// §১০.৩ Single-Popup Pattern — shared helper। এই ফাংশন UI button-এর
// onClick-এর সবচেয়ে প্রথম synchronous statement হিসেবে সরাসরি কল হবে
// (কোনো await/.then()-এর ভিতর থেকে না) — existing GoogleAccountModal.jsx-
// এর googleProvider(app.js) প্যাটার্নের সাথে সামঞ্জস্যপূর্ণ, এখানে আলাদা
// module-level instance(কোনো extra config লাগে না, একই default provider)।
const googleSignInProvider = new GoogleAuthProvider();
function triggerGoogleSignInPopup() {
  return signInWithPopup(auth, googleSignInProvider);
}

export {
  normalizeEmail,
  writeUserMapping,
  loadUserMapping,
  familyMemberEmailRef,
  lookupFamilyByEmail,
  addProxyMemberByAdmin,
  deleteFamilyMemberEmail,
  currentGoogleUid,
  currentGoogleEmail,
  signInExistingMemberByGoogle,
  generateInviteToken,
  rotateInviteLink,
  revokeInviteLink,
  loadActiveInviteToken,
  removeLegacyInviteToken,
  joinFamilyViaInviteLink,
  leaveFamily,
  editOwnProfile,
  triggerGoogleSignInPopup
};

