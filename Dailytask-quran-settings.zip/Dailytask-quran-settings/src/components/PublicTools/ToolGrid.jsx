// ToolGrid.jsx — আমল hub ও সহায়িকা shell-এর shared icon-grid section।
// গোল আইকন + নিচে লেবেল (রেফারেন্স-অ্যাপের প্যাটার্ন)। শুধু presentation-layer।
// ১৯ সেপ্টেম্বর ২০২৬ (premium-grid, owner-approved mockup): ঐচ্ছিক `variant` prop যোগ হয়েছে —
//   "default"(বাদ দিলে) = আগের ৪-কলাম আচরণ হুবহু অপরিবর্তিত (সহায়িকার ভিতরের ক্যাটাগরি-গ্রিড এটাই)
//   "compact3" = আমল hub — ৩-কলাম কার্ড-টাইল
//   "hero"     = সহায়িকা front — ২-কলাম বড় কার্ড, আইকন+লেখা মাঝ-বরাবর (center)
// সাথে PageHeader ও VerseCard(দুটোই pure-presentational, কোনো data/Firestore নেই)।
// React global(window.React, globals.js)।

import { ToolIcon } from "./ToolIcons.jsx";

const PRIMARY = "var(--theme-primary, #0E4B43)";
const GOLD = "#C89B3C";
const SERIF = "'Noto Serif Bengali', serif";

// --- default variant(অপরিবর্তিত) ---
function Tile({ icon, label, onClick }) {
  return React.createElement(
    "button",
    { type: "button", onClick, className: "flex flex-col items-center gap-1.5 active:scale-95 transition-transform" },
    React.createElement(
      "div",
      {
        className: "w-11 h-11 rounded-full flex items-center justify-center border border-emerald-900/10",
        style: { background: "var(--theme-soft, #E8F0EE)" },
      },
      React.createElement(ToolIcon, { name: icon, size: 20, color: PRIMARY })
    ),
    React.createElement(
      "span",
      {
        className: "text-xs leading-snug text-center text-slate-700 w-full px-0.5",
        style: { display: "-webkit-box", WebkitLineClamp: 3, WebkitBoxOrient: "vertical", overflow: "hidden" },
      },
      label
    )
  );
}

// --- list variant("সহায়িকা" ক্যাটাগরি-সাব-লিস্ট, owner-request ১৯ সেপ্টেম্বর
// ২০২৬: বাংলা টাইটেল লম্বা/অসম-দৈর্ঘ্যের বলে ৪-কলাম গ্রিডে ভেঙে বিশ্রী দেখাত,
// তাই পুরো-width রো+চেভরন লিস্টে) ---
function ListRow({ icon, label, subtitle, onClick }) {
  return React.createElement(
    "button",
    {
      type: "button",
      onClick,
      className: "w-full flex items-center gap-3 py-3 active:bg-slate-50 transition-colors text-left",
    },
    React.createElement(
      "div",
      {
        className: "w-10 h-10 rounded-full flex items-center justify-center shrink-0",
        style: { background: "var(--theme-soft, #E8F0EE)" },
      },
      React.createElement(ToolIcon, { name: icon, size: 18, color: PRIMARY })
    ),
    React.createElement(
      "div",
      { className: "flex-1 min-w-0" },
      React.createElement("div", { className: "text-sm font-semibold text-slate-800 truncate" }, label),
      subtitle && React.createElement("div", { className: "text-sm text-slate-500 mt-0.5 truncate" }, subtitle)
    ),
    React.createElement(ToolIcon, { name: "chevronRight", size: 15, color: GOLD })
  );
}

// --- premium variants ---
const PREMIUM = {
  compact3: { cols: "grid-cols-3", height: "clamp(92px, 12vh, 108px)", disc: 40, icon: 20, font: 12.5, chevron: false },
  hero: { cols: "grid-cols-2", height: "clamp(70px, 9.5vh, 84px)", disc: 36, icon: 20, font: 13.5, chevron: true },
};

function PremiumTile({ icon, label, onClick, cfg, accent }) {
  // accent(ঐচ্ছিক): নির্দিষ্ট টাইলকে আলাদা রঙ দেয় — {bg, border, disc, ring, icon, text}; না থাকলে আগের থিম-রঙ।
  const ac = accent || null;
  return React.createElement(
    "button",
    {
      type: "button",
      onClick,
      className: "relative flex flex-col items-center justify-center gap-1.5 rounded-2xl border px-1.5 active:scale-95 transition-transform",
      style: {
        height: cfg.height,
        background: ac ? ac.bg : "linear-gradient(160deg, #FFFFFF 0%, #F3F8F6 100%)",
        borderColor: ac ? ac.border : "#E1EBE7",
        boxShadow: "0 1px 2px rgba(14,75,67,0.06), 0 4px 12px rgba(14,75,67,0.05)",
      },
    },
    cfg.chevron &&
      React.createElement(
        "span",
        { className: "absolute top-2 right-2", style: { lineHeight: 0 } },
        React.createElement(ToolIcon, { name: "chevronRight", size: 14, color: GOLD })
      ),
    React.createElement(
      "div",
      {
        className: "rounded-full flex items-center justify-center shrink-0",
        style: {
          width: cfg.disc,
          height: cfg.disc,
          background: ac ? ac.disc : "radial-gradient(circle at 30% 25%, #FFFFFF 0%, var(--theme-tint, #E3EEEA) 100%)",
          boxShadow: ac ? "inset 0 0 0 1px " + ac.ring : "inset 0 0 0 1px var(--theme-line, #D3E3DD)",
        },
      },
      React.createElement(ToolIcon, { name: icon, size: cfg.icon, color: ac ? ac.icon : PRIMARY })
    ),
    React.createElement(
      "span",
      {
        className: "leading-snug text-center w-full",
        style: {
          fontSize: cfg.font,
          color: ac ? ac.text : "#1A2621",
          display: "-webkit-box",
          WebkitLineClamp: 2,
          WebkitBoxOrient: "vertical",
          overflow: "hidden",
        },
      },
      label
    )
  );
}

export function ToolGridSection({ title, icon, items, onSelect, variant }) {
  if (variant === "list") {
    return React.createElement(
      "section",
      { className: "bg-white rounded-2xl shadow-sm border border-slate-200/80 px-4 divide-y divide-slate-100" },
      items.map((item) =>
        React.createElement(ListRow, {
          key: item.key || item.id,
          icon: item.icon,
          label: item.label,
          subtitle: item.subtitle,
          onClick: () => onSelect(item),
        })
      )
    );
  }

  const cfg = PREMIUM[variant];

  if (cfg) {
    const grid = React.createElement(
      "div",
      { className: "grid gap-2 " + cfg.cols },
      items.map((item) =>
        React.createElement(PremiumTile, {
          key: item.key || item.id,
          icon: item.icon,
          label: item.label,
          cfg,
          accent: item.accent,
          onClick: () => onSelect(item),
        })
      )
    );
    // hero: টাইলই নিজে কার্ড (বাইরে wrapper নেই); compact3: একটা সাদা কার্ডের ভিতরে
    if (variant === "hero") {
      return React.createElement("section", { className: "mb-3" }, grid);
    }
    return React.createElement(
      "section",
      { className: "mb-3 bg-white rounded-[20px] shadow-sm border border-slate-200/80 p-2.5" },
      title &&
        React.createElement(
          "div",
          { className: "flex items-center gap-2 mb-2.5 px-1 text-sm font-bold", style: { color: PRIMARY } },
          icon && React.createElement(ToolIcon, { name: icon, size: 16, color: PRIMARY }),
          title
        ),
      grid
    );
  }

  return React.createElement(
    "section",
    { className: "mb-3 bg-white rounded-2xl shadow-sm border border-slate-200/80 p-3" },
    title &&
      React.createElement(
        "div",
        { className: "flex items-center gap-2 mb-3 text-sm font-bold", style: { color: PRIMARY } },
        icon && React.createElement(ToolIcon, { name: icon, size: 16, color: PRIMARY }),
        title
      ),
    React.createElement(
      "div",
      { className: "grid grid-cols-4 gap-x-2 gap-y-3" },
      items.map((item) =>
        React.createElement(Tile, {
          key: item.key || item.id,
          icon: item.icon,
          label: item.label,
          onClick: () => onSelect(item),
        })
      )
    )
  );
}

// স্ক্রিন-হেডার (আমল/সহায়িকা উভয়ে) — নরম সবুজ ব্যান্ড, শিরোনাম+উপ-শিরোনাম।
// right (ঐচ্ছিক): ডানপাশের বাড়তি নিয়ন্ত্রণ, যেমন কুরআনের সেটিং-আইকন।
export function PageHeader({ title, subtitle, right }) {
  const text = [
    React.createElement("h1", { key: "t", className: "text-[19px] leading-tight", style: { fontFamily: SERIF, fontWeight: 500, color: PRIMARY } }, title),
    subtitle && React.createElement("p", { key: "s", className: "text-xs mt-0.5", style: { color: "#5B6B64" } }, subtitle),
  ];
  return React.createElement(
    "header",
    {
      className: "mb-3 rounded-2xl border px-4 py-3" + (right ? " flex items-center justify-between gap-3" : ""),
      style: { background: "linear-gradient(135deg, var(--theme-soft, #E8F0EE) 0%, var(--theme-wash, #F2F7F4) 100%)", borderColor: "var(--theme-line, #D3E3DD)" },
    },
    right ? React.createElement("div", { className: "min-w-0" }, text) : text,
    right
  );
}

// আইটেম/টুল-ডিটেইল পেজের হেডার (owner-request, ১৯ সেপ্টেম্বর ২০২৬: "ভিতরের পেজ
// প্রিমিয়াম লাগে না") — আগে শুধু plain bold টেক্সট ছিল, এখন hero-টাইলের মতো
// আইকন-ডিস্ক + gradient ব্যান্ড, cat.label ব্রেডক্রাম্ব হিসেবে সাবটাইটেলে।
export function DetailHeader({ icon, title, subtitle }) {
  return React.createElement(
    "header",
    {
      className: "mb-3 rounded-2xl border px-4 py-3.5 flex items-center gap-3",
      style: { background: "linear-gradient(135deg, var(--theme-soft, #E8F0EE) 0%, var(--theme-wash, #F2F7F4) 100%)", borderColor: "var(--theme-line, #D3E3DD)" },
    },
    icon &&
      React.createElement(
        "div",
        {
          className: "w-12 h-12 rounded-full flex items-center justify-center shrink-0",
          style: {
            background: "radial-gradient(circle at 30% 25%, #FFFFFF 0%, var(--theme-tint, #E3EEEA) 100%)",
            boxShadow: "inset 0 0 0 1px var(--theme-line, #D3E3DD)",
          },
        },
        React.createElement(ToolIcon, { name: icon, size: 22, color: PRIMARY })
      ),
    React.createElement(
      "div",
      { className: "min-w-0" },
      React.createElement(
        "h1",
        { className: "text-[17px] leading-tight truncate", style: { fontFamily: SERIF, fontWeight: 500, color: PRIMARY } },
        title
      ),
      subtitle && React.createElement("p", { className: "text-xs mt-0.5", style: { color: "#5B6B64" } }, subtitle)
    )
  );
}

// কুরআনের বাণী-কার্ড — লেখা অনুভূমিক ও উল্লম্ব, দুই দিকেই মাঝ-বরাবর (center)।
export function VerseCard({ text, source }) {
  return React.createElement(
    "div",
    {
      className: "rounded-[20px] px-5 py-4 text-center flex flex-col items-center justify-center gap-1.5",
      style: {
        minHeight: 92,
        background: "linear-gradient(160deg, var(--theme-primary, #0E4B43) 0%, var(--theme-deep, #0A3A34) 100%)",
        boxShadow: "0 4px 14px rgba(14,75,67,0.22)",
      },
    },
    React.createElement("p", { className: "text-base leading-relaxed", style: { fontFamily: SERIF, color: "#FFFFFF" } }, text),
    source && React.createElement("p", { className: "text-xs", style: { color: "#E0BC6B" } }, source)
  );
}
