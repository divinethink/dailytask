// PrayerTimes.jsx — "সময়সূচি" bottom-nav ট্যাব(Public Tools Phase A, item ২)।
// UI layout 3_2_Public_Tools_Architecture_Plan.md §৪.২ ও visual reference
// 3_3_Public_Tools_Final_Mockup.md §৫ ভিত্তিতে, ১৮ সেপ্টেম্বর ২০২৬-এ owner-feedback
// অনুযায়ী premium-redesign + accuracy fix। data/lib separation(Dev Rule ২): এই
// ফাইল কখনো সরাসরি fetch() করে না — publicToolsPrayerApi.js/publicToolsGeocode.js
// (data-layer) ব্যবহার করে। React global(window.React, globals.js)।

import { toBn, BN_MONTHS, getHijriDate } from "../../legacy/appHelpers.js";
import {
  getSavedLocation,
  saveLocation,
  getSavedMadhab,
  saveMadhab,
  detectGpsLocation,
  getGeoPermissionState,
  MANUAL_LOCATIONS,
} from "../../legacy/publicToolsSettings.js";
import { fetchDailyPrayerTimes, peekCachedDailyTimings } from "../../legacy/publicToolsPrayerApi.js";
import { searchBangladeshLocation, reverseGeocodeBangladesh, nearestDistrictName } from "../../legacy/publicToolsGeocode.js";
import { ChevronDown, ChevronLeft, Loader2, RefreshIcon, X } from "../icons.jsx";
import { Qibla } from "./Qibla.jsx";
import { WaqtAmalCard } from "../WaqtAmalCard.jsx";
import { MonthlyPrayerSchedule } from "./MonthlyPrayerSchedule.jsx";
import { JamaatCard } from "./JamaatCard.jsx";
import { visibleIds } from "../../legacy/tabLayout.js";
import { GPS_MESSAGES, usePopupMessages } from "../../legacy/popupMessages.js";

const { useState, useEffect, useMemo, useRef } = React;

// §GPS-বন্ধ নোটিশ(owner-approved): লোকেশন বন্ধ/অনুমতি-নেই ধরা পড়লে সময় ও ধরন localStorage-এ থাকে;
// ✕ চাপলে ব্যানার লুকায়, পরের ব্যর্থতায় আবার আসে। শুধু per-device UI-flag, কোনো ডেটা/Rules নেই।
const GPS_FLAG_KEY = "dt_pt_gps_issue";
const GPS_DISMISS_KEY = "dt_pt_gps_issue_dismissed";
function readGpsIssue() {
  try {
    const raw = localStorage.getItem(GPS_FLAG_KEY);
    if (!raw) return null;
    const v = JSON.parse(raw);
    const dismissedAt = Number(localStorage.getItem(GPS_DISMISS_KEY) || 0);
    if (!v || !v.kind || !GPS_TEXT[v.kind] || !(v.at > dismissedAt)) return null;
    return v;
  } catch {
    return null;
  }
}
function writeGpsIssue(kind) {
  try {
    if (kind) localStorage.setItem(GPS_FLAG_KEY, JSON.stringify({ kind, at: Date.now() }));
    else localStorage.removeItem(GPS_FLAG_KEY);
  } catch {}
}
function dismissGpsIssue() {
  try {
    localStorage.setItem(GPS_DISMISS_KEY, String(Date.now()));
  } catch {}
}
// ওয়েব-পেজ ফোনের/ব্রাউজারের সেটিংস নিজে খুলতে পারে না(কোনো API নেই) — স্ট্যান্ডার্ড হলো:
// কারণ ধরে পরিষ্কার ধাপ দেখানো + "আবার চেষ্টা করুন" বাটন + সেটিংস থেকে ফিরলে নিজে আবার চেষ্টা।
// কারণ: denied=ব্লক করা, prompt=প্রশ্নটি এড়ানো/বাতিল, off=ফোনের লোকেশন বন্ধ, timeout=সময় শেষ
const GPS_TEXT = GPS_MESSAGES;
const GPS_KINDS = ["off", "denied", "prompt", "timeout"];

function parseTimeOnDate(baseDate, hhmm) {
  if (!hhmm || typeof hhmm !== "string") return null;
  const [h, m] = hhmm.split(":").map(Number);
  if (Number.isNaN(h) || Number.isNaN(m)) return null;
  const d = new Date(baseDate);
  d.setHours(h, m, 0, 0);
  return d;
}

function addMinutes(date, mins) {
  return date ? new Date(date.getTime() + mins * 60000) : null;
}

// ১২-ঘণ্টা ফরম্যাট, AM/PM ছাড়া(owner-instruction, ১৮ সেপ্টেম্বর ২০২৬ — দ্বিতীয়
// রাউন্ড: "am/pm তুলে দিলে ফন্ট বাড়বে, সুন্দর লাগবে")। সেহরি/ইফতার footer-এ
// আলাদাভাবে বাংলা দিনাংশ-শব্দ("ভোর"/"সন্ধ্যা") জোড়া হয়, নিচে দ্রষ্টব্য।
function formatHHMM(date) {
  if (!date) return "--:--";
  let h = date.getHours();
  const m = String(date.getMinutes()).padStart(2, "0");
  h = h % 12;
  if (h === 0) h = 12;
  return `${toBn(h)}:${toBn(m)}`;
}

function formatCountdown(ms) {
  const safeMs = Math.max(0, ms);
  const totalSec = Math.floor(safeMs / 1000);
  const h = String(Math.floor(totalSec / 3600)).padStart(2, "0");
  const m = String(Math.floor((totalSec % 3600) / 60)).padStart(2, "0");
  const s = String(totalSec % 60).padStart(2, "0");
  return toBn(`${h}:${m}:${s}`);
}

// §মসজিদ-কার্ড(owner-approved ডিজাইন "ঘ", ১ নভেম্বর ২০২৬): কাউন্টডাউন + সালাতের
// সময়সূচি এক কার্ডে — উপরে খিলান+দুই মিনার আকৃতির হেডার(inline SVG, কোনো asset নেই),
// নিচে সময়সূচি। শুধু উপস্থাপনা; ওয়াক্ত/টিক-লজিক অপরিবর্তিত।
function WaqtHero({ waqtInfo, now, waqtProgress }) {
  const h = React.createElement;
  const GOLD = "#E3C26B";
  const totalSec = Math.max(0, Math.floor((waqtInfo.target.getTime() - now.getTime()) / 1000));
  const parts = [
    [Math.floor(totalSec / 3600), "ঘণ্টা"],
    [Math.floor((totalSec % 3600) / 60), "মিনিট"],
    [totalSec % 60, "সেকেন্ড"],
  ];
  const hasBar = waqtProgress !== null;
  const pct = hasBar ? Math.round(waqtProgress * 100) : 0;
  const H = hasBar ? 224 : 194; // viewBox-উচ্চতা = আসল px-উচ্চতা, তাই আকৃতি লম্বায় বিকৃত হয় না(শুধু প্রস্থে scale)
  const stroke = { stroke: GOLD, strokeOpacity: 0.6, strokeWidth: 1.5, vectorEffect: "non-scaling-stroke" };
  const dot = (left, top) => h("span", { "aria-hidden": true, className: "absolute rounded-full", style: { left, top, width: 7, height: 7, background: GOLD, transform: "translateX(-50%)" } });
  const minaretDecor = (x) => [
    h("line", { key: "a" + x, x1: x - 8, y1: 92, x2: x + 8, y2: 92, ...stroke }),
    h("line", { key: "b" + x, x1: x - 8, y1: 140, x2: x + 8, y2: 140, ...stroke }),
    h("rect", { key: "c" + x, x: x - 2.5, y: 106, width: 5, height: 14, rx: 2.5, fill: GOLD, fillOpacity: 0.5 }),
  ];
  return h(
    "div",
    { className: "relative text-white text-center", style: { height: H } },
    h(
      "svg",
      { viewBox: `0 0 400 ${H}`, preserveAspectRatio: "none", className: "absolute inset-0 w-full h-full pointer-events-none", "aria-hidden": true },
      h("defs", null,
        h("linearGradient", { id: "wq-grad", x1: 0, y1: 0, x2: 1, y2: 1 },
          h("stop", { offset: 0, style: { stopColor: "var(--theme-primary, #0E4B43)" } }),
          h("stop", { offset: 1, style: { stopColor: "var(--theme-ink, #16302B)" } }))),
      h("path", {
        d: `M0 ${H} V74 L12 42 L24 74 V140 C24 80 124 44 200 8 C276 44 376 80 376 140 V74 L388 42 L400 74 V${H} Z`,
        fill: "url(#wq-grad)", stroke: GOLD, strokeWidth: 1.6, strokeLinejoin: "round", vectorEffect: "non-scaling-stroke",
      }),
      h("path", {
        d: `M38 ${H} V148 C38 96 132 62 200 24 C268 62 362 96 362 148 V${H}`,
        fill: "none", stroke: GOLD, strokeOpacity: 0.45, vectorEffect: "non-scaling-stroke",
      }),
      minaretDecor(12), minaretDecor(388)
    ),
    dot("3%", 38), dot("50%", 4), dot("97%", 38),
    h(
      "div",
      { className: "relative flex flex-col items-center px-9", style: { paddingTop: 54 } },
      h("div", { className: "text-3xl font-bold leading-none text-center" }, waqtInfo.name),
      h("div", { className: "text-xs opacity-85 mt-1.5 text-center" }, waqtInfo.currentKey ? h("span", { style: { color: GOLD } }, "● ") : null, waqtInfo.label),
      h(
        "div",
        { className: "flex gap-2 justify-center w-full mt-3", role: "timer", "aria-label": `${waqtInfo.name} ${waqtInfo.label}` },
        parts.map(([n, u]) =>
          h(
            "div",
            { key: u, className: "w-16 shrink-0 rounded-[10px] border border-white/20 bg-white/10 py-[3px]" },
            h("b", { className: "block text-[18px] leading-[22px]", style: { fontFamily: "'Hind Siliguri', sans-serif" } }, toBn(String(n).padStart(2, "0"))),
            h("small", { className: "block text-[10px] leading-[13px] opacity-80" }, u)
          )
        )
      ),
      hasBar &&
        h(
          "div",
          { className: "w-full mt-3" },
          h(
            "div",
            { className: "h-[5px] rounded-full bg-white/20 overflow-hidden", role: "progressbar", "aria-valuenow": pct, "aria-valuemin": 0, "aria-valuemax": 100 },
            h("div", { className: "h-full rounded-full", style: { width: `${pct}%`, background: GOLD } })
          ),
          h(
            "div",
            { className: "flex justify-between text-xs opacity-75 mt-1" },
            h("span", null, formatHHMM(waqtInfo.start)),
            h("span", null, `${toBn(pct)}% সময় পার`),
            h("span", null, formatHHMM(waqtInfo.target))
          )
        )
    )
  );
}

function formatGregorianDate(date) {
  return `${toBn(date.getDate())} ${BN_MONTHS[date.getMonth()]} ${toBn(date.getFullYear())}`;
}

function formatHijriDate(date) {
  const h = getHijriDate(date);
  return `${toBn(h.day)} ${h.month} ${toBn(h.year)}`;
}

// §লোকেশন-রো vs GPS-পিল — আলাদা icon(owner-instruction, ১৮ সেপ্টেম্বর ২০২৬): আগে
// দুই জায়গাতেই একই 📍 emoji ছিল, বিভ্রান্তিকর। এখন GPS-পিলে crosshair/target(GpsIcon)
// ও এলাকা-রো-তে classic map-pin/teardrop(PinIcon) — দুটো visually স্পষ্ট আলাদা।
function PinIcon({ size = 14, className }) {
  return /*#__PURE__*/React.createElement(
    "svg",
    { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", className },
    /*#__PURE__*/React.createElement("path", { d: "M12 22s7-7.5 7-12a7 7 0 1 0-14 0c0 4.5 7 12 7 12z" }),
    /*#__PURE__*/React.createElement("circle", { cx: 12, cy: 10, r: 2.5 })
  );
}

function GpsIcon({ size = 12, className }) {
  return /*#__PURE__*/React.createElement(
    "svg",
    { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", className },
    /*#__PURE__*/React.createElement("circle", { cx: 12, cy: 12, r: 3 }),
    /*#__PURE__*/React.createElement("line", { x1: 12, y1: 2, x2: 12, y2: 5 }),
    /*#__PURE__*/React.createElement("line", { x1: 12, y1: 19, x2: 12, y2: 22 }),
    /*#__PURE__*/React.createElement("line", { x1: 2, y1: 12, x2: 5, y2: 12 }),
    /*#__PURE__*/React.createElement("line", { x1: 19, y1: 12, x2: 22, y2: 12 })
  );
}

// §রেখা-আইকন(নিচের নেভ বারের ধাঁচ: stroke, currentColor)
function LineSvg({ size, className, style, children }) {
  return /*#__PURE__*/React.createElement(
    "svg",
    { width: size, height: size, viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "1.8", strokeLinecap: "round", strokeLinejoin: "round", className, style, "aria-hidden": true },
    children
  );
}
function MosqueLineIcon({ size = 18, className, style }) {
  return /*#__PURE__*/React.createElement(
    LineSvg,
    { size, className, style },
    /*#__PURE__*/React.createElement("path", { d: "M12 3v2M5 21v-9a7 7 0 0 1 14 0v9M3 21h18M9 21v-4a3 3 0 0 1 6 0v4" })
  );
}
function MoonStarIcon({ size = 22, className, style }) {
  return /*#__PURE__*/React.createElement(
    LineSvg,
    { size, className, style },
    /*#__PURE__*/React.createElement("path", { d: "M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5z" }),
    /*#__PURE__*/React.createElement("path", { d: "M17 3v3M15.5 4.5h3" })
  );
}
function SunsetIcon({ size = 22, className, style }) {
  return /*#__PURE__*/React.createElement(
    LineSvg,
    { size, className, style },
    /*#__PURE__*/React.createElement("path", { d: "M3 19h18M6 19a6 6 0 0 1 12 0M12 7V4M4.5 11l2 1.5M19.5 11l-2 1.5" })
  );
}

function WaqtIconChip({ emoji, bg }) {
  return /*#__PURE__*/React.createElement(
    "span",
    { className: "w-6 h-6 rounded-full flex items-center justify-center text-xs shrink-0", style: { background: bg } },
    emoji
  );
}

const WAQT_CHIP = {
  fajr: { emoji: "🌅", bg: "linear-gradient(135deg,#BFE3FF,#EAF6FF)" },
  dhuhr: { emoji: "☀️", bg: "linear-gradient(135deg,#FFE9A8,#FFF6DC)" },
  asr: { emoji: "🔆", bg: "linear-gradient(135deg,#FFD59E,#FFEDD5)" },
  maghrib: { emoji: "🌇", bg: "linear-gradient(135deg,#FFB199,#FFE1D6)" },
  isha: { emoji: "🌙", bg: "linear-gradient(135deg,#C9D6E3,#EDF1F5)" },
};

// ("পরবর্তী ওয়াক্ত + আমল" কার্ড হোম-ট্যাবে সরানো হয়েছে — components/WaqtAmalCard.jsx)
const OTHER_ITEMS = [
  { k: "tahajjud", label: "তাহাজ্জুদ", color: "#4B4FA8" },
  { k: "ishraq", label: "ইশরাক", color: "#B3610E" },
  { k: "chasht", label: "চাশত", color: "#0F6E56" },
  { k: "awabin", label: "আওয়াবিন", color: "#B23A25" },
];
const DONE_KEY = "dt_pt_done";
function dayKey(d) {
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}
function readDone(d) {
  try {
    const o = JSON.parse(localStorage.getItem(DONE_KEY) || "null");
    return o && o.d === dayKey(d) && o.k ? o.k : {};
  } catch {
    return {};
  }
}

export function PrayerTimes({ layout, tabLayout } = {}) {
  const [location, setLocationState] = useState(() => getSavedLocation());
  const [madhab, setMadhabState] = useState(() => getSavedMadhab());
  // §লোড-ব্যাকগ্রাউন্ডে: সর্বশেষ সিংক-করা সময় প্রথম render-এই দেখানো হয়, নেটওয়ার্ক আপডেট নিচে চলে।
  const [timings, setTimings] = useState(() => {
    const l = getSavedLocation();
    const c = l && peekCachedDailyTimings({ lat: l.lat, lon: l.lon, madhab: getSavedMadhab(), date: new Date() });
    return c ? c.timings : null;
  });
  const [syncedAt, setSyncedAt] = useState(() => {
    const l = getSavedLocation();
    const c = l && peekCachedDailyTimings({ lat: l.lat, lon: l.lon, madhab: getSavedMadhab(), date: new Date() });
    return c ? c.fetchedAt : null;
  });
  const [approximate, setApproximate] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [now, setNow] = useState(() => new Date());
  // তারিখ বদলালে(মধ্যরাত পার হলে) সময়সূচি নতুন করে আনতে/হিসাব করতে
  const todayKey = dayKey(now);
  const [locationPanelOpen, setLocationPanelOpen] = useState(false);
  const [madhabPanelOpen, setMadhabPanelOpen] = useState(false);
  const [gpsBusy, setGpsBusy] = useState(false);
  const [gpsPopup, setGpsPopup] = useState(null);
  const [gpsIssue, setGpsIssue] = useState(() => readGpsIssue());
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchError, setSearchError] = useState(null);
  // §জেলা/উপজেলা ফিল্টার(নতুন, ১৮ সেপ্টেম্বর ২০২৬, owner-instruction) — bangladeshGeoData.js
  // lazy-load হয়(শুধু panel খোলার পরে, ৪১KB dataset PrayerTimes-এর মূল chunk-কে ভারী না করতে)।
  const [geoData, setGeoData] = useState(null);
  const [geoLoading, setGeoLoading] = useState(false);
  const [filterDistrictId, setFilterDistrictId] = useState("");
  const [filterUpazilaId, setFilterUpazilaId] = useState("");
  const [filterBusy, setFilterBusy] = useState(false);
  // §জেলা-সার্চ(owner-instruction, ১৯ সেপ্টেম্বর ২০২৬): native <select>-এ সার্চ
  // করা যায় না, তাই জেলা তালিকার উপরে আলাদা সার্চ-বক্স সহ custom dropdown।
  const [districtPickerOpen, setDistrictPickerOpen] = useState(false);
  const [districtSearchQuery, setDistrictSearchQuery] = useState("");
  const reqIdRef = useRef(0);
  // §ওয়াক্ত ✓(শুধু এই ডিভাইসে, দিন বদলালে নিজে রিসেট; হোম-ডেটা/Firestore-এ কিছু লেখে না)
  const [done, setDone] = useState(() => readDone(new Date()));
  const [sub, setSub] = useState(null);
  const searchReqIdRef = useRef(0);

  // প্রতি সেকেন্ডে countdown আপডেট(existing timer-pattern reuse, 3_2 §৪.২ item ৩)
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  // Location/মাযহাব বদলালেই দৈনিক সময়সূচি নতুন করে fetch(cache-fallback data-layer-এই হয়)
  useEffect(() => {
    if (!location) return;
    const myReqId = ++reqIdRef.current;
    setLoading(true);
    setError(null);
    const cachedNow = peekCachedDailyTimings({ lat: location.lat, lon: location.lon, madhab, date: new Date() });
    setTimings(cachedNow ? cachedNow.timings : null);
    setSyncedAt(cachedNow ? cachedNow.fetchedAt : null);
    fetchDailyPrayerTimes({ lat: location.lat, lon: location.lon, madhab, date: new Date() })
      .then((res) => {
        if (myReqId !== reqIdRef.current) return;
        setTimings(res.timings);
        setSyncedAt(res.fetchedAt || null);
        setApproximate(!!res.approximate);
      })
      .catch((err) => {
        if (myReqId !== reqIdRef.current) return;
        setTimings(null);
        setError(err && err.message ? err.message : "সময়সূচি আনতে ব্যর্থ হয়েছে");
      })
      .finally(() => {
        if (myReqId !== reqIdRef.current) return;
        setLoading(false);
      });
  }, [location, madhab, todayKey]);

  // §এলাকা-সার্চ(debounced, ৫০০ms) — Nominatim usage-policy-সৌজন্যে অকারণ
  // request এড়াতে ২ অক্ষরের কম হলে বা typing চলাকালীন call হয় না।
  useEffect(() => {
    if (searchQuery.trim().length < 2) {
      setSearchResults([]);
      setSearchError(null);
      return;
    }
    const myReqId = ++searchReqIdRef.current;
    const timer = setTimeout(() => {
      setSearchLoading(true);
      setSearchError(null);
      searchBangladeshLocation(searchQuery)
        .then((results) => {
          if (myReqId !== searchReqIdRef.current) return;
          setSearchResults(results);
        })
        .catch(() => {
          if (myReqId !== searchReqIdRef.current) return;
          setSearchError("এলাকা খুঁজে পাওয়া যায়নি, আবার চেষ্টা করুন");
        })
        .finally(() => {
          if (myReqId !== searchReqIdRef.current) return;
          setSearchLoading(false);
        });
    }, 500);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  // §জেলা/উপজেলা geo-dataset lazy-load — panel প্রথমবার খোলার সময়ে, অথবা
  // location এখনো সেট-না-থাকা প্রথমবার(initial no-location screen-ও একই
  // renderLocationPicker() ব্যবহার করে) — দুই ক্ষেত্রেই একবার fetch, cache(state)।
  useEffect(() => {
    if ((!locationPanelOpen && location) || geoData || geoLoading) return;
    setGeoLoading(true);
    import("../../legacy/bangladeshGeoData.js")
      .then((mod) => setGeoData({ districts: mod.BD_DISTRICTS, upazilas: mod.BD_UPAZILAS }))
      .catch(() => setGeoData(null))
      .finally(() => setGeoLoading(false));
  }, [locationPanelOpen, location, geoData, geoLoading]);

  function applyLocation(loc) {
    setLocationState(loc);
    saveLocation(loc);
    setLocationPanelOpen(false);
    setSearchQuery("");
    setSearchResults([]);
    setFilterDistrictId("");
    setFilterUpazilaId("");
  }

  // §GPS reverse-geocode(owner-instruction, ১৮ সেপ্টেম্বর ২০২৬): শুধু lat/lon
  // পাওয়ার পর Nominatim reverse দিয়ে "এলাকা, জেলা" নাম বের করা হয়(উদাহরণ:
  // "গুলশান, ঢাকা") — জেনেরিক "GPS অবস্থান" লেবেলের বদলে। reverse-geocode fail
  // করলেও lat/lon সঠিক থাকে বলে generic label-এ gracefully fallback করে(সময়সূচি
  // ভুল হয় না, শুধু লেবেল কম-informative থাকে)।
  // নাম বের করা: Nominatim → ব্যর্থ হলে নিকটতম জেলা → শেষে জেনেরিক।
  function resolveGpsName(loc) {
    return reverseGeocodeBangladesh(loc.lat, loc.lon)
      .catch(() => nearestDistrictName(loc.lat, loc.lon))
      .then((n) => n || "GPS অবস্থান")
      .catch(() => "GPS অবস্থান");
  }

  // §ট্যাব খুললে আর স্বয়ংক্রিয় GPS চাওয়া হয় না(owner-approved: পুরো-পেজ লোকেশন-ডায়ালগ বিরক্তিকর ছিল)।
  // শুধু সংরক্ষিত GPS-লোকেশনের নাম জেনেরিক থাকলে নীরবে নাম বের করা হয়(এতে GPS লাগে না, শুধু নেটওয়ার্ক)।
  // নতুন GPS পড়া হয় কেবল "রিফ্রেশ" বা "GPS দিয়ে সঠিক অবস্থান নিন" বাটনে।
  useEffect(() => {
    const saved = getSavedLocation();
    if (!saved || saved.source !== "gps") return;
    const needName = !saved.name || saved.name === "GPS অবস্থান";
    if (!needName) return;
    let cancelled = false;
    resolveGpsName(saved).then((name) => {
      if (cancelled || !name || name === saved.name) return;
      const next = { ...saved, name, source: "gps" };
      setLocationState(next);
      saveLocation(next);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  function showGpsIssue(kind) {
    writeGpsIssue(kind);
    setGpsIssue({ kind, at: Date.now() });
    setGpsPopup(kind);
  }

  function handleGpsFailure(err) {
    const code = err && err.code;
    if (code === 1) {
      // অনুমতি নেই: ব্লক(denied) নাকি শুধু প্রশ্ন এড়ানো(prompt) — আলাদা নির্দেশ
      return getGeoPermissionState().then((st) => showGpsIssue(st === "denied" ? "denied" : "prompt"));
    }
    if (code === 2) {
      showGpsIssue("off");
      return;
    }
    if (code === 3) {
      showGpsIssue("timeout");
      return;
    }
    setError(err && err.message ? err.message : "GPS অবস্থান পাওয়া যায়নি");
  }

  function handleUseGps() {
    setGpsBusy(true);
    detectGpsLocation({ fresh: true })
      .then((loc) =>
        resolveGpsName(loc).then((name) => {
          writeGpsIssue(null);
          setGpsIssue(null);
          applyLocation({ ...loc, name });
        })
      )
      .catch(handleGpsFailure)
      .finally(() => setGpsBusy(false));
  }

  // §রিফ্রেশ: GPS-অবস্থান হলে নতুন করে GPS চায়(বন্ধ থাকলে পপআপ); ম্যানুয়াল অবস্থান হলে শুধু সময় নতুন করে আনে।
  function handleRefresh() {
    if (gpsBusy || loading) return;
    if (!location || location.source !== "gps") {
      if (location) setLocationState({ ...location });
      return;
    }
    setGpsBusy(true);
    detectGpsLocation({ fresh: true })
      .then((g) => {
        writeGpsIssue(null);
        setGpsIssue(null);
        const moved = Math.abs(g.lat - location.lat) > 0.01 || Math.abs(g.lon - location.lon) > 0.01;
        const base = moved ? g : location;
        const needName = moved || !location.name || location.name === "GPS অবস্থান";
        return (needName ? resolveGpsName(base) : Promise.resolve(location.name)).then((name) => {
          const next = { ...base, name, source: "gps" };
          setLocationState(next);
          saveLocation(next);
        });
      })
      .catch(handleGpsFailure)
      .finally(() => setGpsBusy(false));
  }

  // ব্যানার(দুই লাইন, ✕ সহ) ও পপআপ — বন্ধ/অনুমতি-নেই অবস্থায়
  // লেখা App Creator সম্পাদনা করতে পারেন(মেনু → পপআপ বার্তা সম্পাদনা); না থাকলে কোড-ডিফল্ট
  const gpsMsgs = usePopupMessages(!!(gpsPopup || gpsIssue), GPS_KINDS.map((k) => "gps_" + k));
  const gpsMsg = (k) => gpsMsgs[GPS_KINDS.indexOf(k)];
  const gpsBanner = gpsIssue
    ? /*#__PURE__*/React.createElement(
        "div",
        { className: "mx-4 mb-2 flex items-start gap-2 text-sm text-amber-800 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2" },
        /*#__PURE__*/React.createElement(
          "div",
          { className: "flex-1" },
          /*#__PURE__*/React.createElement("div", { className: "font-bold" }, gpsMsg(gpsIssue.kind).custom ? gpsMsg(gpsIssue.kind).title : GPS_TEXT[gpsIssue.kind].title),
          /*#__PURE__*/React.createElement("div", null, gpsMsg(gpsIssue.kind).custom ? gpsMsg(gpsIssue.kind).body.split("\n")[0] : GPS_TEXT[gpsIssue.kind].short)
        ),
        /*#__PURE__*/React.createElement(
          "button",
          {
            type: "button",
            "aria-label": "বন্ধ করুন",
            onClick: () => {
              dismissGpsIssue();
              setGpsIssue(null);
            },
            className: "w-8 h-8 -mr-1 -mt-1 flex items-center justify-center text-amber-800",
          },
          /*#__PURE__*/React.createElement(X, { size: 16 })
        )
      )
    : null;
  const gpsPopupEl = gpsPopup && GPS_TEXT[gpsPopup]
    ? /*#__PURE__*/React.createElement(
        "div",
        { className: "fixed inset-0 z-50 flex items-center justify-center px-6", style: { background: "rgba(0,0,0,0.45)" } },
        /*#__PURE__*/React.createElement(
          "div",
          { className: "bg-white rounded-2xl p-5 w-full max-w-sm shadow-md max-h-[85vh] overflow-y-auto" },
          /*#__PURE__*/React.createElement("div", { className: "text-base font-bold text-emerald-950 mb-2" }, gpsMsg(gpsPopup).custom ? gpsMsg(gpsPopup).title : GPS_TEXT[gpsPopup].title),
          /*#__PURE__*/React.createElement("p", { className: "text-sm text-slate-600 leading-relaxed mb-3 whitespace-pre-line" }, gpsMsg(gpsPopup).custom ? gpsMsg(gpsPopup).body : GPS_TEXT[gpsPopup].body),
          !gpsMsg(gpsPopup).custom && GPS_TEXT[gpsPopup].steps.length > 0 &&
            /*#__PURE__*/React.createElement(
              "ol",
              { className: "list-decimal pl-5 text-sm text-slate-700 leading-relaxed mb-4 flex flex-col gap-1" },
              GPS_TEXT[gpsPopup].steps.map((t, i) => /*#__PURE__*/React.createElement("li", { key: i }, t))
            ),
          /*#__PURE__*/React.createElement(
            "button",
            {
              type: "button",
              disabled: gpsBusy,
              onClick: () => {
                setGpsPopup(null);
                handleUseGps();
              },
              className: "w-full h-11 rounded-xl font-bold text-white text-sm bg-emerald-900 disabled:opacity-50",
            },
            "আবার চেষ্টা করুন"
          ),
          /*#__PURE__*/React.createElement(
            "button",
            {
              type: "button",
              onClick: () => setGpsPopup(null),
              className: "w-full h-11 mt-2 rounded-xl font-semibold text-emerald-900 text-sm border border-slate-200",
            },
            "পরে"
          )
        )
      )
    : null;

  // সেটিংস থেকে অ্যাপে ফিরলে: পপআপ খোলা ও অনুমতি এখন "granted" হলে নিজে আবার চেষ্টা(প্রশ্ন আসে না)
  useEffect(() => {
    if (!gpsPopup) return;
    function onVisible() {
      if (document.visibilityState !== "visible" || gpsBusy) return;
      getGeoPermissionState().then((st) => {
        if (st === "granted") {
          setGpsPopup(null);
          handleUseGps();
        }
      });
    }
    document.addEventListener("visibilitychange", onVisible);
    return () => document.removeEventListener("visibilitychange", onVisible);
  }, [gpsPopup, gpsBusy]);

  function handleMadhabChange(m) {
    setMadhabState(m);
    saveMadhab(m);
    setMadhabPanelOpen(false);
  }

  // §জেলা/উপজেলা ফিল্টার প্রয়োগ(নতুন, owner-instruction) — জেলা-শুধু বাছাই হলে
  // সরকারি DC-office lat/lon(bangladeshGeoData.js) সরাসরি ব্যবহার হয়(কোনো extra
  // API-call লাগে না); উপজেলা-সহ বাছাই হলে Nominatim দিয়ে সেই নির্দিষ্ট উপজেলার
  // সঠিক lat/lon আনা হয়(fail করলে জেলা-কেন্দ্রের coordinate-এ gracefully fallback,
  // ইউজার কখনো আটকে যাবে না)।
  function applyFilterSelection() {
    if (!geoData || !filterDistrictId) return;
    const district = geoData.districts.find((d) => d.id === filterDistrictId);
    if (!district) return;
    if (!filterUpazilaId) {
      applyLocation({ lat: district.lat, lon: district.lon, name: district.name, source: "filter" });
      return;
    }
    const upazila = geoData.upazilas.find((u) => u.id === filterUpazilaId);
    if (!upazila) return;
    const combinedName = `${upazila.name}, ${district.name}`;
    setFilterBusy(true);
    searchBangladeshLocation(`${upazila.name}, ${district.name}`)
      .then((results) => {
        if (results.length > 0) applyLocation({ ...results[0], name: combinedName });
        else applyLocation({ lat: district.lat, lon: district.lon, name: combinedName, source: "filter" });
      })
      .catch(() => applyLocation({ lat: district.lat, lon: district.lon, name: combinedName, source: "filter" }))
      .finally(() => setFilterBusy(false));
  }

  // §৪.১ bonus-derive — পূর্ণ schedule(আজকের সব ওয়াক্ত+সংশ্লিষ্ট time)
  const schedule = useMemo(() => {
    if (!timings) return null;
    const today = new Date();
    const get = (k) => parseTimeOnDate(today, timings[k]);
    const fajr = get("Fajr");
    const sunrise = get("Sunrise");
    const dhuhr = get("Dhuhr");
    const asr = get("Asr");
    const sunset = get("Sunset") || get("Maghrib");
    const maghrib = get("Maghrib");
    const isha = get("Isha");
    if (!fajr || !sunrise || !dhuhr || !asr || !maghrib || !isha) return null;
    // পরদিনের ফজর — নতুন API-call এড়াতে আজকের ফজর-সময়ই পরদিনের জন্য approximate
    // হিসেবে ব্যবহৃত(কয়েক মিনিটের farok থাকতে পারে, "আনুমানিক" স্পিরিট)।
    const nextFajr = addMinutes(fajr, 24 * 60);
    return { fajr, sunrise, dhuhr, asr, sunset, maghrib, isha, nextFajr };
  }, [timings, todayKey]);

  // বর্তমান/পরবর্তী ওয়াক্ত(countdown banner) + list-highlight
  const waqtInfo = useMemo(() => {
    if (!schedule) return null;
    const { fajr, sunrise, dhuhr, asr, maghrib, isha, nextFajr } = schedule;
    if (now < fajr) {
      return { name: "ইশা", label: "শেষ হতে বাকি", target: fajr, currentKey: "isha", start: addMinutes(isha, -1440) };
    }
    const windows = [
      { key: "fajr", name: "ফজর", start: fajr, end: sunrise },
      { key: "dhuhr", name: "যোহর", start: dhuhr, end: asr },
      { key: "asr", name: "আসর", start: asr, end: maghrib },
      { key: "maghrib", name: "মাগরিব", start: maghrib, end: isha },
      { key: "isha", name: "ইশা", start: isha, end: nextFajr },
    ];
    const active = windows.find((w) => now >= w.start && now < w.end);
    if (active) return { name: active.name, label: "শেষ হতে বাকি", target: active.end, currentKey: active.key, start: active.start };
    const upcoming = windows.find((w) => now < w.start);
    if (upcoming) return { name: upcoming.name, label: "শুরু হতে বাকি", target: upcoming.start, currentKey: null, nextKey: upcoming.key };
    return { name: "ফজর", label: "শুরু হতে বাকি", target: nextFajr, currentKey: null, nextKey: "fajr" };
  }, [schedule, now]);

  // §রমজান সেহরি/ইফতার countdown — data-layer/schema(owner-instruction, ১৮
  // সেপ্টেম্বর ২০২৬): "রমজান মাস আসলে এই পেজেই ইফতার ও সেহরি কাউন্টডাউন দেখানোর
  // অপশন রাখতে হবে, পর্যাপ্ত data layer/schema রাখবেন"। হিজরি মাস "রমজান"(existing
  // getHijriDate()/HIJRI_MONTHS_BN reuse, appHelpers.js) হলেই স্বয়ংক্রিয়ভাবে সক্রিয়
  // হবে — কোনো manual toggle/flag লাগে না, এখন(hijri মাস রমজান না) কিছুই render
  // করবে না(null), তাই বর্তমান UI অপরিবর্তিত থাকে। রমজান মাস এলে schedule.fajr/
  // schedule.maghrib থেকেই সরাসরি derive হবে(নতুন API/storage লাগবে না)।
  const hijriNow = useMemo(() => getHijriDate(now), [now]);
  const isRamadan = hijriNow.month === "রমজান";
  const ramadanCountdown = useMemo(() => {
    if (!isRamadan || !schedule) return null;
    const { fajr, maghrib, nextFajr } = schedule;
    if (now < fajr) return { label: "সেহরি শেষ হতে বাকি", target: fajr };
    if (now < maghrib) return { label: "ইফতার হতে বাকি", target: maghrib };
    return { label: "সেহরি শেষ হতে বাকি", target: nextFajr };
  }, [isRamadan, schedule, now]);

  // নিষিদ্ধ সময় — সূর্যোদয়/মধ্যাহ্ন/সূর্যাস্ত window(§৪.১ bonus-derive)
  const forbiddenWindows = useMemo(() => {
    if (!schedule) return [];
    const { sunrise, dhuhr, sunset } = schedule;
    return [
      { label: "সূর্যোদয়", start: sunrise, end: addMinutes(sunrise, 18) },
      { label: "মধ্যাহ্ন", start: addMinutes(dhuhr, -8), end: dhuhr },
      { label: "সূর্যাস্ত", start: addMinutes(sunset, -15), end: sunset },
    ];
  }, [schedule]);

  // §Owner-instruction(১৮ সেপ্টেম্বর): তাহাজ্জুদ+ইশরাক+চাশত+আওয়াবিন — কলাপসিবল
  // বাদ, সবসময় visible। ইশরাক(সূর্যোদয়ের অল্প পরে, ছোট window) ও চাশত(তার পরে
  // যোহরের আগ পর্যন্ত) আলাদা করে দেখানো হচ্ছে(আগে একত্রে "দুহা" ছিল)।
  const otherTimes = useMemo(() => {
    if (!schedule) return null;
    const { sunrise, dhuhr, maghrib, isha, nextFajr } = schedule;
    const nightMs = nextFajr.getTime() - isha.getTime();
    const tahajjudStart = new Date(isha.getTime() + nightMs * (2 / 3));
    const ishraqStart = addMinutes(sunrise, 20);
    const ishraqEnd = addMinutes(sunrise, 40);
    const chashtEnd = addMinutes(dhuhr, -10);
    return {
      tahajjud: { start: tahajjudStart, end: nextFajr },
      ishraq: { start: ishraqStart, end: ishraqEnd },
      chasht: { start: ishraqEnd, end: chashtEnd },
      awabin: { start: maghrib, end: isha },
    };
  }, [schedule]);

  const rows = useMemo(() => {
    if (!schedule) return [];
    const { fajr, sunrise, dhuhr, asr, maghrib, isha } = schedule;
    return [
      { key: "fajr", label: "ফজর", start: fajr, end: sunrise },
      { key: "dhuhr", label: "যোহর", start: dhuhr, end: asr },
      { key: "asr", label: "আসর", start: asr, end: maghrib },
      { key: "maghrib", label: "মাগরিব", start: maghrib, end: isha },
      { key: "isha", label: "ইশা", start: isha, end: null },
    ];
  }, [schedule]);

  const dk = dayKey(now);
  const doneToday = done;
  function toggleDone(key) {
    const cur = readDone(new Date());
    const next = { ...cur, [key]: !cur[key] };
    try {
      localStorage.setItem(DONE_KEY, JSON.stringify({ d: dayKey(new Date()), k: next }));
    } catch {}
    setDone(next);
  }
  // দিন বদলালে(মধ্যরাত) ✓ রিসেট
  useEffect(() => {
    setDone(readDone(new Date()));
  }, [dk]);

  const activeForbidden = useMemo(() => forbiddenWindows.find((w) => now >= w.start && now < w.end) || null, [forbiddenWindows, now]);
  const waqtProgress = useMemo(() => {
    if (!waqtInfo || !waqtInfo.currentKey || !waqtInfo.start) return null;
    const total = waqtInfo.target.getTime() - waqtInfo.start.getTime();
    if (total <= 0) return null;
    return Math.min(1, Math.max(0, (now.getTime() - waqtInfo.start.getTime()) / total));
  }, [waqtInfo, now]);

  // ---- এলাকা-সার্চ+quick-shortcut+GPS — একই panel initial-state ও header দুই
  // জায়গাতেই reuse হয়(§Nominatim-নোট, publicToolsGeocode.js) ----
  function renderLocationPicker() {
    return /*#__PURE__*/React.createElement(
      "div",
      { className: "flex flex-col gap-2 w-full" },
      /*#__PURE__*/React.createElement(
        "button",
        {
          type: "button",
          disabled: gpsBusy,
          onClick: handleUseGps,
          className:
            "h-10 px-4 rounded-xl font-bold text-white text-sm bg-emerald-900 flex items-center justify-center gap-2 shadow-sm disabled:opacity-50",
        },
        gpsBusy && /*#__PURE__*/React.createElement(Loader2, { size: 15, className: "animate-spin" }),
        "📍 GPS দিয়ে সঠিক অবস্থান নিন"
      ),
      // §জেলা/উপজেলা ফিল্টার(নতুন) — cascading dropdown, geoData lazy-loaded
      /*#__PURE__*/React.createElement(
        "div",
        { className: "border-t border-slate-100 pt-2 flex flex-col gap-1.5" },
        /*#__PURE__*/React.createElement("div", { className: "text-xs text-slate-400 px-1" }, "ম্যানুয়ালি এলাকা নির্বাচন করুন:"),
        geoLoading &&
          /*#__PURE__*/React.createElement(
            "div",
            { className: "text-sm text-slate-500 flex items-center gap-1.5 px-1" },
            /*#__PURE__*/React.createElement(Loader2, { size: 12, className: "animate-spin" }),
            "জেলার তালিকা আনা হচ্ছে..."
          ),
        geoData &&
          /*#__PURE__*/React.createElement(
            "div",
            { className: "flex gap-1.5" },
            /*#__PURE__*/React.createElement(
              "div",
              { className: "flex-1 relative" },
              /*#__PURE__*/React.createElement(
                "button",
                {
                  type: "button",
                  onClick: () => setDistrictPickerOpen((v) => !v),
                  className:
                    "w-full h-9 px-2 rounded-lg border border-slate-200 text-sm bg-white flex items-center justify-between " +
                    (filterDistrictId ? "text-slate-800" : "text-slate-400"),
                },
                filterDistrictId
                  ? geoData.districts.find((d) => d.id === filterDistrictId).name
                  : "জেলা বাছাই করুন",
                /*#__PURE__*/React.createElement(ChevronDown, { size: 12 })
              ),
              districtPickerOpen &&
                /*#__PURE__*/React.createElement(
                  "div",
                  { className: "absolute left-0 right-0 mt-1 bg-white rounded-xl shadow-md border border-slate-200 p-1.5 z-30 flex flex-col gap-1" },
                  /*#__PURE__*/React.createElement("input", {
                    type: "text",
                    autoFocus: true,
                    value: districtSearchQuery,
                    onChange: (e) => setDistrictSearchQuery(e.target.value),
                    placeholder: "জেলার নাম লিখে খুঁজুন...",
                    className: "h-8 px-2 rounded-lg border border-slate-200 text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-700",
                  }),
                  /*#__PURE__*/React.createElement(
                    "div",
                    { className: "flex flex-col max-h-40 overflow-y-auto" },
                    geoData.districts
                      .filter((d) => d.name.includes(districtSearchQuery.trim()))
                      .map((d) =>
                        /*#__PURE__*/React.createElement(
                          "button",
                          {
                            key: d.id,
                            type: "button",
                            onClick: () => {
                              setFilterDistrictId(d.id);
                              setFilterUpazilaId("");
                              setDistrictPickerOpen(false);
                              setDistrictSearchQuery("");
                            },
                            className:
                              "text-left text-sm px-2 py-1.5 rounded-lg hover:bg-slate-50 " +
                              (d.id === filterDistrictId ? "text-emerald-800 font-bold" : "text-slate-700"),
                          },
                          d.name
                        )
                      ),
                    geoData.districts.filter((d) => d.name.includes(districtSearchQuery.trim())).length === 0 &&
                      /*#__PURE__*/React.createElement("div", { className: "text-sm text-slate-400 px-2 py-1.5" }, "কোনো জেলা পাওয়া যায়নি")
                  )
                )
            ),
            /*#__PURE__*/React.createElement(
              "select",
              {
                value: filterUpazilaId,
                disabled: !filterDistrictId,
                onChange: (e) => setFilterUpazilaId(e.target.value),
                className: "flex-1 h-9 px-2 rounded-lg border border-slate-200 text-sm text-slate-800 bg-white disabled:opacity-50",
              },
              /*#__PURE__*/React.createElement("option", { value: "" }, "উপজেলা(ঐচ্ছিক)"),
              geoData.upazilas
                .filter((u) => u.districtId === filterDistrictId)
                .map((u) => /*#__PURE__*/React.createElement("option", { key: u.id, value: u.id }, u.name))
            )
          ),
        geoData &&
          filterDistrictId &&
          /*#__PURE__*/React.createElement(
            "button",
            {
              type: "button",
              disabled: filterBusy,
              onClick: applyFilterSelection,
              className: "h-9 rounded-lg bg-emerald-800 text-white text-sm font-bold flex items-center justify-center gap-1.5 disabled:opacity-50",
            },
            filterBusy && /*#__PURE__*/React.createElement(Loader2, { size: 12, className: "animate-spin" }),
            "এই এলাকা নির্বাচন করুন"
          )
      ),
      /*#__PURE__*/React.createElement("div", { className: "text-xs text-slate-400 px-1 pt-1" }, "অথবা লিখে সার্চ করুন:"),
      /*#__PURE__*/React.createElement("input", {
        type: "text",
        value: searchQuery,
        onChange: (e) => setSearchQuery(e.target.value),
        placeholder: "এলাকা/উপজেলা/জেলার নাম লিখুন...",
        className: "h-10 px-3 rounded-xl border border-slate-200 text-sm text-slate-800 focus:outline-none focus:ring-1 focus:ring-emerald-700",
      }),
      searchLoading &&
        /*#__PURE__*/React.createElement(
          "div",
          { className: "text-sm text-slate-500 flex items-center gap-1.5 px-1" },
          /*#__PURE__*/React.createElement(Loader2, { size: 12, className: "animate-spin" }),
          "খোঁজা হচ্ছে..."
        ),
      searchError && /*#__PURE__*/React.createElement("div", { className: "text-sm text-red-600 px-1" }, searchError),
      searchResults.length > 0 &&
        /*#__PURE__*/React.createElement(
          "div",
          { className: "flex flex-col gap-0.5 max-h-40 overflow-y-auto border border-slate-100 rounded-xl" },
          searchResults.map((r, i) =>
            /*#__PURE__*/React.createElement(
              "button",
              {
                key: i,
                type: "button",
                onClick: () => applyLocation(r),
                className: "text-left text-sm px-3 py-2 hover:bg-slate-50 border-b border-slate-50 last:border-b-0",
              },
              r.name
            )
          )
        ),
      /*#__PURE__*/React.createElement("div", { className: "text-xs text-slate-400 px-1" }, "অথবা জনপ্রিয় শহর:"),
      /*#__PURE__*/React.createElement(
        "div",
        { className: "flex flex-wrap gap-1.5" },
        MANUAL_LOCATIONS.map((loc) =>
          /*#__PURE__*/React.createElement(
            "button",
            {
              key: loc.id,
              type: "button",
              onClick: () => applyLocation({ lat: loc.lat, lon: loc.lon, name: loc.name, source: "manual" }),
              className: "px-2.5 py-1 rounded-lg bg-slate-50 border border-slate-200 text-sm text-emerald-900",
            },
            loc.name
          )
        )
      )
    );
  }

  // ---- শর্টকাট: কিবলা/মাসিক সূচি এই পেজের ভেতরেই খোলে, "← সময়সূচি" দিয়ে ফেরত ----
  if (sub) {
    const SubComp = sub === "qibla" ? Qibla : MonthlyPrayerSchedule;
    return /*#__PURE__*/React.createElement(
      "div",
      { className: "min-h-screen pb-24 bg-[#F4F7F1]" },
      /*#__PURE__*/React.createElement(
        "button",
        { type: "button", onClick: () => setSub(null), className: "flex items-center gap-1 px-4 pt-4 pb-2 text-sm font-semibold text-emerald-950" },
        /*#__PURE__*/React.createElement(ChevronLeft, { size: 16 }),
        "সময়সূচি"
      ),
      /*#__PURE__*/React.createElement(SubComp, null)
    );
  }

  // ---- Location সেটআপ এখনো করা হয়নি(প্রথমবার) ----
  if (!location) {
    return /*#__PURE__*/React.createElement(
      "div",
      { className: "min-h-screen pb-24 bg-[#F4F7F1] flex flex-col items-center justify-center px-6 text-center gap-4" },
      /*#__PURE__*/React.createElement(
        "div",
        { className: "text-lg font-semibold", style: { color: "var(--theme-primary, #0E4B43)", fontFamily: "'Noto Serif Bengali', serif" } },
        "সালাতের সময়সূচি দেখতে অবস্থান লাগবে"
      ),
      /*#__PURE__*/React.createElement("div", { className: "w-full max-w-xs" }, renderLocationPicker()),
      error && /*#__PURE__*/React.createElement("p", { className: "text-sm text-red-600 mt-1" }, error)
    );
  }

  // §সময়সূচি-কার্ডের ক্রম(owner-approved): layout = member.prayerLayout(শুধু মালিকের জন্য আসে); না থাকলে ডিফল্ট ক্রম।
  const sectionEls = {
    schedule: (
    // §Owner-instruction(৩১ অক্টোবর ২০২৬): কম্প্যাক্ট লেআউট — সালাতের সময়সূচি পূর্ণ-প্রস্থ,
    // নাম গাঢ়/সময় ওয়াক্ত-ভিত্তিক রঙিন; নিষিদ্ধ সময় আলাদা ৩-কলাম লাল-tint কার্ড।
    schedule &&
      /*#__PURE__*/React.createElement(
        "div",
        { className: "mx-4 mb-3", style: { filter: "drop-shadow(0 0 8px rgba(200,155,60,0.35))" } },
        waqtInfo && /*#__PURE__*/React.createElement(WaqtHero, { waqtInfo, now, waqtProgress }),
      /*#__PURE__*/React.createElement(
        "div",
        {
          className: "bg-white px-4 pt-3 pb-2 " + (waqtInfo ? "rounded-b-3xl" : "rounded-3xl"),
          style: { border: "1.5px solid #E3C26B", borderTop: waqtInfo ? "2px dashed #E3C26B" : "1.5px solid #E3C26B", marginTop: waqtInfo ? -1 : 0 },
        },
        /*#__PURE__*/React.createElement(
          "div",
          { className: "text-sm font-bold text-emerald-950 mb-1 flex items-center gap-1.5" },
          /*#__PURE__*/React.createElement(MosqueLineIcon, { size: 20, style: { color: "var(--theme-primary, #0E4B43)" } }),
          "সালাতের সময়সূচি"
        ),
        rows.map((r) =>
          /*#__PURE__*/React.createElement(
            "div",
            {
              key: r.key,
              className:
                "relative flex items-center gap-3 text-sm py-0.5 px-2 rounded-xl " +
                (waqtInfo && waqtInfo.currentKey === r.key
                  ? "bg-[#F3EEDD] font-bold"
                  : r.end && now >= r.end ? "opacity-60" : ""),
            },
            waqtInfo && waqtInfo.currentKey === r.key &&
              /*#__PURE__*/React.createElement("span", { className: "absolute left-0 top-2 bottom-2 w-1 rounded-full", style: { background: "#C89B3C" }, "aria-hidden": true }),
            /*#__PURE__*/React.createElement(WaqtIconChip, WAQT_CHIP[r.key]),
            /*#__PURE__*/React.createElement(
              "span",
              { className: "flex-1 text-slate-800 flex items-center gap-1.5" },
              r.label,
              waqtInfo && waqtInfo.currentKey === r.key &&
                /*#__PURE__*/React.createElement("span", { className: "text-[11px] font-bold text-white rounded-full px-1.5 py-[1px]", style: { background: "#C89B3C" } }, "এখন")
            ),
            /*#__PURE__*/React.createElement(
              "span",
              { className: "text-base font-semibold whitespace-nowrap text-slate-600", style: { fontFamily: "'Hind Siliguri', sans-serif" } },
              r.end ? `${formatHHMM(r.start)}–${formatHHMM(r.end)}` : formatHHMM(r.start)
            ),
            /*#__PURE__*/React.createElement(
              "button",
              {
                type: "button",
                onClick: () => toggleDone(r.key),
                "aria-label": `${r.label} পড়া হয়েছে`,
                "aria-pressed": !!doneToday[r.key],
                className: "shrink-0 w-8 h-7 -mr-1 flex items-center justify-center",
              },
              /*#__PURE__*/React.createElement(
                "span",
                {
                  className:
                    "w-[22px] h-[22px] rounded-full border-[1.5px] flex items-center justify-center text-xs leading-none text-white " +
                    (doneToday[r.key] ? "bg-emerald-900 border-emerald-900" : "border-slate-300"),
                },
                doneToday[r.key] ? "✓" : ""
              )
            )
          )
        )
      )
      )
    ),
    // §মসজিদের জামায়াত(owner-request ৩ নভেম্বর ২০২৬): per-device, ওয়াক্ত-হিসাবের উপর নির্ভর, নিজের এডিট-সুবিধা সহ।
    jamaat: schedule && /*#__PURE__*/React.createElement(JamaatCard, { schedule, now }),
    forbidden: (
    // §নিষিদ্ধ সময়(owner-instruction): লাল রঙে, একটাই লাইনে — ছোট ফোনে লাইন না ভেঙে পাশে স্ক্রল হয়।
    schedule &&
      /*#__PURE__*/React.createElement(
        "div",
        { className: "mx-4 mb-3 rounded-2xl px-3 py-2 border border-[#F2C6C0] flex items-center gap-3 overflow-x-auto", style: { background: "#FCEEEC", scrollbarWidth: "none" } },
        /*#__PURE__*/React.createElement("span", { className: "text-sm shrink-0", "aria-label": "নিষিদ্ধ সময়" }, "⛔"),
        forbiddenWindows.map((w) =>
          /*#__PURE__*/React.createElement(
            "span",
            { key: w.label, className: "text-[11px] whitespace-nowrap shrink-0" },
            /*#__PURE__*/React.createElement("span", { className: "text-slate-700" }, w.label + " "),
            /*#__PURE__*/React.createElement(
              "span",
              { className: "font-semibold", style: { fontFamily: "'Hind Siliguri', sans-serif", color: "#B42318" } },
              `${formatHHMM(w.start)}–${formatHHMM(w.end)}`
            )
          )
        )
      )
    ),
    other: (
    // §Owner-instruction: কলাপসিবল বাদ, সবসময় visible; নাম গাঢ়, dot+সময় আলাদা রঙে
    otherTimes &&
      /*#__PURE__*/React.createElement(
        "div",
        { className: "mx-4 mb-3 bg-white rounded-2xl border border-[#C89B3C]/50 shadow-[0_0_10px_rgba(200,155,60,0.35)] overflow-hidden" },
        /*#__PURE__*/React.createElement("div", { className: "px-4 pt-3 pb-2 text-sm font-bold text-emerald-950" }, "✨ অন্যান্য সালাত"),
        /*#__PURE__*/React.createElement(
          "div",
          { className: "px-4 pb-3 grid grid-cols-2 gap-x-4 gap-y-2" },
          OTHER_ITEMS.map((it) => {
            // §চলমান নফল সালাত হাইলাইট(১ নভেম্বর ২০২৬, owner-requested): ফরজ সারির মতোই
            // হালকা সোনালি ব্যাকগ্রাউন্ড+বাম-বার+গাঢ় নাম, শুধু `now` ও otherTimes-এর window থেকে
            // নির্ধারিত(কোনো নতুন state/data নয়)। তাহাজ্জুদ রাত পেরিয়ে ফজরে শেষ হয় — তাই
            // গতকালের window(-২৪ঘ)-ও যাচাই হয়, যাতে মধ্যরাতের পরেও হাইলাইট থাকে।
            const w = otherTimes[it.k];
            const DAY = 86400000;
            const active = !!(now && ((now >= w.start && now < w.end) ||
              (it.k === "tahajjud" && now.getTime() >= w.start.getTime() - DAY && now.getTime() < w.end.getTime() - DAY)));
            return /*#__PURE__*/React.createElement(
              "div",
              {
                key: it.k,
                className: "relative flex items-center justify-between gap-1 whitespace-nowrap rounded-xl px-2 py-1 -mx-2 " + (active ? "bg-[#F3EEDD] font-bold" : ""),
                "aria-current": active ? "true" : undefined
              },
              active && /*#__PURE__*/React.createElement("span", { className: "absolute left-0 top-1.5 bottom-1.5 w-1 rounded-full", style: { background: "#C89B3C" }, "aria-hidden": true }),
              /*#__PURE__*/React.createElement(
                "span",
                { className: "text-sm text-slate-800" },
                /*#__PURE__*/React.createElement("span", { style: { color: it.color } }, "● "),
                it.label
              ),
              /*#__PURE__*/React.createElement(
                "span",
                { className: "text-sm font-semibold text-slate-600" },
                `${formatHHMM(w.start)}–${formatHHMM(w.end)}`
              )
            );
          })
        )
      )
    ),
    meal: (
    // §সেহরি | ইফতার — কিবলা/মাসিক বোতামের ঠিক উপরে, নাম+সময় এক লাইনে
    schedule &&
      /*#__PURE__*/React.createElement(
        "div",
        { className: "mx-4 mb-3 grid grid-cols-2 gap-2" },
        /*#__PURE__*/React.createElement(
          "div",
          { className: "rounded-2xl px-3 py-4 flex items-center gap-2.5 border border-[#C5D4DD]", style: { background: "#E8EFF3" } },
          /*#__PURE__*/React.createElement("span", { className: "w-10 h-10 rounded-full bg-white flex items-center justify-center shrink-0" }, /*#__PURE__*/React.createElement(MoonStarIcon, { size: 24, style: { color: "#2C5F7C" } })),
          /*#__PURE__*/React.createElement(
            "div",
            { className: "leading-tight min-w-0" },
            /*#__PURE__*/React.createElement("div", { className: "text-sm text-[#2C4A5C]" }, "সেহরি"),
            /*#__PURE__*/React.createElement("div", { className: "text-base font-bold text-[#1F3A49] whitespace-nowrap" }, `ভোর ${formatHHMM(schedule.fajr)}`)
          )
        ),
        /*#__PURE__*/React.createElement(
          "div",
          { className: "rounded-2xl px-3 py-4 flex items-center gap-2.5 border border-[#EBCDA3]", style: { background: "#FBEFE0" } },
          /*#__PURE__*/React.createElement("span", { className: "w-10 h-10 rounded-full bg-white flex items-center justify-center shrink-0" }, /*#__PURE__*/React.createElement(SunsetIcon, { size: 24, style: { color: "#C0661B" } })),
          /*#__PURE__*/React.createElement(
            "div",
            { className: "leading-tight min-w-0" },
            /*#__PURE__*/React.createElement("div", { className: "text-sm text-[#7B4A12]" }, "ইফতার"),
            /*#__PURE__*/React.createElement("div", { className: "text-base font-bold text-[#5E370B] whitespace-nowrap" }, `সন্ধ্যা ${formatHHMM(schedule.maghrib)}`)
          )
        )
      )
    ),
    // ২ নভেম্বর ২০২৬(owner): "চলমান সালাত" কার্ড হোম থেকে এখানে; ডিফল্টে সবার নিচে, কাস্টমাইজে সরানো/লুকানো যায়।
    waqt: /*#__PURE__*/React.createElement(
      "div",
      { key: "waqt-amal", className: "mx-4 mb-3 bg-white rounded-2xl p-4 border border-[#E4D3A8] shadow-[0_3px_12px_-3px_rgba(160,120,40,0.25)]" },
      /*#__PURE__*/React.createElement(WaqtAmalCard, null)
    ),
  };
  // ক্রম+লুকানো: member.tabLayout(নতুন); না থাকলে পুরনো member.prayerLayout(ক্রম) fallback; দুটোই না থাকলে ডিফল্ট।
  const orderedSections = visibleIds("prayer", tabLayout, layout).map((k) => sectionEls[k]);

  return /*#__PURE__*/React.createElement(
    "div",
    { className: "min-h-screen pb-24 bg-[#F4F7F1]" },
    /*#__PURE__*/React.createElement(
      "div",
      { className: "px-4 pt-3 pb-1 flex items-start justify-between gap-2" },
      /*#__PURE__*/React.createElement(
        "div",
        null,
        /*#__PURE__*/React.createElement("div", { className: "text-sm font-bold text-emerald-950" }, formatGregorianDate(now)),
        /*#__PURE__*/React.createElement("div", { className: "text-[13px] font-medium text-emerald-800 whitespace-nowrap" }, formatHijriDate(now))
      ),
      /*#__PURE__*/React.createElement(
        "div",
        { className: "flex flex-row gap-1.5 items-center shrink-0" },
        // §GPS পিল — এখন ফিল্টার/সার্চ-সহ একই panel খোলে(owner-instruction: "জিপিএস
        // চিহ্নেই ফিল্টার অপশন যুক্ত করা হোক", আগে এটা সরাসরি GPS-detect ট্রিগার
        // করত, লোকেশন-রো থেকে আলাদা ছিল — এখন দুটোই একই একক panel-এ consolidate)।
        /*#__PURE__*/React.createElement(
          "button",
          {
            type: "button",
            onClick: () => {
              setLocationPanelOpen((v) => !v);
              setMadhabPanelOpen(false);
            },
            className:
              "text-xs px-2 py-1 whitespace-nowrap rounded-full bg-white border border-slate-200 shadow-sm flex items-center gap-1 " +
              (location.source === "gps" ? "text-emerald-700 font-bold" : "text-slate-500"),
          },
          /*#__PURE__*/React.createElement(GpsIcon, { size: 12 }),
          location.source === "gps" ? "GPS চালু" : "GPS"
        ),
        /*#__PURE__*/React.createElement(
          "div",
          { className: "relative" },
          /*#__PURE__*/React.createElement(
            "button",
            {
              type: "button",
              onClick: () => {
                setMadhabPanelOpen((v) => !v);
                setLocationPanelOpen(false);
              },
              className: "text-xs px-2 py-1 whitespace-nowrap rounded-full bg-white border border-slate-200 shadow-sm flex items-center gap-1 text-emerald-950",
            },
            /*#__PURE__*/React.createElement(MosqueLineIcon, { size: 13, style: { color: "var(--theme-primary, #0E4B43)" } }),
            madhab === 1 ? "হানাফী" : "অন্যান্য",
            /*#__PURE__*/React.createElement(ChevronDown, { size: 12 })
          ),
          madhabPanelOpen &&
            /*#__PURE__*/React.createElement(
              "div",
              { className: "absolute right-0 mt-1 w-32 bg-white rounded-xl shadow-md border border-slate-200 p-1 z-20" },
              /*#__PURE__*/React.createElement(
                "button",
                { type: "button", onClick: () => handleMadhabChange(1), className: "w-full text-left text-sm px-2 py-1.5 rounded-lg hover:bg-slate-50" },
                "হানাফী"
              ),
              /*#__PURE__*/React.createElement(
                "button",
                { type: "button", onClick: () => handleMadhabChange(0), className: "w-full text-left text-sm px-2 py-1.5 rounded-lg hover:bg-slate-50" },
                "অন্যান্য(শাফি/মালিকি/হাম্বলি)"
              )
            )
        )
      )
    ),
    // §Location row(owner-instruction, ১৯ সেপ্টেম্বর ২০২৬): এখন শুধু GPS-পিলে
    // ক্লিক করলেই panel খোলে(consolidated ট্রিগার একটাই); এই row এখন শুধু
    // নির্বাচিত এলাকার নাম দেখায়, ক্লিক-non-interactive(আগে দুই জায়গাতেই একই
    // panel খুলত যা বিভ্রান্তিকর ছিল)।
    // ২-লাইন প্রদর্শন(owner-instruction): নাম কমা দিয়ে split করে প্রথম অংশ(এলাকা)
    // বড়+বোল্ড লাইনে, বাকি অংশ(উপজেলা/জেলা) ছোট ধূসর লাইনে — যেমন "গুলশান" /
    // "ঢাকা"। কমা না থাকলে(যেমন quick-shortcut শহরের নাম) স্বাভাবিকভাবে এক-লাইনই থাকে।
    /*#__PURE__*/React.createElement(
      "div",
      { className: "px-4 pb-1.5 relative" },
      /*#__PURE__*/React.createElement(
        "div",
        { className: "flex items-start justify-between gap-2" },
        /*#__PURE__*/React.createElement(
          "div",
          { className: "min-w-0 flex-1 flex items-start" },
          /*#__PURE__*/React.createElement(
            "div",
            { className: "max-w-full flex items-center gap-1.5 py-1" },
            /*#__PURE__*/React.createElement(PinIcon, { size: 15, className: "text-emerald-800 shrink-0" }),
            /*#__PURE__*/React.createElement(
              "div",
              { className: "leading-tight min-w-0" },
              /*#__PURE__*/React.createElement("div", { className: "text-sm text-emerald-950 font-semibold truncate" }, (location.name || "").split(",")[0].trim()),
              (location.name || "").split(",").length > 1 &&
                /*#__PURE__*/React.createElement(
                  "div",
                  { className: "text-[11px] text-slate-500 truncate" },
                  (location.name || "").split(",").slice(1).join(",").trim()
                )
            )
          )
        ),
        /*#__PURE__*/React.createElement(
          "div",
          { className: "shrink-0 flex items-start gap-1.5" },
          location &&
            /*#__PURE__*/React.createElement(
              "button",
              {
                type: "button",
                onClick: handleRefresh,
                disabled: gpsBusy || loading,
                "aria-label": "রিফ্রেশ করুন",
                className: "bg-white rounded-xl border border-slate-200 px-2 py-1 text-[11px] font-semibold text-emerald-900 flex items-center gap-1 whitespace-nowrap shadow-sm active:opacity-60 disabled:opacity-70",
              },
              gpsBusy || loading
                ? /*#__PURE__*/React.createElement(Loader2, { size: 12, className: "animate-spin" })
                : /*#__PURE__*/React.createElement(RefreshIcon, { size: 12 }),
              gpsBusy || loading ? "আপডেট হচ্ছে…" : "রিফ্রেশ" + (syncedAt ? ` · ${formatHHMM(new Date(syncedAt))}` : "")
            ),
          /*#__PURE__*/React.createElement(
            "button",
            {
              type: "button",
              onClick: () => setSub("qibla"),
              "aria-label": "কিবলা দেখুন",
              className: "shrink-0 mt-0.5 bg-white rounded-xl border border-[#C89B3C]/60 px-2 py-1 text-[13px] font-bold text-emerald-900 flex items-center gap-1.5 whitespace-nowrap shadow-sm active:opacity-60",
            },
            "🧭 কিবলা"
          )
        )
      ),
      locationPanelOpen &&
        /*#__PURE__*/React.createElement(
          "div",
          { className: "absolute left-4 right-4 mt-2 bg-white rounded-2xl shadow-md border border-slate-200 p-3 z-20 max-h-[70vh] overflow-y-auto" },
          renderLocationPicker()
        )
    ),
    gpsBanner,
    gpsPopupEl,
    approximate &&
      /*#__PURE__*/React.createElement(
        "div",
        { className: "mx-4 mb-2 text-sm text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-1.5" },
        "⚠️ ইন্টারনেট সমস্যার কারণে আনুমানিক(পুরনো cache) সময় দেখানো হচ্ছে"
      ),
    error &&
      !timings &&
      /*#__PURE__*/React.createElement(
        "div",
        { className: "mx-4 mb-2 text-sm text-red-700 bg-red-50 border border-red-200 rounded-lg px-3 py-1.5" },
        error
      ),
    loading &&
      !timings &&
      /*#__PURE__*/React.createElement(
        "div",
        { className: "mx-4 mb-2 rounded-2xl min-h-[92px] bg-slate-200/70 animate-pulse flex items-center justify-center text-sm text-slate-500 gap-1.5" },
        /*#__PURE__*/React.createElement(Loader2, { size: 14, className: "animate-spin" }),
        "সময়সূচি আনা হচ্ছে..."
      ),
    activeForbidden &&
      /*#__PURE__*/React.createElement(
        "div",
        { role: "status", className: "mx-4 mb-2 text-sm text-red-700 bg-red-50 border border-dashed border-red-300 rounded-xl px-3 py-1.5 flex items-center gap-1.5" },
        "⛔",
        /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("b", null, `এখন নিষিদ্ধ সময়: ${activeForbidden.label}`), ` · ${formatHHMM(activeForbidden.end)} পর্যন্ত নামাজ নয়`)
      ),
    // §রমজান সেহরি/ইফতার countdown(schema উপরে, isRamadan true হলেই সক্রিয় —
    // এখন hijri মাস রমজান না বলে null, কিছুই render হয় না)। ভিন্ন gradient(সোনালী/
    // বেগুনি) দিয়ে মূল ওয়াক্ত-banner থেকে visually আলাদা রাখা হয়েছে।
    ramadanCountdown &&
      /*#__PURE__*/React.createElement(
        "div",
        {
          className: "mx-4 mb-2 rounded-2xl px-3 py-2 text-white shadow-sm relative overflow-hidden flex items-center justify-between gap-2 border border-[#C89B3C]/60 shadow-[0_0_12px_rgba(200,155,60,0.4)]",
          style: { background: "linear-gradient(135deg, #4A2E6B, #2B1A45)" },
        },
        /*#__PURE__*/React.createElement("span", { className: "relative text-sm opacity-90" }, `🌙 রমজান · ${ramadanCountdown.label}`),
        /*#__PURE__*/React.createElement(
          "span",
          { className: "relative text-xl font-bold tracking-wide whitespace-nowrap", style: { fontFamily: "'Hind Siliguri', sans-serif" } },
          formatCountdown(ramadanCountdown.target.getTime() - now.getTime())
        )
      ),
    ...orderedSections
  );
}
