// reviewMonthly.js — মাসিক মুহাসাবা রিপোর্টের হিসাব। Pure (Firebase/UI/অ্যাপ-হেল্পার import ছাড়া)।
// অ্যাপের হিসাব-ফাংশনগুলো h (helpers) হিসেবে ঢোকানো হয়, তাই Node-এ সরাসরি টেস্ট করা যায়।
// সব সংখ্যা পূর্ণসংখ্যা; কোনো .limit() নেই। চলতি মাস চলমান হলে আগের মাসের সাথে একই দিন-সংখ্যার তুলনা হয়।
import { chunkCount, chunkRange } from "./reviewSchema.js";
import { weekdayAverages, weakestWeekdays, bestImprovementAndDrop, rankMoves, goalSuccess, monthDelta, weeklyGap } from "./reviewCalc.js";

const MIN_DAYS = 3; // এর কম দিনের ডেটায় কোনো সিদ্ধান্তমূলক হিসাব দেখানো হয় না
const SLEEP_KEY = "phoneOffBy11";
const GOAL_VALUES = ["done", "partial", "none"];

const pad2 = n => String(n).padStart(2, "0");
const daysIn = (y, m0) => new Date(y, m0 + 1, 0).getDate();
const labelOf = f => ((f.shortLabel ? String(f.shortLabel).trim() : "") || f.label || f.key);

function prevMonthOf(year, month0) {
  return month0 === 0 ? { year: year - 1, month0: 11 } : { year, month0: month0 - 1 };
}

// মাসের কত দিন পেরিয়েছে: ভবিষ্যৎ মাস ⇒ 0, চলতি মাস ⇒ আজকের তারিখ, অতীত মাস ⇒ পুরো মাস।
function elapsedDays(year, month0, now) {
  const total = daysIn(year, month0);
  const cur = now.getFullYear() * 12 + now.getMonth();
  const asked = year * 12 + month0;
  if (asked > cur) return 0;
  if (asked === cur) return Math.min(now.getDate(), total);
  return total;
}

function fill(str, vars) {
  return String(str).replace(/\{(\w+)\}/g, (m, k) => (vars && vars[k] !== undefined ? vars[k] : m));
}

// entries: { "01": entry, ... } ⇒ [{ day, score(0..1) }] (এন্ট্রি ও স্কোর আছে এমন দিন, 1..upTo)
function dayScores(entries, upTo, h, fields) {
  const out = [];
  for (let d = 1; d <= upTo; d++) {
    const e = entries ? entries[pad2(d)] : null;
    if (!e) continue;
    const s = h.dailyScore(e, h.member, fields || h.allFields);
    if (s === null || s === undefined || !Number.isFinite(s)) continue;
    out.push({ day: d, score: s });
  }
  return out;
}
const avgPct = rows => (rows.length ? Math.round((rows.reduce((t, r) => t + r.score, 0) / rows.length) * 100) : null);

// একটা ফিল্ডে "পুরো সম্পন্ন" (ratio ≥ 1) দিনের সংখ্যা। ওজরের দিন গণনার বাইরে, তবে সংখ্যাটা excused-এ ফেরত যায়।
function fullDays(entries, upTo, f, h) {
  let n = 0, logged = 0, excused = 0;
  const ex = h.isFieldExcusable(f, h.member);
  for (let d = 1; d <= upTo; d++) {
    const e = entries ? entries[pad2(d)] : null;
    if (!e) continue;
    if (ex && h.isExcused(e, f.key)) { excused += 1; continue; }
    const r = h.ratioOf(f, e);
    if (r === null || r === undefined || !Number.isFinite(r)) continue;
    logged += 1;
    if (r >= 1) n += 1;
  }
  return { n, logged, excused };
}

// h = { member, allFields, fieldApplies, isExcused, isFieldExcusable, dailyScore, ratioOf }
// prevEntries: আগের মাসের এন্ট্রি-ম্যাপ, না পাওয়া গেলে null (তখন তুলনা বাদ, বাকিটা চলে)।
function buildMonthlyReport({ year, month0, now, curEntries, prevEntries, h }) {
  const total = daysIn(year, month0);
  const elapsed = elapsedDays(year, month0, now);
  const partial = elapsed < total;
  const rows = dayScores(curEntries, elapsed, h);
  if (rows.length < MIN_DAYS) return { ok: false, filled: rows.length, elapsed, total };

  const p = prevMonthOf(year, month0);
  const prevTotal = daysIn(p.year, p.month0);
  const cmp = Math.min(elapsed, prevTotal); // একই দিন-সংখ্যার জানালা (চলমান মাসে ন্যায্য তুলনার জন্য)
  const applicable = h.allFields.filter(f => f.key && h.fieldApplies(f, h.member));

  const avg = avgPct(rows);
  let prev = null;
  if (prevEntries) {
    const prevRows = dayScores(prevEntries, partial ? cmp : prevTotal, h);
    if (prevRows.length >= MIN_DAYS) prev = { year: p.year, month0: p.month0, avg: avgPct(prevRows), filled: prevRows.length };
  }
  const delta = prev ? monthDelta(prev.avg, avg) : null;

  // সপ্তাহ ধরে গড় (শুধু শুরু হয়ে যাওয়া সপ্তাহ)
  const weeks = [];
  for (let w = 1; w <= chunkCount(year, month0); w++) {
    const r = chunkRange(year, month0, w);
    if (r.start > elapsed) break;
    const wr = rows.filter(x => x.day >= r.start && x.day <= r.end);
    weeks.push({ week: w, count: wr.length, avg: wr.length ? avgPct(wr) : null });
  }
  while (weeks.length && weeks[weeks.length - 1].avg === null) weeks.pop(); // শেষের ফাঁকা সপ্তাহ নয় (মাঝের ফাঁক থাকে)

  // বার অনুযায়ী গড়
  const scores = rows.map(r => ({ date: `${year}-${pad2(month0 + 1)}-${pad2(r.day)}`, score: Math.round(r.score * 100) }));
  const weekdays = weekdayAverages(scores);
  const weekdayValid = weekdays.filter(a => a.avg !== null).length;
  const weakest = weekdayValid >= 3 ? weakestWeekdays(weekdays, 2) : [];

  // উন্নতি/পতন: দুই মাসের "পুরো সম্পন্ন" দিন। ওজর থাকলে বা ডেটা কম হলে সেই ফিল্ড বাদ (অন্যায্য তুলনা এড়াতে)।
  let moves = { improvement: null, drop: null, ups: [], downs: [], same: [] };
  if (prevEntries) {
    const items = [];
    for (const f of applicable) {
      const a = fullDays(curEntries, cmp, f, h);
      const b = fullDays(prevEntries, cmp, f, h);
      if (a.excused || b.excused || a.logged < MIN_DAYS || b.logged < MIN_DAYS) continue;
      items.push({ key: f.key, prev: b.n, cur: a.n });
    }
    const r = bestImprovementAndDrop(items);
    const withLabel = x => (x ? { ...x, label: labelOf(applicable.find(f => f.key === x.key)) } : null);
    // ups/downs/same: জোড়া-বার কার্ডের জন্য সব তুলনা (সংযোজন; improvement/drop আগের মতোই)
    const rk = rankMoves(items);
    moves = { improvement: withLabel(r.improvement), drop: withLabel(r.drop), ups: rk.ups.map(withLabel), downs: rk.downs.map(withLabel), same: rk.same.map(withLabel) };
  }

  // "কখন ভালো থাকেন": কোন আমল পূর্ণ করা দিনগুলোতে বাকি আমলের স্কোর সবচেয়ে বেশি থাকে।
  // আগে শুধু "ঘুমের আগে ফোন বন্ধ" দেখা হতো; এখন সেটা অগ্রাধিকার পায়, শর্ত না মিললে বাকি আমল থেকে সবচেয়ে বড় পার্থক্যেরটা।
  // সম্পর্ক মাত্র, কারণ নয়। দুই দলেই ≥৩ দিন ও ≥৫ পয়েন্ট পার্থক্য না হলে null।
  const whenGoodFor = (f, isYes) => {
    const rest = h.allFields.filter(x => x.key !== f.key);
    const yes = [], no = [];
    for (let d = 1; d <= elapsed; d++) {
      const e = curEntries ? curEntries[pad2(d)] : null;
      if (!e) continue;
      if (f.key !== SLEEP_KEY && h.isFieldExcusable(f, h.member) && h.isExcused(e, f.key)) continue;
      const s = h.dailyScore(e, h.member, rest);
      if (s === null || s === undefined || !Number.isFinite(s)) continue;
      const flag = isYes(e);
      if (flag === null) continue;
      (flag ? yes : no).push({ score: s });
    }
    if (yes.length < MIN_DAYS || no.length < MIN_DAYS) return null;
    const diff = avgPct(yes) - avgPct(no);
    return diff >= 5 ? { key: f.key, label: labelOf(f), diff, yesN: yes.length, noN: no.length } : null;
  };
  let whenGood = null;
  const sf = applicable.find(f => f.key === SLEEP_KEY);
  if (sf) whenGood = whenGoodFor(sf, e => !!e[SLEEP_KEY]);
  if (!whenGood) {
    for (const f of applicable) {
      if (f.key === SLEEP_KEY) continue;
      const c = whenGoodFor(f, e => {
        const r = h.ratioOf(f, e);
        return r === null || r === undefined || !Number.isFinite(r) ? null : r >= 1;
      });
      if (c && (!whenGood || c.diff > whenGood.diff)) whenGood = c;
    }
  }

  // প্রস্তাবের ফলব্যাক: এ মাসে সবচেয়ে বেশি দিন ছুটে যাওয়া আমল
  const gapDays = [];
  for (let d = 1; d <= elapsed; d++) gapDays.push({ day: d, entry: curEntries ? curEntries[pad2(d)] || null : null });
  const gaps = weeklyGap({
    days: gapDays, fields: applicable, ratioOf: h.ratioOf, applies: () => true,
    excused: (f, e) => h.isFieldExcusable(f, h.member) && h.isExcused(e, f.key)
  });
  const topGap = gaps[0] ? { ...gaps[0], label: labelOf(applicable.find(f => f.key === gaps[0].key)) } : null;

  return { ok: true, year, month0, total, elapsed, cmp, partial, filled: rows.length, avg, prev, delta, weeks, weekdays, weekdayValid, weakest, moves, whenGood, topGap };
}

// reviews: [{ weekKey, goalResult }] ⇒ সপ্তাহ-ক্রমে ফল ও গণনা। অজানা মান গোনা হয় না।
function goalSummary(reviews) {
  const seq = (reviews || [])
    .filter(r => r && GOAL_VALUES.includes(r.goalResult))
    .sort((a, b) => (a.weekKey < b.weekKey ? -1 : a.weekKey > b.weekKey ? 1 : 0))
    .map(r => r.goalResult);
  return { seq, counts: goalSuccess(seq) };
}

// ডেটা থেকে সর্বোচ্চ ৩টা সিদ্ধান্তের প্রস্তাব: [{ id, text }]। ব্যক্তিগত মুহাসাবার (reviews) কোনো লেখা এখানে ঢোকে না।
// o = { text (reviewText.monthly.decisions), toBn, weekdayNames }
function suggestDecisions(report, o) {
  const out = [];
  if (!report || !report.ok) return out;
  const T = o.text;
  const m = report.moves || {};
  if (m.drop) {
    out.push({ id: "drop", text: report.partial
      ? fill(T.dropPartial, { label: m.drop.label })
      : fill(T.drop, { label: m.drop.label, cur: o.toBn(m.drop.cur), prev: o.toBn(m.drop.prev) }) });
  } else if (report.topGap) {
    out.push({ id: "gap", text: fill(T.gap, { label: report.topGap.label, n: o.toBn(report.topGap.missed) }) });
  }
  if (report.weakest && report.weakest.length) {
    out.push({ id: "weekday", text: fill(T.weekday, { days: report.weakest.map(i => o.weekdayNames[i]).join(" ও ") }) });
  }
  if (m.improvement) out.push({ id: "keep", text: fill(T.keep, { label: m.improvement.label }) });
  // বাড়তি প্রস্তাব (সবই নিজের ডেটা থেকে; ব্যক্তিগত মুহাসাবার লেখা নয়)
  if (m.drop && report.topGap && report.topGap.key !== m.drop.key) out.push({ id: "gap", text: fill(T.gap, { label: report.topGap.label, n: o.toBn(report.topGap.missed) }) });
  if (report.whenGood) out.push({ id: "phone", text: fill(T.phone, { label: report.whenGood.label }) });
  if (Number.isFinite(report.avg)) {
    if (report.prev && report.delta !== null && report.delta < 0) out.push({ id: "restore", text: fill(T.restore, { n: o.toBn(report.prev.avg) }) });
    else if (report.avg < 95) out.push({ id: "target", text: fill(T.target, { n: o.toBn(Math.min(100, report.avg + 5)) }) });
  }
  if (o.goalNone > 0 || o.goalTotal === 0) out.push({ id: "goal", text: T.goal });
  return out.slice(0, 5);
}

export { MIN_DAYS, SLEEP_KEY, prevMonthOf, elapsedDays, fill, buildMonthlyReport, goalSummary, suggestDecisions };
