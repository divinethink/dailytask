// JamaatCard.jsx — "সময়সূচি" ট্যাবের "মসজিদের জামায়াত" কার্ড (owner-request ৩ নভেম্বর ২০২৬)।
// শুধু এই ডিভাইসের localStorage(legacy/jamaatTimes.js); Firestore/Rules কিছু নেই। ওয়াক্ত-হিসাব (schedule) বাইরে থেকে আসে।
// জামায়াতের সময় অটো (সূর্যোদয়/সূর্যাস্ত/ওয়াক্ত-শুরু ± মিনিট) বা হাতে-বসানো (fixed); মিলে না গেলে Owner ঠিক করতে পারেন।
// React global(window.React, globals.js)।
import { toBn } from "../../legacy/appHelpers.js";
import { MosqueIcon, EditIcon } from "../icons.jsx";
import {
  JAMAAT_KEYS,
  JAMAAT_LABEL,
  BASES,
  SUGGESTED,
  loadJamaat,
  saveJamaat,
  clearJamaat,
  resolveJamaat,
  nextJamaatKey,
  isStale,
} from "../../legacy/jamaatTimes.js";

const { useState, useMemo } = React;
const h = React.createElement;

function fmt(d) {
  if (!d) return "--:--";
  const hr = d.getHours() % 12 || 12;
  return `${toBn(hr)}:${toBn(String(d.getMinutes()).padStart(2, "0"))}`;
}
function toHHMM(d) {
  return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}
function gapText(min) {
  const sign = min < 0 ? "−" : "+";
  const a = Math.abs(min);
  const hh = Math.floor(a / 60);
  const mm = a % 60;
  return `${sign}${hh ? toBn(hh) + " ঘ " : ""}${toBn(mm)} মি`;
}
function leftText(ms) {
  const m = Math.max(0, Math.ceil(ms / 60000));
  const hh = Math.floor(m / 60);
  return `${hh ? toBn(hh) + " ঘ " : ""}${toBn(m % 60)} মি বাকি`;
}

const FIELD = "border border-slate-300 rounded-lg px-2 text-sm bg-white min-h-[44px]";
const BTN = "rounded-xl px-4 min-h-[44px] text-sm font-bold";
const TIME_COLOR = { fajr: "#185FA5", dhuhr: "#0E4B43", asr: "#B3610E", maghrib: "#B23A25", isha: "#4B4FA8" };
const SOFT = { background: "var(--theme-soft, #E8F0EE)", color: "var(--theme-primary, #0E4B43)" };

// হোম/মেনুর ধাঁচের আইকন-চিপ: বামে মসজিদ, ডানে এডিট (MenuPage-এর w-10 h-10 rounded-xl)
function Header({ title, sub, onEdit }) {
  return h(
    "div",
    { className: "flex items-center gap-3" },
    h("span", { className: "w-10 h-10 rounded-xl flex items-center justify-center shrink-0", style: SOFT }, h(MosqueIcon, { size: 20 })),
    h(
      "div",
      { className: "min-w-0 flex-1 leading-tight" },
      h("div", { className: "text-sm font-bold text-emerald-950" }, title),
      sub && h("div", { className: "text-xs text-slate-500 truncate mt-0.5" }, sub)
    ),
    onEdit &&
      h(
        "button",
        { type: "button", onClick: onEdit, "aria-label": "জামায়াতের সময় এডিট", className: "w-10 h-10 rounded-xl flex items-center justify-center shrink-0 active:scale-95 transition-transform", style: SOFT },
        h(EditIcon, { size: 16 })
      )
  );
}

export function JamaatCard({ schedule, now }) {
  const [cfg, setCfg] = useState(() => loadJamaat());
  const [draft, setDraft] = useState(null); // null = দেখার মোড

  const rows = useMemo(() => (cfg && schedule ? resolveJamaat(cfg, schedule, now) : []), [cfg, schedule, now]);
  const nextKey = rows.length ? nextJamaatKey(rows, now) : null;
  const draftRows = useMemo(() => (draft && schedule ? resolveJamaat(draft, schedule, now) : []), [draft, schedule, now]);

  function openEditor() {
    setDraft(cfg || { mosque: "", rules: JSON.parse(JSON.stringify(SUGGESTED.rules)), jumuah: SUGGESTED.jumuah, roundTo: SUGGESTED.roundTo });
  }
  function setRule(k, patch) {
    setDraft((d) => ({ ...d, rules: { ...d.rules, [k]: { ...d.rules[k], ...patch } } }));
  }
  function switchMode(k, mode) {
    const cur = draftRows.find((r) => r.key === k);
    // অটো → নির্দিষ্ট: এখনকার হিসাব-করা সময়ই শুরুর মান, যাতে শুধু মিনিট ঠিক করলেই হয়
    setRule(k, mode === "fixed" && cur ? { mode, fixed: toHHMM(cur.time) } : { mode });
  }
  function onSave() {
    const saved = saveJamaat(draft);
    if (saved) setCfg(saved);
    setDraft(null);
  }
  function onClear() {
    clearJamaat();
    setCfg(null);
    setDraft(null);
  }

  const shell = (children) =>
    h("div", { className: "mx-4 mb-3 bg-white rounded-3xl border border-[#E3C26B] shadow-[0_0_10px_rgba(200,155,60,0.3)] overflow-hidden" }, children);

  if (!schedule) return null;

  // ---- এডিট মোড (কম্প্যাক্ট) ----
  if (draft) {
    return shell(
      h(
        "div",
        { className: "px-4 pt-3 pb-3" },
        h(Header, { title: "জামায়াতের সময় ঠিক করুন" }),
        h("input", {
          type: "text",
          value: draft.mosque,
          maxLength: 60,
          placeholder: "মসজিদের নাম (ঐচ্ছিক)",
          "aria-label": "মসজিদের নাম",
          onChange: (e) => setDraft({ ...draft, mosque: e.target.value }),
          className: FIELD + " w-full mt-3",
        }),
        JAMAAT_KEYS.map((k) => {
          const r = draft.rules[k];
          const pv = draftRows.find((x) => x.key === k);
          return h(
            "div",
            { key: k, className: "mt-2 rounded-2xl bg-slate-50 px-3 py-2" },
            h(
              "div",
              { className: "flex items-center justify-between gap-2" },
              h("span", { className: "text-sm font-bold", style: { color: TIME_COLOR[k] } }, JAMAAT_LABEL[k]),
              pv &&
                h(
                  "span",
                  { className: "text-xs " + (pv.warn ? "text-red-700" : "text-slate-500"), style: { fontFamily: "'Hind Siliguri', sans-serif" } },
                  `${fmt(pv.time)} · ${gapText(pv.gapMin)}` + (pv.warn ? " · ⚠ " + pv.warn : "")
                ),
              h(
                "div",
                { className: "flex rounded-lg overflow-hidden border border-slate-300 bg-white", role: "group", "aria-label": JAMAAT_LABEL[k] + " পদ্ধতি" },
                ["auto", "fixed"].map((m) =>
                  h(
                    "button",
                    {
                      key: m,
                      type: "button",
                      onClick: () => switchMode(k, m),
                      "aria-pressed": r.mode === m,
                      className: "px-3 min-h-[44px] text-xs font-bold " + (r.mode === m ? "bg-emerald-900 text-white" : "text-slate-600"),
                    },
                    m === "auto" ? "অটো" : "নির্দিষ্ট"
                  )
                )
              )
            ),
            r.mode === "fixed"
              ? h("input", {
                  type: "time",
                  value: r.fixed,
                  "aria-label": JAMAAT_LABEL[k] + " জামায়াতের সময়",
                  onChange: (e) => e.target.value && setRule(k, { fixed: e.target.value }),
                  className: FIELD + " mt-1.5 w-full",
                })
              : h(
                  "div",
                  { className: "flex items-center gap-2 mt-1.5" },
                  h(
                    "select",
                    {
                      value: r.base,
                      "aria-label": JAMAAT_LABEL[k] + " ভিত্তি",
                      onChange: (e) => setRule(k, { base: e.target.value }),
                      className: FIELD + " flex-1 min-w-0",
                    },
                    Object.keys(BASES).map((b) => h("option", { key: b, value: b }, BASES[b]))
                  ),
                  h("input", {
                    type: "number",
                    inputMode: "numeric",
                    min: -240,
                    max: 240,
                    value: r.offset,
                    "aria-label": JAMAAT_LABEL[k] + " মিনিট ফারাক",
                    onChange: (e) => setRule(k, { offset: e.target.value === "" ? 0 : Number(e.target.value) }),
                    className: FIELD + " w-20 text-center",
                  }),
                  h("span", { className: "text-xs text-slate-500 shrink-0" }, "মি (−=আগে)")
                )
          );
        }),
        h(
          "div",
          { className: "mt-2 rounded-2xl bg-slate-50 px-3 py-2 flex items-center justify-between gap-2" },
          h("span", { className: "text-sm font-bold text-emerald-950" }, "জুমা (শুক্রবার)"),
          h("input", {
            type: "time",
            value: draft.jumuah,
            "aria-label": "জুমার জামায়াতের সময়",
            onChange: (e) => e.target.value && setDraft({ ...draft, jumuah: e.target.value }),
            className: FIELD,
          })
        ),
        h(
          "label",
          { className: "flex items-center gap-2 mt-1 min-h-[44px] text-xs text-slate-600" },
          h("input", { type: "checkbox", checked: draft.roundTo === 5, onChange: (e) => setDraft({ ...draft, roundTo: e.target.checked ? 5 : 0 }), className: "w-5 h-5" }),
          "অটো সময় ৫ মিনিটে মিলিয়ে নিন"
        ),
        h(
          "div",
          { className: "flex gap-2" },
          h("button", { type: "button", onClick: onSave, className: BTN + " flex-1 bg-emerald-900 text-white" }, "সংরক্ষণ"),
          h("button", { type: "button", onClick: () => setDraft(null), className: BTN + " bg-slate-100 text-slate-700" }, "বাতিল"),
          cfg && h("button", { type: "button", onClick: onClear, className: BTN + " bg-red-50 text-red-700" }, "মুছুন")
        )
      )
    );
  }

  // ---- না-সেট মোড ----
  if (!cfg) {
    return shell(
      h(
        "div",
        { className: "px-4 py-3 flex items-center gap-3" },
        h(Header, { title: "মসজিদে জামায়াতের সময়সূচি", sub: "আপনার মসজিদের জামায়াতের সময় রাখুন" }),
        h("button", { type: "button", onClick: openEditor, className: BTN + " bg-emerald-900 text-white shrink-0" }, "সেট করুন")
      )
    );
  }

  // ---- দেখার মোড ----
  const stale = isStale(cfg, now.getTime());
  return shell(
    h(
      "div",
      { className: "px-4 pt-3 pb-3" },
      h(Header, { title: "মসজিদে জামায়াতের সময়সূচি", sub: cfg.mosque, onEdit: openEditor }),
      h(
        "div",
        { className: "mt-2" },
        rows.map((r) => {
          const isNext = r.key === nextKey;
          return h(
            "div",
            {
              key: r.key,
              className: "relative flex items-center gap-2 text-sm py-1.5 px-2 rounded-xl " + (isNext ? "bg-[#F3EEDD]" : r.time < now ? "opacity-60" : ""),
              "aria-current": isNext ? "true" : undefined,
            },
            isNext && h("span", { className: "absolute left-0 top-2 bottom-2 w-1 rounded-full", style: { background: "#C89B3C" }, "aria-hidden": true }),
            h("span", { className: "w-2 h-2 rounded-full shrink-0", style: { background: TIME_COLOR[r.key] }, "aria-hidden": true }),
            h(
              "div",
              { className: "flex-1 min-w-0 leading-tight" },
              h(
                "div",
                { className: "flex items-center gap-1.5 " + (isNext ? "font-bold" : "font-semibold") + " text-slate-800" },
                r.label,
                isNext && h("span", { className: "text-[11px] font-bold text-white rounded-full px-1.5 py-[1px]", style: { background: "#C89B3C" } }, "পরবর্তী")
              ),
              isNext && h("div", { className: "text-[11px] text-slate-500" }, leftText(r.time - now)),
              r.warn && h("div", { className: "text-[11px] text-red-700" }, "⚠ " + r.warn)
            ),
            h("span", { className: "text-[11px] text-slate-500 bg-slate-100 rounded-full px-2 py-0.5 whitespace-nowrap" }, gapText(r.gapMin)),
            h("span", { className: "text-base font-bold whitespace-nowrap w-14 text-right", style: { fontFamily: "'Hind Siliguri', sans-serif", color: TIME_COLOR[r.key] } }, fmt(r.time))
          );
        })
      ),
      h(
        "div",
        { className: "text-[11px] text-slate-400 mt-1.5 px-2" },
        "ধূসর +মি = ওয়াক্ত শুরুর কত পরে জামায়াত" + (stale ? " · ⚠ অনেক দিন আগে সেট করা, মসজিদের সময় মিলিয়ে নিন" : "")
      )
    )
  );
}
