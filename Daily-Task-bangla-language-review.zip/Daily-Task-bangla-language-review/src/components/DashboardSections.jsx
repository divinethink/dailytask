// A4-G6-Part C — Dashboard secondary sections: Weekly Reflection, Monthly
// Overview, Meeting Minutes, and small inline modals (Delete-Account-Warning,
// Add-Custom-Field, Feedback, Milestone-Toast).
// Extracted verbatim from legacy App() (app.js lines ~7235-7722, scattered).
// Structural-only (Owner Rule 2): no logic/condition change, only moved to its
// own file + split into named exports.
// [৮ সেপ্টেম্বর ২০২৬] Chart.js-ভিত্তিক ProgressChart(সাপ্তাহিক লাইন-গ্রাফ)
// সরিয়ে StreakCard দিয়ে প্রতিস্থাপন করা হয়েছে (owner-approved, নিচে দ্রষ্টব্য)।
import { InfoIcon, Loader2, Plus, Trash, RefreshIcon, CalIcon, ChevronLeft, ChevronRight, ChevronDown, Printer, MessageSquare, X } from "./icons.jsx";

// React itself is a true runtime global (established pattern — no file in this
// codebase imports it). app.js locally destructures hooks from it the same way.
const { useState } = React;

// StreakCard — ProgressChart(Chart.js লাইন-গ্রাফ)-এর প্রতিস্থাপন (৮ সেপ্টেম্বর
// ২০২৬, owner-approved: "গ্রাফ কাজে লাগছে না, আগ্রহ তৈরি হয় এমন কিছু আনা
// হোক")। কোনো নতুন calculation লাগেনি — `calculateStreak()`(appHelpers.js)
// আগে থেকেই তৈরি ও app.js-এ প্রতি রেন্ডারে গণনা হচ্ছিল, শুধু এতদিন কোথাও
// প্রধানভাবে দেখানো হতো না (শুধু Profile-dropdown-এর ভিতরে ছিল)। Milestone
// (৭/৩০/১০০/৩৬৫ দিন) toast system-ও আগে থেকেই আছে, অপরিবর্তিত।
// §Dashboard redesign(১৭ সেপ্টেম্বর ২০২৬, owner-approved): streak-সংখ্যা এখন
// DashboardHeader.jsx-এর compact chip-এ (bell-এর পাশে) দেখানো হয় — তাই এই
// component থেকে বড় streak-box সরিয়ে শুধু "আজকের অগ্রগতি" এক-লাইন compact
// row রাখা হলো (component/prop-নাম অপরিবর্তিত রাখা হয়েছে, শুধু presentation)।
// yesterdayPercent(নতুন, ঐচ্ছিক prop) দিলে গতকালের তুলনায় বৃদ্ধি/হ্রাস দেখাবে —
// app.js-এর call-site-এ একই মাসের ভিতরে (cross-month fetch ছাড়াই) নিরাপদে
// derive করা হয়েছে, না মিললে (যেমন মাসের ১ তারিখ) silently বাদ যায়।
export function StreakCard({ streak, toBn, mode, primaryPercent, comparisonPercent }) {
  if (primaryPercent === null || primaryPercent === undefined) return null;
  const hasDelta = comparisonPercent !== null && comparisonPercent !== undefined;
  const delta = hasDelta ? primaryPercent - comparisonPercent : null;
  // §Stable card(১৯ সেপ্টেম্বর ২০২৬, owner-রিপোর্টেড): রাত ১২টার পর আজকের
  // এন্ট্রি এখনো না থাকলে card পুরোপুরি অদৃশ্য না হয়ে "গতকালের অগ্রগতি"-তে
  // fallback করে (call-site/app.js-এ mode নির্ধারিত হয়) — লেবেল/তুলনা-টেক্সট
  // mode অনুযায়ী বদলায়, বাকি presentation অপরিবর্তিত।
  const label = mode === "yesterday" ? "গতকালের অগ্রগতি:" : "আজকের অগ্রগতি:";
  const deltaPrefix = mode === "yesterday" ? "· আগের দিনের চেয়ে " : "· গতকালের চেয়ে ";
  // §১-লাইন ফিক্স (১৯ সেপ্টেম্বর ২০২৬, owner-রিপোর্টেড): "গতকালের অগ্রগতি:"
  // লেবেল "আজকের অগ্রগতি:"-এর চেয়ে লম্বা বলে ছোট স্ক্রিনে flex-wrap হয়ে ২য়
  // লাইনে চলে যেত (device/font-scale-নির্ভর, unpredictable)। Fix: ফন্ট/গ্যাপ
  // ছোট করে + flex-nowrap দিয়ে সবসময় ১-লাইনে রাখা হলো; overflow-x-auto শুধু
  // চরম extreme-zoom edge-case-এর জন্য safety-net(স্বাভাবিক অবস্থায় কখনো
  // scroll লাগবে না, clip/hidden-content-এর চেয়ে নিরাপদ ফলব্যাক)।
  return /*#__PURE__*/React.createElement("div", {
    className: "w-full mt-2 rounded-xl bg-[#f0ede4] border border-[#d9d2bd] px-4 py-3 flex items-center justify-center flex-nowrap overflow-x-auto gap-x-1.5 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
  }, /*#__PURE__*/React.createElement("span", {
    className: "text-sm font-bold text-emerald-900 flex-shrink-0"
  }, label), /*#__PURE__*/React.createElement("span", {
    className: "text-sm font-bold text-emerald-900 flex-shrink-0",
    style: { fontFamily: "'IBM Plex Mono', 'Hind Siliguri', monospace" }
  }, toBn(primaryPercent), "%"), hasDelta && /*#__PURE__*/React.createElement("span", {
    className: (delta >= 0 ? "text-emerald-700" : "text-red-700") + " text-xs font-medium whitespace-nowrap flex-shrink-0"
  }, deltaPrefix, toBn(Math.abs(delta)), "% ", delta >= 0 ? "বেশি ↑" : "কম ↓"));
}

// hex রঙ হালকা/গাঢ় করে (percent: ধনাত্মক=হালকা, ঋণাত্মক=গাঢ়) — gradient/3D-bevel
// effect তৈরির জন্য, কোনো নতুন color-library লাগেনি।
// একটা donut(সেরা ৩ অথবা সর্বনিম্ন ৩ অ্যাক্টিভিটি) — সাধারণ, flat রঙ (কোনো
// gradient/shadow/3D-effect নেই, existing dashboard-এর color-palette-এর সাথেই
// সামঞ্জস্যপূর্ণ)। Chart.js-এর নিজস্ব legend ব্যবহার করা হয়েছে (নাম+% দুটোই
// legend-label-এর ভিতরে বেক করা), কারণ canvas slice-এর ভিতরে ছোট টেক্সট গোজার
// চেয়ে regular legend-টেক্সট ছোট স্ক্রিনেও অনেক বেশি সহজে পড়া যায়।
// পারফরম্যান্স-tier রঙ — শুধু এই র‍্যাঙ্কিং-সেকশনের জন্য, existing scoreColor()
// থেকে আলাদা রাখা হয়েছে ইচ্ছাকৃতভাবে: এখানে ০% মানে "সত্যিকারের রেকর্ড করা
// শূন্য পারফরম্যান্স"(fieldPercent() ইতিমধ্যে non-null মানেই ডেটা আছে ধরে
// নেয়), "কোনো এন্ট্রি নেই" নয় — তাই ০%-কেও colorless(#E7EEE3, যেটা ক্যালেন্ডারে
// "খালি দিন" বোঝায়) না দেখিয়ে বাকি লাল-tier-এর মতোই স্পষ্ট লাল দেখানো হয় (owner
// অনুরোধ, ৬ সেপ্টেম্বর ২০২৬)। ৮৫/৬০/৩৫% থ্রেশহোল্ড ও রঙ scoreColor()-এর সাথেই
// অভিন্ন রাখা হয়েছে (visual language consistency)।
function activityTierColor(pct) {
  // §Fix(১৯ সেপ্টেম্বর ২০২৬): scoreColor()-এর সাথে সামঞ্জস্যপূর্ণ fixed-green fix,
  // একই কারণ (থিম-color-এর সাথে performance-semantics মিশে যাওয়া প্রতিরোধ)।
  if (pct >= 85) return "#0E4B43";
  if (pct >= 70) return "#2563A8";
  if (pct >= 40) return "#D6A400";
  return "#C1666B";
}
const ORDINAL_BN = ["১ম", "২য়", "৩য়"];
// owner(৭ নভেম্বর ২০২৬): প্রতি শতাংশ-স্তরে শুধু ১টা আমলের নাম (আগে সর্বোচ্চ ৩টা ছিল)।
const MAX_LABELS_PER_TIER = 1;
const FARD_RANK_LABEL = "ফরজ আদায় (কাযা-মুক্ত)";

// একটা tier-cell: র‍্যাঙ্ক-ব্যাজ + আমলের নাম (১টা), নিচে বার ও বড় শতাংশ।
function TierCell({ rank, rankPrefix, pct, shownPct, labels, toBn }) {
  const color = activityTierColor(pct);
  const shown = shownPct === undefined ? pct : shownPct;
  return /*#__PURE__*/React.createElement("div", { title: rankPrefix }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-1.5 mb-1"
  }, /*#__PURE__*/React.createElement("span", {
    className: "w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold text-white flex-shrink-0",
    style: { background: color }
  }, toBn(rank)), /*#__PURE__*/React.createElement("span", {
    className: "flex-1 min-w-0 text-[13px] font-bold text-slate-800 leading-tight"
  }, labels.slice(0, MAX_LABELS_PER_TIER).join(", "))), /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-2"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex-1 h-2 rounded-full overflow-hidden",
    style: { background: "rgba(15,23,42,0.08)", boxShadow: "0 0 0 1px rgba(15,23,42,0.14)" }
  }, /*#__PURE__*/React.createElement("div", {
    className: "h-full rounded-full transition-all duration-500",
    style: { width: `${shown}%`, background: `linear-gradient(90deg, ${color}b3, ${color})` }
  })), /*#__PURE__*/React.createElement("span", {
    className: "font-bold text-base leading-none flex-shrink-0 min-w-[2.6rem] text-right",
    style: { fontFamily: "'IBM Plex Mono', 'Hind Siliguri', monospace", color }
  }, toBn(shown), "%")));
}

// দুই প্যানেল (সর্বোচ্চ | সর্বনিম্ন) একটাই grid-এ — প্রতি সারির উচ্চতা দুই পাশেই সমান হয়, তাই ১ম-১ম, ২য়-২য় সোজাসুজি মেলে।
// প্যানেলের রঙিন ব্যাকগ্রাউন্ড/বর্ডার প্রতিটি cell-এ আলাদা বসানো, কোণ গোল শুধু উপরে-নিচে।
function TierGrid({ left, right, toBn }) {
  const sides = [left, right].filter(x => x.tiers.length > 0);
  if (sides.length === 0) return null;
  const rows = Math.max(...sides.map(x => x.tiers.length));
  const cell = (side, content, kind, key) => {
    const first = kind === "head", last = kind === "last";
    return /*#__PURE__*/React.createElement("div", {
      key,
      className: "px-2.5 " + (first ? "pt-2.5 pb-2 rounded-t-xl" : "pb-2.5 " + (last ? "rounded-b-xl" : "")),
      style: {
        background: side.bg,
        borderLeft: `1px solid ${side.border}`,
        borderRight: `1px solid ${side.border}`,
        borderTop: first ? `1px solid ${side.border}` : "none",
        borderBottom: last ? `1px solid ${side.border}` : "none",
        paddingTop: first ? undefined : 2
      }
    }, content);
  };
  const out = [];
  sides.forEach((side, si) => out.push(cell(side, /*#__PURE__*/React.createElement("div", {
    className: "text-[13px] font-bold leading-tight flex items-center gap-1",
    style: { color: side.headingColor }
  }, /*#__PURE__*/React.createElement("span", null, side.icon), side.heading), "head", "h" + si)));
  for (let i = 0; i < rows; i++) {
    sides.forEach((side, si) => {
      const t = side.tiers[i];
      out.push(cell(side, t ? /*#__PURE__*/React.createElement(TierCell, {
        rank: i + 1,
        rankPrefix: `${ORDINAL_BN[i]} ${side.rankPrefix}`,
        pct: t.pct,
        shownPct: t.shownPct,
        labels: t.labels,
        toBn
      }) : null, i === rows - 1 ? "last" : "row", `r${i}-${si}`));
    });
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "grid gap-x-2 mb-3",
    style: { gridTemplateColumns: `repeat(${sides.length}, minmax(0, 1fr))` }
  }, out);
}

// Rating-tier থ্রেশহোল্ড ও ক্যাপশন — owner-চূড়ান্ত (৭ সেপ্টেম্বর ২০২৬)।
function ratingTier(pct) {
  if (pct >= 90) return { emoji: "⭐", label: "উৎকৃষ্ট", caption: "ধারাবাহিকতা খুব ভালো, এভাবেই বজায় রাখুন।" };
  if (pct >= 80) return { emoji: "🌿", label: "খুব ভালো", caption: "সামান্য উন্নতির সুযোগ আছে।" };
  if (pct >= 70) return { emoji: "👍", label: "ভালো", caption: "নিয়মিত আমলে আরও ধারাবাহিকতা প্রয়োজন।" };
  if (pct >= 50) return { emoji: "🔄", label: "উন্নতি প্রয়োজন", caption: "কয়েকটি গুরুত্বপূর্ণ আমল নিয়মিত করার চেষ্টা করুন।" };
  return { emoji: "🌱", label: "পুনরায় ধারাবাহিকতা গড়ার পর্যায়", caption: "ছোট ছোট লক্ষ্য নিয়ে ধারাবাহিকতা গড়ুন।" };
}

// computeActivityStats — TopBottomActivityRanking(তালিকা) ও
// MonthlyOverviewSection(শুধু rating badge)-এর জন্য একই hisab reuse করার
// pure helper(৮ সেপ্টেম্বর ২০২৬-এ extract করা, কোনো logic বদলায়নি, শুধু
// component-এর ভিতর থেকে বের করে দুই জায়গায় reuse-যোগ্য করা হয়েছে — কারণ
// badge এখন শুধু Monthly Overview বক্সে দেখানো হয়, ranking বক্সে না, অথচ
// দুটোই একই Overall%/Fard-Gate hisab-এর উপর নির্ভরশীল)।
//
// চলতি মাসের ১ তারিখ থেকে "যতদিন পূরণ হয়েছে" ততদিন পর্যন্ত (আজকের এন্ট্রি
// সেভ হয়ে থাকলে আজও ধরা হয়, না থাকলে গতকাল পর্যন্ত — filled-status-ভিত্তিক,
// rigid date-cutoff না) প্রতিটা আমলের গড় % হিসাব করে (fieldPercent() reuse)।
// অতীত মাস দেখলে পুরো মাস।
//
// Fard Gate: ফরজ কাযা (fardPrayers) ঠিক ১০০% না হলে "সর্বোচ্চ" তালিকায় আসবে
// না (even ৯৯%) — "সর্বনিম্ন"-এ কোনো বাধা নেই। একই নিয়ম জামায়াতে সালাত (male-only
// field)-এর জন্য ৭০% থ্রেশহোল্ডে। এই দুইটা field সবসময় Overall%-গড়ে যোগ হয় (gate
// শুধু তালিকা-প্রদর্শনে প্রভাব ফেলে, সংখ্যায় না)।
//
// Rating badge-এ আলাদা Fard Gate: Overall ৯০%+ হলেও fardPrayers ১০০% না হলে
// "উৎকৃষ্ট" badge দেখানো হবে না (এক ধাপ নিচে নামবে, "খুব ভালো") — কিন্তু আসল
// Overall% সংখ্যা অপরিবর্তিত থাকে (owner-চূড়ান্ত সিদ্ধান্ত)।
function computeActivityStats({ monthEntries, totalDays, member, allFields, fieldPercent, pad2, toBn, monthCursor }) {
  const now = new Date();
  const isCurrentMonth = now.getFullYear() === monthCursor.year && now.getMonth() === monthCursor.month0;
  let cutoffDay = totalDays;
  if (isCurrentMonth) {
    // শুধু "আজ" special-case করলে যথেষ্ট না — গতকাল (বা তার আগের দিন)ও যদি এখনো
    // পূরণ না হয়ে থাকে (owner এখনো এন্ট্রি দেননি), সেটাও বাদ দিতে হবে। তাই আজ
    // থেকে পিছনের দিকে হেঁটে সর্বশেষ প্রকৃত-পূরণ-করা দিন খুঁজে বের করা হয় (owner
    // পর্যবেক্ষণ, ৭ সেপ্টেম্বর ২০২৬: "পূরণ না করা পর্যন্ত হিসাবে ধরা যাবে না")।
    let d = now.getDate();
    while (d >= 1 && !monthEntries[pad2(d)]) d--;
    cutoffDay = d;
  }
  if (cutoffDay < 1) return null;
  const results = [];
  for (const f of allFields) {
    const pct = fieldPercent(f, monthEntries, cutoffDay, member);
    // "ফরজ কাযা" ফিল্ডের pct আসলে ইনভার্টেড (কাযা-মুক্ত/সময়মতো-আদায়ের হার,
    // fieldPercent()-এর ডকুমেন্টেড কনভেনশন) — তালিকায় সরাসরি "ফরজ কাযা" নামে
    // এই মান দেখালে নিচের কাযা-বার্তা (complementary %)-র সাথে বৈপরীত্য মনে
    // হয় (owner পর্যবেক্ষণ, ৮ সেপ্টেম্বর ২০২৬)। তাই শুধু এই ranking-লেবেলে
    // স্পষ্ট নাম ব্যবহার করা হলো — সংখ্যা/hisab অপরিবর্তিত।
    const label = f.key === "fardPrayers" ? FARD_RANK_LABEL : f.shortLabel || f.label;
    if (pct !== null) results.push({ key: f.key, label, pct });
  }
  if (results.length === 0) return null;

  const topEligible = r => {
    if (r.key === "fardPrayers") return r.pct === 100;
    if (r.key === "jamaat") return r.pct >= 70;
    return true;
  };
  const topPercents = [...new Set(results.filter(topEligible).map(r => r.pct))].filter(p => p > 0).sort((a, b) => b - a).slice(0, 3);
  const topSet = new Set(topPercents);
  const bottomPercents = [...new Set(results.map(r => r.pct))].filter(p => !topSet.has(p)).sort((a, b) => a - b).slice(0, 3);
  const labelsForTop = pct => results.filter(r => r.pct === pct && topEligible(r)).map(r => r.label);
  const labelsForAny = pct => results.filter(r => r.pct === pct).map(r => r.label);
  const topTiers = topPercents.map(pct => ({ pct, labels: labelsForTop(pct) }));
  // "আরও মনোযোগ" তালিকায় ফরজ আলাদা সারিতে "ফরজ (কাযা)" নামে আসল কাযা-হার (১০০−কাযা-মুক্ত%) দেখায়;
  // র‍্যাঙ্কিং/রঙ আগের মতোই কাযা-মুক্ত স্কোর অনুযায়ী (owner, ৫ নভেম্বর ২০২৬)। অন্য আমলের সারি অপরিবর্তিত।
  const bottomTiers = [];
  for (const pct of bottomPercents) {
    const normal = labelsForAny(pct).filter(l => l !== FARD_RANK_LABEL);
    if (normal.length) bottomTiers.push({ pct, labels: normal });
    if (results.some(r => r.pct === pct && r.key === "fardPrayers")) bottomTiers.push({ pct, shownPct: 100 - pct, labels: ["ফরজ (কাযা)"] });
  }
  bottomTiers.splice(3);

  const overallPct = Math.round(results.reduce((s, r) => s + r.pct, 0) / results.length);
  let badgeTier = ratingTier(overallPct);
  const fardResult = results.find(r => r.key === "fardPrayers");
  if (fardResult && fardResult.pct !== 100 && overallPct >= 90) {
    badgeTier = ratingTier(89);
  }

  let qazaJamaatBlock = null;
  if (fardResult) {
    const qazaPct = 100 - fardResult.pct;
    const jamaatResult = results.find(r => r.key === "jamaat");
    const goalMet = qazaPct === 0;
    // টেক্সট আপডেট (৮ সেপ্টেম্বর ২০২৬, owner-চূড়ান্ত ওয়র্ডিং)।
    const infoText = jamaatResult ? `চলতি মাসে এ পর্যন্ত আপনার কাযা সালাতের হার ${toBn(qazaPct)}% এবং জামায়াতে আদায়ের হার ${toBn(jamaatResult.pct)}%।` : `চলতি মাসে এ পর্যন্ত আপনার কাযা সালাতের হার ${toBn(qazaPct)}%।`;
    const goalText = jamaatResult ? "🎯 লক্ষ্য: সালাত কোনোভাবেই কাযা না করা এবং যথাসম্ভব জামায়াতে আদায়ের চেষ্টা করা।" : "🎯 লক্ষ্য: সালাত কোনোভাবেই কাযা না করা।";
    qazaJamaatBlock = { infoText, goalText, goalMet };
  }

  return { topTiers, bottomTiers, overallPct, badgeTier, qazaJamaatBlock };
}

export function TopBottomActivityRanking({
  monthEntries,
  totalDays,
  member,
  allFields,
  fieldPercent,
  pad2,
  toBn,
  monthCursor
}) {
  const stats = computeActivityStats({ monthEntries, totalDays, member, allFields, fieldPercent, pad2, toBn, monthCursor });
  if (!stats) return null;
  const { topTiers, bottomTiers, qazaJamaatBlock } = stats;

  return /*#__PURE__*/React.createElement("div", {
    className: "mt-4"
  }, /*#__PURE__*/React.createElement("h3", {
    className: "font-bold text-sm text-slate-800 mb-3 text-center"
  }, "📊 চলতি মাসে এ পর্যন্ত আপনার সর্বোচ্চ ও সর্বনিম্ন এক্টিভিটি"), /*#__PURE__*/React.createElement(TierGrid, {
    toBn: toBn,
    left: { heading: "সর্বোচ্চ ৩ এক্টিভিটি", icon: "🏆", headingColor: "#0E4B43", bg: "#EEF6F1", border: "#BFDCCB", tiers: topTiers, rankPrefix: "সর্বোচ্চ" },
    right: { heading: "আরও মনোযোগ প্রয়োজন", icon: "🎯", headingColor: "#8A6508", bg: "#FFF8E6", border: "#EBD59A", tiers: bottomTiers, rankPrefix: "সর্বনিম্ন" }
  }), qazaJamaatBlock && /*#__PURE__*/React.createElement("div", {
    className: qazaJamaatBlock.goalMet ? "bg-[#eaf3ee] border border-[#9fc9ae] rounded-xl p-3" : "bg-[#faece7] border border-[#f0997b] rounded-xl p-3"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-start gap-2"
  }, /*#__PURE__*/React.createElement("span", {
    className: "text-sm leading-none"
  }, qazaJamaatBlock.goalMet ? "✅" : "⚠️"), /*#__PURE__*/React.createElement("div", {
    className: qazaJamaatBlock.goalMet ? "text-sm font-bold text-[#215339] leading-relaxed" : "text-sm font-bold text-[#712b13] leading-relaxed"
  }, qazaJamaatBlock.infoText))), qazaJamaatBlock && /*#__PURE__*/React.createElement("div", {
    className: qazaJamaatBlock.goalMet ? "text-sm text-[#215339] leading-relaxed mt-1.5 pl-6" : "text-sm text-[#712b13] leading-relaxed mt-1.5 pl-6"
  }, qazaJamaatBlock.goalText));
}

// Shared month-nav control (refresh + ◀ month ▶) — verbatim JSX previously
// inlined only in MonthlyOverviewSection, now reused by Weekly/Meeting
// sections too (owner-approved, same dirty-check confirm logic, no behavior
// change — see chat: "মাসের ফিচার রিইউজ করা প্রয়োজন").
function MonthNavControl({
  monthCursor,
  setMonthCursor,
  setMonthRefreshKey,
  weeklyDirtyRef,
  meetingDirtyRef,
  BN_MONTHS,
  toBn,
  hideRefresh
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-1.5 flex-shrink-0"
  }, !hideRefresh && /*#__PURE__*/React.createElement("button", {
    onClick: () => setMonthRefreshKey(k => k + 1),
    title: "ক্যালেন্ডার রিফ্রেশ করুন",
    className: "w-7 h-7 flex items-center justify-center rounded-xl bg-white border border-slate-200 shadow-sm text-emerald-800 hover:bg-slate-50"
  }, /*#__PURE__*/React.createElement(RefreshIcon, {
    size: 13
  })), /*#__PURE__*/React.createElement("div", {
    className: "flex items-center bg-white px-0.5 rounded-lg border border-[#C89B3C] shadow-sm text-emerald-950"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => {
      if ((weeklyDirtyRef.current || meetingDirtyRef.current) && !window.confirm("সাপ্তাহিক রিফ্লেকশন বা মাসিক সভায় সেভ না করা পরিবর্তন আছে। মাস পরিবর্তন করলে তা হারিয়ে যাবে। আপনি কি নিশ্চিত?")) return;
      setMonthCursor(c => c.month0 === 0 ? {
        year: c.year - 1,
        month0: 11
      } : {
        year: c.year,
        month0: c.month0 - 1
      });
    },
    className: "relative w-5 h-7 flex items-center justify-center rounded-md hover:bg-black/10 before:content-[''] before:absolute before:-inset-x-1 before:-inset-y-2"
  }, /*#__PURE__*/React.createElement(ChevronLeft, {
    size: 11
  })), /*#__PURE__*/React.createElement("span", {
    className: "text-[10px] font-bold px-0.5 whitespace-nowrap"
  }, BN_MONTHS[monthCursor.month0], " ", /*#__PURE__*/React.createElement("span", {
    style: { fontFamily: "'IBM Plex Mono', 'Hind Siliguri', monospace" }
  }, toBn(monthCursor.year))), /*#__PURE__*/React.createElement("button", {
    onClick: () => {
      if ((weeklyDirtyRef.current || meetingDirtyRef.current) && !window.confirm("সাপ্তাহিক রিফ্লেকশন বা মাসিক সভায় সেভ না করা পরিবর্তন আছে। মাস পরিবর্তন করলে তা হারিয়ে যাবে। আপনি কি নিশ্চিত?")) return;
      setMonthCursor(c => c.month0 === 11 ? {
        year: c.year + 1,
        month0: 0
      } : {
        year: c.year,
        month0: c.month0 + 1
      });
    },
    className: "relative w-5 h-7 flex items-center justify-center rounded-md hover:bg-black/10 before:content-[''] before:absolute before:-inset-x-1 before:-inset-y-2"
  }, /*#__PURE__*/React.createElement(ChevronRight, {
    size: 11
  }))));
}

export function MonthlyOverviewSection({
  allFields,
  entryDirtyRef,
  leadBlanks,
  meetingDirtyRef,
  monthCursor,
  monthEntries,
  monthStats,
  selectedMember,
  setMonthCursor,
  setMonthRefreshKey,
  setPrintMode,
  setShowMonthlyInfoModal,
  setViewDate,
  total,
  weeklyDirtyRef,
  BN_MONTHS,
  BN_WEEKDAYS,
  dailyScore,
  fieldPercent,
  pad2,
  scoreColor,
  toBn,
  streak,
  // §Layout reposition(১৭ সেপ্টেম্বর ২০২৬, owner-অনুরোধ): TopBottomActivityRanking-
  // এর already-rendered element এখানে prop হিসেবে আসে (component নিজে অপরিবর্তিত,
  // শুধু render-tree-এর অবস্থান বদলেছে — app.js দ্রষ্টব্য)।
  rankingSlot
}) {
  // §Heatmap legend day-count(১৭ সেপ্টেম্বর ২০২৬, owner-approved): scoreColor()
  // -এর হুবহু একই ৪-threshold branching reuse করে প্রতিটা tier-এ কতদিন পড়ে তার
  // tally — নতুন calculation/read নয়, existing dailyScore()-ই আলাদাভাবে (calendar
  // -cell render loop থেকে independent) আরেকবার লুপ করা হচ্ছে।
  const tierCounts = { excellent: 0, good: 0, medium: 0, low: 0, empty: 0 };
  for (let d = 1; d <= total; d++) {
    const s = dailyScore(monthEntries[pad2(d)], selectedMember, allFields);
    if (s === null || s === undefined) tierCounts.empty += 1;
    else if (Math.round(s * 100) >= 85) tierCounts.excellent += 1;
    else if (Math.round(s * 100) >= 70) tierCounts.good += 1;
    else if (Math.round(s * 100) >= 40) tierCounts.medium += 1;
    else if (s > 0) tierCounts.low += 1;
    else tierCounts.empty += 1;
  }
  return React.createElement("div", {
    className: "px-5 mt-8"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center justify-between mb-3"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "font-bold flex items-center gap-1.5 text-base text-slate-800"
  }, /*#__PURE__*/React.createElement(CalIcon, {
    size: 16,
    color: "var(--theme-primary)"
  }), " মাসিক ওভারভিউ"), /*#__PURE__*/React.createElement(MonthNavControl, {
    monthCursor: monthCursor,
    setMonthCursor: setMonthCursor,
    setMonthRefreshKey: setMonthRefreshKey,
    weeklyDirtyRef: weeklyDirtyRef,
    meetingDirtyRef: meetingDirtyRef,
    BN_MONTHS: BN_MONTHS,
    toBn: toBn
  })), /*#__PURE__*/React.createElement("div", {
    className: "bg-white rounded-2xl p-4 border border-[#E4D3A8] shadow-[0_3px_12px_-3px_rgba(160,120,40,0.25)]"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex gap-2 mb-3 pb-3 border-b border-slate-100"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex-1 min-w-0 rounded-2xl px-3 py-2 text-white",
    style: { background: "linear-gradient(135deg,#0E4B43,#2D6A5C)", boxShadow: "0 6px 14px -6px rgba(14,75,67,0.55)" }
  }, /*#__PURE__*/React.createElement("div", {
    className: "text-xs font-bold opacity-90"
  }, "গড় স্কোর"), /*#__PURE__*/React.createElement("div", {
    className: "text-xl font-bold leading-tight",
    style: { fontFamily: "'IBM Plex Mono', 'Hind Siliguri', monospace" }
  }, toBn(monthStats.avgPct), "%")), /*#__PURE__*/React.createElement("div", {
    className: "flex-1 min-w-0 rounded-2xl px-3 py-2",
    style: { background: "linear-gradient(135deg,#FBEFC4,#F3D98B)", color: "#5C4300", boxShadow: "0 6px 14px -6px rgba(160,120,40,0.45)" }
  }, /*#__PURE__*/React.createElement("div", {
    className: "text-xs font-bold opacity-90"
  }, "পূরণ করা দিন"), /*#__PURE__*/React.createElement("div", {
    className: "text-xl font-bold leading-tight",
    style: { fontFamily: "'IBM Plex Mono', 'Hind Siliguri', monospace" }
  }, toBn(monthStats.filled), "/", toBn(total))), /*#__PURE__*/React.createElement("button", {
    onClick: () => setPrintMode(true),
    title: "PDF / প্রিন্ট (২ পেজ)",
    "aria-label": "PDF / প্রিন্ট",
    className: "shrink-0 flex flex-col items-center justify-center gap-0.5 px-3.5 rounded-2xl text-xs font-bold bg-emerald-50 text-emerald-900 border border-emerald-100 hover:bg-emerald-100 transition-all"
  }, /*#__PURE__*/React.createElement(Printer, {
    size: 16
  }), "PDF")), /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-1.5 text-sm font-bold text-slate-600 mt-4 mb-2"
  }, /*#__PURE__*/React.createElement(CalIcon, {
    size: 13,
    color: "var(--theme-primary)"
  }), "এক্টিভিটি ক্যালেন্ডার", /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => setShowMonthlyInfoModal(true),
    className: "text-slate-400 hover:text-emerald-700",
    title: "ক্যালেন্ডারের রঙ কী বোঝায়?"
  }, /*#__PURE__*/React.createElement(InfoIcon, {
    size: 14
  }))), /*#__PURE__*/React.createElement("div", {
    className: "mt-0"
  }, /*#__PURE__*/React.createElement("div", {
    className: "grid grid-cols-7 gap-1.5"
  }, BN_WEEKDAYS.map(w => /*#__PURE__*/React.createElement("div", {
    key: w,
    className: "text-center text-[11px] font-bold text-slate-400"
  }, w)), Array.from({
    length: leadBlanks
  }).map((_, i) => /*#__PURE__*/React.createElement("div", {
    key: "b" + i
  })), Array.from({
    length: total
  }, (_, i) => i + 1).map(d => {
    const e = monthEntries[pad2(d)];
    const s = dailyScore(e, selectedMember, allFields);
    const cellDate = new Date(monthCursor.year, monthCursor.month0, d);
    const isToday = cellDate.toDateString() === new Date().toDateString();
    return /*#__PURE__*/React.createElement("button", {
      key: d,
      onClick: () => {
        if (entryDirtyRef.current && !window.confirm("এই দিনের এন্ট্রিতে সেভ না করা পরিবর্তন আছে। এগিয়ে গেলে তা হারিয়ে যাবে। আপনি কি নিশ্চিত?")) return;
        setViewDate(cellDate);
      },
      className: "h-7 w-full rounded-xl flex items-center justify-center text-xs font-bold transition-transform active:scale-90",
      style: {
        background: scoreColor(s),
        color: s !== null && Math.round(s * 100) >= 70 ? "#fff" : s !== null && Math.round(s * 100) >= 40 ? "#7A5C00" : s !== null && s > 0 ? "#3A0D0F" : "#555",
        fontFamily: "'IBM Plex Mono', 'Hind Siliguri', monospace",
        boxShadow: isToday ? "0 0 0 2px var(--theme-primary), 0 2px 5px -1px rgba(0,0,0,0.15)" : "0 1px 2px rgba(0,0,0,0.06)"
      }
    }, toBn(d));
  }))), /* §Part B Phase ৫ (heatmap legend, 2_5 Part B §B৩.৪, ১৫ সেপ্টেম্বর ২০২৬):
       কম্প্যাক্ট রঙ-legend, existing scoreColor()(appHelpers.js) ৫-tier scheme
       ও InfoModals.jsx-এর ইতিমধ্যে-বিদ্যমান ক্যালেন্ডার-রঙ legend-এর সাথে
       হুবহু sync(কোনো নতুন formula/threshold না, শুধু presentation) — পূর্ণ
       percentage-range বিবরণ আগে থেকেই ⓘ-আইকনে আছে, এটা শুধু at-a-glance
       quick-reference, tap ছাড়াই। */
  /*#__PURE__*/React.createElement("div", {
    className: "flex flex-wrap items-center gap-1.5 mt-3 pt-3 border-t border-slate-100"
  }, [
    { c: "#0E4B43", l: "চমৎকার", n: tierCounts.excellent },
    { c: "#2563A8", l: "ভালো", n: tierCounts.good },
    { c: "#F5D061", l: "মাঝারি", n: tierCounts.medium },
    { c: "#C1666B", l: "কম", n: tierCounts.low },
    { c: "#E7EEE3", l: "খালি", n: tierCounts.empty, border: true }
  ].map(item => /*#__PURE__*/React.createElement("span", {
    key: item.l,
    className: "flex items-center gap-1 pl-1 pr-2 py-0.5 rounded-full bg-slate-50 border border-slate-100"
  }, /*#__PURE__*/React.createElement("span", {
    className: "w-2.5 h-2.5 rounded-full" + (item.border ? " border border-slate-300" : ""),
    style: { background: item.c }
  }), /*#__PURE__*/React.createElement("span", {
    className: "text-[11px] font-medium text-slate-500"
  }, item.l, /*#__PURE__*/React.createElement("span", {
    className: "font-bold text-slate-700",
    style: { fontFamily: "'IBM Plex Mono', 'Hind Siliguri', monospace" }
  }, "(", toBn(item.n), ")"))))), rankingSlot));
}

export function MeetingMinutesSection({
  fold,
  addMeetingRow,
  handleSaveMeeting,
  meetingSavedTick,
  meetingState,
  monthCursor,
  removeMeetingRow,
  savingMeeting,
  setShowMeetingInfoModal,
  updateMeetingRow,
  BN_MONTHS,
  toBn,
  setMonthCursor,
  setMonthRefreshKey,
  weeklyDirtyRef,
  meetingDirtyRef
}) {
  // §Section-level accordion(১৬ সেপ্টেম্বর ২০২৬, owner-approved): Weekly
  // Reflection-এর মতোই, পুরো সেকশন ডিফল্টে বন্ধ। ভিতরের প্রতিটা row-এর
  // আলাদা accordion(openRows) owner-অনুরোধে (১৬ সেপ্টেম্বর, দ্বিতীয় দফা)
  // সরানো হয়েছে — সেকশন খোলা থাকলে প্রতিটা row এখন সবসময় দেখা যাবে।
  const [sectionOpen, setSectionOpen] = useState(fold === "open" || fold === "fixed");
  const rows = meetingState.rows && meetingState.rows.length > 0 ? meetingState.rows : [];
  return React.createElement("div", {
    className: "mx-5 mt-4 p-4 rounded-2xl bg-white shadow-sm",
    style: { border: "1px solid #EADFBE" }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: () => fold === "fixed" ? undefined : setSectionOpen(o => !o),
    className: "flex items-center justify-between mb-2 select-none" + (fold === "fixed" ? "" : " cursor-pointer")
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-2"
  }, /*#__PURE__*/React.createElement("h2", {
    className: "font-bold text-base text-slate-800"
  }, "মাসিক পারিবারিক সভা ও সিদ্ধান্ত"), /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: e => {
      e.stopPropagation();
      setShowMeetingInfoModal(true);
    },
    className: "text-slate-400 hover:text-emerald-700",
    title: "তথ্য"
  }, /*#__PURE__*/React.createElement(InfoIcon, {
    size: 13
  })), /*#__PURE__*/React.createElement("span", {
    className: "text-xs bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold flex items-center gap-1"
  }, /*#__PURE__*/React.createElement(RefreshIcon, {
    size: 10
  }), "লাইভ সিংক")), fold === "fixed" ? null : /*#__PURE__*/React.createElement(ChevronDown, {
    size: 18,
    className: "text-slate-400 transition-transform" + (sectionOpen ? " rotate-180" : "")
  })), sectionOpen && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center justify-between mb-3 flex-wrap gap-y-2"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: addMeetingRow,
    className: "px-2.5 py-1 bg-emerald-800 text-white rounded-xl text-sm font-bold flex items-center gap-1 hover:bg-emerald-900 transition-all shadow-sm"
  }, /*#__PURE__*/React.createElement(Plus, {
    size: 12
  }), " সারি যোগ করুন"), /*#__PURE__*/React.createElement(MonthNavControl, {
    monthCursor: monthCursor,
    setMonthCursor: setMonthCursor,
    setMonthRefreshKey: setMonthRefreshKey,
    weeklyDirtyRef: weeklyDirtyRef,
    meetingDirtyRef: meetingDirtyRef,
    BN_MONTHS: BN_MONTHS,
    toBn: toBn,
    hideRefresh: true
  })), /*#__PURE__*/React.createElement("div", {
    className: "space-y-2 mb-4"
  }, rows.map((row, idx) => {
    return /*#__PURE__*/React.createElement("div", {
      key: row.id || idx,
      className: "bg-white rounded-2xl shadow-sm border border-slate-200/80 overflow-hidden"
    }, /*#__PURE__*/React.createElement("div", {
      className: "flex items-center justify-between gap-2 px-3.5 py-2.5"
    }, /*#__PURE__*/React.createElement("div", {
      className: "flex items-center gap-2 min-w-0"
    }, /*#__PURE__*/React.createElement("span", {
      className: "bg-[#C89B3C] text-emerald-950 text-sm font-bold px-2.5 py-1 rounded-full flex-shrink-0",
      style: { fontFamily: "'IBM Plex Mono', 'Hind Siliguri', monospace" }
    }, "ক্র. ", toBn(idx + 1)), row.topic && /*#__PURE__*/React.createElement("span", {
      className: "text-sm text-slate-500 truncate"
    }, row.topic)), rows.length > 1 && /*#__PURE__*/React.createElement("button", {
      onClick: () => removeMeetingRow(idx),
      className: "text-red-400 hover:text-red-600 p-1 flex-shrink-0"
    }, /*#__PURE__*/React.createElement(Trash, {
      size: 14
    }))), /*#__PURE__*/React.createElement("div", {
      className: "px-3.5 pb-3.5 space-y-2.5"
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "text-xs font-bold text-slate-500 mb-1"
    }, "বিষয়"), /*#__PURE__*/React.createElement("textarea", {
      value: row.topic || "",
      onChange: e => updateMeetingRow(idx, "topic", e.target.value),
      placeholder: "বিষয়...",
      rows: 2,
      className: "w-full text-sm p-2 border border-slate-200 rounded-lg outline-none focus:border-emerald-700 font-semibold bg-white resize-none"
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "text-xs font-bold text-slate-500 mb-1"
    }, "কার্যপরিধি/সিদ্ধান্ত"), /*#__PURE__*/React.createElement("textarea", {
      value: row.decision || "",
      onChange: e => updateMeetingRow(idx, "decision", e.target.value),
      placeholder: "কার্যপরিধি/সিদ্ধান্ত...",
      rows: 2,
      className: "w-full text-sm p-2 border border-slate-200 rounded-lg outline-none focus:border-emerald-700 bg-white resize-none"
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      className: "text-xs font-bold text-slate-500 mb-1"
    }, "বাস্তবায়নকারী"), /*#__PURE__*/React.createElement("input", {
      type: "text",
      value: row.person || "",
      onChange: e => updateMeetingRow(idx, "person", e.target.value),
      placeholder: "বাস্তবায়নকারী",
      className: "w-full text-sm p-2 border border-slate-200 rounded-lg outline-none focus:border-emerald-700 font-medium bg-white"
    }))));
  })), /*#__PURE__*/React.createElement("button", {
    onClick: handleSaveMeeting,
    className: "w-full h-11 rounded-2xl font-bold text-white text-sm bg-emerald-900 flex items-center justify-center gap-2 shadow-sm"
  }, savingMeeting ? /*#__PURE__*/React.createElement(Loader2, {
    className: "animate-spin",
    size: 16
  }) : meetingSavedTick ? "সেভ ও সিংক হয়েছে!" : "মাসিক সভা ও সিদ্ধান্ত সেভ করুন")));
}

export function DeleteAccountWarningModal({
  handleDeleteGoogleAccount,
  setShowDeleteAccountWarning,
  showDeleteAccountWarning
}) {
  return showDeleteAccountWarning && /*#__PURE__*/React.createElement("div", {
    className: "fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center px-5 z-50"
  }, /*#__PURE__*/React.createElement("div", {
    className: "bg-white rounded-3xl p-5 w-full max-w-sm shadow-xl border border-slate-100"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center gap-2 mb-3"
  }, /*#__PURE__*/React.createElement("span", {
    className: "text-2xl"
  }, "⚠️"), /*#__PURE__*/React.createElement("h3", {
    className: "font-bold text-sm text-slate-800"
  }, "Google অ্যাকাউন্ট ডিলিট নিশ্চিত করুন")), /*#__PURE__*/React.createElement("p", {
    className: "text-sm text-slate-600 leading-relaxed mb-4"
  }, "এতে এই ডিভাইস থেকে Google অ্যাকাউন্ট সরে যাবে এবং আপনি সাইন-আউট হয়ে যাবেন। তবে অ্যাপের মূল ডেটার কোনো ক্ষতি হবে না — আপনার সম্পূর্ণ ডেটা ফ্যামিলি ইউজারনেমের সাথে নিরাপদে সংরক্ষিত থাকবে।"), /*#__PURE__*/React.createElement("div", {
    className: "flex gap-2"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setShowDeleteAccountWarning(false),
    className: "flex-1 h-9 border border-slate-200 text-slate-600 rounded-xl text-sm font-bold"
  }, "বাতিল"), /*#__PURE__*/React.createElement("button", {
    onClick: handleDeleteGoogleAccount,
    className: "flex-1 h-9 bg-red-600 text-white rounded-xl text-sm font-bold"
  }, "হ্যাঁ, ডিলিট করুন"))));
}

export function FeedbackModal({
  feedbackMsg,
  feedbackSending,
  feedbackStatus,
  handleSendFeedback,
  setFeedbackMsg,
  setFeedbackStatus,
  setShowFeedbackModal,
  showFeedbackModal
}) {
  return showFeedbackModal && /*#__PURE__*/React.createElement("div", {
    className: "fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center px-5 z-50"
  }, /*#__PURE__*/React.createElement("div", {
    className: "bg-white rounded-3xl p-5 w-full max-w-sm shadow-xl border border-slate-100"
  }, /*#__PURE__*/React.createElement("div", {
    className: "flex items-center justify-between mb-2"
  }, /*#__PURE__*/React.createElement("h3", {
    className: "font-bold text-sm text-slate-800 flex items-center gap-2"
  }, /*#__PURE__*/React.createElement(MessageSquare, {
    size: 16,
    color: "var(--theme-primary)"
  }), " পরামর্শ জানান"), /*#__PURE__*/React.createElement("button", {
    onClick: () => {
      setShowFeedbackModal(false);
      setFeedbackStatus(null);
    }
  }, /*#__PURE__*/React.createElement(X, {
    size: 18,
    className: "text-slate-400"
  }))), /*#__PURE__*/React.createElement("p", {
    className: "text-xs text-slate-500 mb-3"
  }, "কোনো সমস্যা বা পরামর্শ আমাদের জানান।"), /*#__PURE__*/React.createElement("textarea", {
    value: feedbackMsg,
    onChange: e => setFeedbackMsg(e.target.value),
    rows: 4,
    placeholder: "আপনার অমূল্য পরামর্শ লিখুন...",
    disabled: feedbackSending,
    className: "w-full rounded-2xl border border-slate-200 p-3 text-sm outline-none focus:border-emerald-800 resize-none mb-2 bg-slate-50/50 disabled:opacity-60"
  }), feedbackStatus === "error" && /*#__PURE__*/React.createElement("p", {
    className: "text-xs text-red-600 mb-2"
  }, "পাঠাতে সমস্যা হয়েছে, আবার চেষ্টা করুন।"), feedbackStatus === "sent" && /*#__PURE__*/React.createElement("p", {
    className: "text-xs text-emerald-700 mb-2"
  }, "ধন্যবাদ! আপনার পরামর্শ পাঠানো হয়েছে।"), /*#__PURE__*/React.createElement("div", {
    className: "flex gap-2 mt-1"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: handleSendFeedback,
    disabled: feedbackSending || !feedbackMsg.trim(),
    className: "flex-1 h-9 bg-emerald-800 text-white rounded-xl text-sm font-bold flex items-center justify-center gap-1.5 disabled:opacity-60"
  }, feedbackSending ? /*#__PURE__*/React.createElement(Loader2, {
    className: "animate-spin",
    size: 14
  }) : feedbackStatus === "sent" ? "পাঠানো হয়েছে!" : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(MessageSquare, {
    size: 14
  }), " পাঠিয়ে দিন")), /*#__PURE__*/React.createElement("button", {
    onClick: () => {
      setShowFeedbackModal(false);
      setFeedbackStatus(null);
    },
    className: "h-9 px-4 border border-slate-200 text-slate-600 rounded-xl text-sm font-bold"
  }, "বাতিল"))));
}

// §B৭ Streak-milestone celebration(2_5 Part B §B৭, ১৫ সেপ্টেম্বর ২০২৬,
// owner-approved): existing milestone toast(৭/৩০/১০০/৩৬৫ দিন)-এর উপর
// CSS-only confetti keyframe-animation — কোনো নতুন library/dependency না,
// শুধু কয়েকটা রঙিন dot-span + একবার-চলা CSS @keyframes।
const MILESTONE_CONFETTI_COLORS = ["#C89B3C", "#2F9E44", "#0E4B43", "#E0A429", "#D64545"];

// §B৭ Weekly Summary Notification(2_5 Part B §B৭, ১৫ সেপ্টেম্বর ২০২৬,
// owner-approved — in-app, non-push variant, বিস্তারিত: architecture-review
// note অনুযায়ী প্রকৃত push(app বন্ধ অবস্থায় delivery) Cloud Function/Blaze
// লাগবে, তাই out-of-scope; এই toast শুধু app-open-এ, existing loaded
// monthEntries থেকে client-side গণনা করে দেখায়, কোনো নতুন Firestore read
// নেই। week-definition existing getWeekRanges()(app-এর নিজস্ব ৭-দিন-চাংক
// সংজ্ঞা, Weekly Reflection feature-এর সাথেই সামঞ্জস্যপূর্ণ)।
export function WeeklySummaryToast({
  weeklySummaryToast,
  setWeeklySummaryToast,
  toBn
}) {
  if (!weeklySummaryToast) return false;
  const { avgPct, filled, totalDays } = weeklySummaryToast;
  return /*#__PURE__*/React.createElement("div", {
    className: "fixed inset-x-0 top-4 flex justify-center px-5 z-[55]"
  }, /*#__PURE__*/React.createElement("div", {
    className: "bg-white text-[#16302B] rounded-2xl shadow-xl px-4 py-3 max-w-sm w-full flex items-center gap-3 border border-slate-100"
  }, /*#__PURE__*/React.createElement("span", {
    className: "text-xl"
  }, "\ud83d\udcca"), /*#__PURE__*/React.createElement("div", {
    className: "flex-1"
  }, /*#__PURE__*/React.createElement("p", {
    className: "text-sm font-bold",
    style: { color: "#0E4B43" }
  }, "\u0997\u09a4 \u09b8\u09aa\u09cd\u09a4\u09be\u09b9\u09c7\u09b0 \u09b8\u09be\u09b0\u09be\u0982\u09b6"), /*#__PURE__*/React.createElement("p", {
    className: "text-sm text-slate-600 mt-0.5"
  }, "\u0997\u09a1\u09bc \u09b8\u09cd\u0995\u09cb\u09b0 ", /*#__PURE__*/React.createElement("span", {
    style: { fontFamily: "'IBM Plex Mono', 'Hind Siliguri', monospace", fontWeight: 700 }
  }, toBn(avgPct) + "%"), " \u00b7 ", toBn(filled), "/", toBn(totalDays), " \u09a6\u09bf\u09a8 \u09b8\u09ae\u09cd\u09aa\u09c2\u09b0\u09cd\u09a3")), /*#__PURE__*/React.createElement("button", {
    onClick: () => setWeeklySummaryToast(null),
    className: "text-slate-400 hover:text-slate-700 shrink-0"
  }, /*#__PURE__*/React.createElement(X, { size: 16 }))));
}

export function MilestoneToast({
  milestoneToast,
  setMilestoneToast,
  toBn
}) {
  return milestoneToast && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("style", null, "@keyframes dtConfettiFall{0%{transform:translateY(-12px) rotate(0deg);opacity:1}100%{transform:translateY(52px) rotate(360deg);opacity:0}}"), /*#__PURE__*/React.createElement("div", {
    className: "fixed inset-x-0 bottom-6 flex justify-center px-5 z-[60]"
  }, /*#__PURE__*/React.createElement("div", {
    className: "relative bg-[#16302B] text-white rounded-2xl shadow-xl px-5 py-4 max-w-sm w-full flex items-center gap-3 border border-[#C89B3C]/40 overflow-hidden"
  }, MILESTONE_CONFETTI_COLORS.map((c, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    "aria-hidden": "true",
    style: {
      position: "absolute",
      top: 0,
      left: (12 + i * 18) + "%",
      width: 6,
      height: 6,
      borderRadius: "50%",
      background: c,
      animation: "dtConfettiFall " + (0.9 + i * 0.15) + "s ease-in " + (i * 0.08) + "s 1"
    }
  })), /*#__PURE__*/React.createElement("span", {
    className: "text-2xl"
  }, "🎉"), /*#__PURE__*/React.createElement("div", {
    className: "flex-1"
  }, /*#__PURE__*/React.createElement("p", {
    className: "text-sm font-bold",
    style: {
      color: "#C89B3C"
    }
  }, "অভিনন্দন!"), /*#__PURE__*/React.createElement("p", {
    className: "text-sm text-slate-200 mt-0.5"
  }, /*#__PURE__*/React.createElement("span", {
    style: { fontFamily: "'IBM Plex Mono', 'Hind Siliguri', monospace" }
  }, toBn(milestoneToast)), " দিনের ধারাবাহিকতা পূর্ণ হয়েছে — মাশাআল্লাহ, চালিয়ে যান!")), /*#__PURE__*/React.createElement("button", {
    onClick: () => setMilestoneToast(null),
    className: "text-slate-400 hover:text-white shrink-0"
  }, /*#__PURE__*/React.createElement(X, {
    size: 16
  })))));
}
