// ২.৪ §২ (owner-simplified, ১১ সেপ্টেম্বর ২০২৬ সিদ্ধান্ত অনুযায়ী মূল
// প্ল্যানের ২-বাটন Screen A/B/C একত্রিত করা হয়েছে একটাই ফ্লো-তে):
//
//   ১) একটাই "Google দিয়ে সাইন-ইন করুন" বাটন — ক্লিকেই popup ট্রিগার(§১০.৩,
//      সরাসরি synchronous onClick, .then()-এর ভিতরে না)।
//   ২) Popup সফল হলে email-match চেক (googleIdentity.signInExistingMemberByGoogle) —
//      মিলে গেলে সরাসরি প্রোফাইল/পরিবারে (onSuccess কল, parent redirect করবে)।
//   ৩) না মিললে (নতুন ইউজার) — নাম+জেন্ডার+Family Code ফর্ম দেখাবে (আগে থেকেই
//      Google Sign-in সম্পন্ন, দ্বিতীয়বার popup লাগবে না)। এই ফর্ম submit
//      না করা পর্যন্ত কোনো family/account তৈরি হয় না।
//
// সম্পূর্ণ নতুন, additive ফাইল — app.js এখনো এটা import/use করে না
// (wiring পরের ধাপে)। createElement-style(existing codebase convention)।
import { useState } from "react";
import { GoogleGIcon } from "./icons.jsx";
import {
  triggerGoogleSignInPopup,
  signInExistingMemberByGoogle,
  currentGoogleEmail
} from "../legacy/googleIdentity.js";
import { createNewFamilyGoogleOnly } from "../legacy/familyIdentity.js";
import { logAuthDiagnostics } from "../legacy/firebaseConfig.js";

export function GoogleSignInGate({ onSuccess }) {
  // "idle" | "checking" | "new-user-form" | "creating" | "error"
  const [stage, setStage] = useState("idle");
  const [errorMsg, setErrorMsg] = useState(null);
  const [familyCode, setFamilyCode] = useState("");
  const [name, setName] = useState("");
  const [gender, setGender] = useState("");

  function handleSignInClick() {
    // §১০.৩ — popup সরাসরি synchronous statement হিসেবে (কোনো await/.then()
    // এর ভিতরে না)।
    setErrorMsg(null);
    setStage("checking");
    triggerGoogleSignInPopup()
      .then(() => signInExistingMemberByGoogle())
      .then(res => {
        if (res && res.matched) {
          onSuccess(res.familyId, res.memberId);
        } else {
          // মিল নেই — নতুন ইউজার, নাম/জেন্ডার/Family Code ফর্ম দেখাও।
          setStage("new-user-form");
        }
      })
      .catch(err => {
        logAuthDiagnostics("Google Sign-in(GoogleSignInGate)", err);
        setErrorMsg(`সাইন-ইন করা যায়নি, আবার চেষ্টা করুন।${err && err.code ? ` [কোড: ${err.code}]` : ""}`);
        setStage("idle");
      });
  }

  function handleCreateAccount() {
    if (!familyCode.trim() || !name.trim()) {
      setErrorMsg("ফ্যামিলি ইউজারনেম ও নাম লিখুন।");
      return;
    }
    setErrorMsg(null);
    setStage("creating");
    // এই মুহূর্তে auth.currentUser আগে থেকেই সেই Google user(উপরের ধাপে
    // popup সফল হয়েছে) — দ্বিতীয় popup লাগে না।
    createNewFamilyGoogleOnly(familyCode.trim(), name.trim(), gender || null)
      .then(res => {
        if (res && res.aborted) {
          const msgMap = {
            "code-taken": "এই ফ্যামিলি ইউজারনেম আগেই ব্যবহৃত হয়েছে। অন্য একটি দিন।",
            "length": "ফ্যামিলি ইউজারনেম ৬-৩০ অক্ষরের মধ্যে হতে হবে।",
            "charset": "ফ্যামিলি ইউজারনেমে শুধু ইংরেজি অক্ষর/সংখ্যা/আন্ডারস্কোর/হাইফেন ব্যবহার করুন।",
            "name-required": "নাম লিখুন।"
          };
          setErrorMsg(msgMap[res.reason] || "তৈরি করা যায়নি, আবার চেষ্টা করুন।");
          setStage("new-user-form");
        }
        // success হলে createNewFamilyGoogleOnly() নিজেই window.location.reload()
        // করে — এখানে আলাদা কিছু করার দরকার নেই।
      });
  }

  if (stage === "new-user-form") {
    return /*#__PURE__*/React.createElement("div", {
      className: "space-y-2 p-3"
    },
      /*#__PURE__*/React.createElement("div", {
        className: "text-xs text-slate-500"
      }, currentGoogleEmail()
          ? `${currentGoogleEmail()} — এই ইমেইল দিয়ে কোনো পরিবার পাওয়া যায়নি। নতুন পরিবার তৈরি করতে নিচের তথ্য দিন।`
          : "নতুন পরিবার তৈরি করতে নিচের তথ্য দিন।"),
      /*#__PURE__*/React.createElement("div", {
        className: "relative w-full"
      },
        /*#__PURE__*/React.createElement("input", {
          type: "text",
          value: familyCode,
          onChange: e => setFamilyCode(e.target.value),
          placeholder: "পরিবারের নাম (ফ্যামিলি ইউজারনেম)",
          className: "w-full border border-slate-200 rounded-lg px-3 py-2 text-sm pr-24"
        }),
        !familyCode && /*#__PURE__*/React.createElement("span", {
          className: "absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 pointer-events-none",
          "aria-hidden": "true"
        }, "যেমন: Hasan-Family")
      ),
      /*#__PURE__*/React.createElement("input", {
        type: "text",
        value: name,
        onChange: e => setName(e.target.value),
        placeholder: "আপনার নাম",
        className: "w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
      }),
      /*#__PURE__*/React.createElement("select", {
        value: gender,
        onChange: e => setGender(e.target.value),
        className: "w-full border border-slate-200 rounded-lg px-3 py-2 text-sm"
      },
        /*#__PURE__*/React.createElement("option", { value: "" }, "জেন্ডার বেছে নিন"),
        /*#__PURE__*/React.createElement("option", { value: "male" }, "পুরুষ"),
        /*#__PURE__*/React.createElement("option", { value: "female" }, "নারী")
      ),
      errorMsg && /*#__PURE__*/React.createElement("div", {
        className: "text-red-600 text-xs"
      }, errorMsg),
      /*#__PURE__*/React.createElement("button", {
        type: "button",
        disabled: stage === "creating" || !familyCode.trim() || !name.trim(),
        onClick: handleCreateAccount,
        className: "w-full bg-emerald-700 text-white rounded-lg py-2 text-sm font-semibold disabled:opacity-50"
      }, stage === "creating" ? "তৈরি হচ্ছে..." : "অ্যাকাউন্ট তৈরি করুন")
    );
  }

  return /*#__PURE__*/React.createElement("div", {
    className: "space-y-2 p-3"
  },
    errorMsg && /*#__PURE__*/React.createElement("div", {
      className: "text-red-600 text-xs"
    }, errorMsg),
    /*#__PURE__*/React.createElement("button", {
      type: "button",
      disabled: stage === "checking",
      onClick: handleSignInClick,
      className: "w-full bg-white border border-slate-300 rounded-xl py-2.5 text-sm font-semibold text-slate-700 flex items-center justify-center gap-3 shadow-sm hover:shadow-md active:scale-[0.99] transition-all disabled:opacity-50"
    }, /*#__PURE__*/React.createElement(GoogleGIcon, { size: 20 }), stage === "checking" ? "চেক করা হচ্ছে..." : "Google দিয়ে সাইন-ইন করুন")
  );
}
