// quranUi.jsx — QuranReader ও QuranMushaf-এর ভাগ-করা অংশ: কপি, আইকন, স্টেপার,
// অবিচ্ছিন্ন আরবি লেখা (AyahFlow), আয়াত-শিট (AyahSheet) ও কপি/শেয়ার-হুক।
// আয়াতের নম্বর CSS-এর গোল চিহ্নে আঁকা (ফন্টের চিহ্ন নয়), যাতে যেকোনো ফন্টে ঠিক দেখায়।
// React global(window.React, globals.js)।

import { CopyIcon, ShareIcon, Icon } from "../../icons.jsx";
import { useBackLayer } from "../../../legacy/backNav.js";
import { fontStack, fontsForScript, SCRIPTS, scriptById, DEFAULT_SCRIPT, flowLayout, ALIGNS, GAPS } from "../../../legacy/quranFonts.js";
import { switchScript, AR_SIZE, TR_SIZE, wbwSupported } from "../../../legacy/quranCore.js";
import { THEMES } from "../../../legacy/readerCore.js";
import { ensureFont } from "../../../legacy/quranFontLoader.js";
import { loadTafsir } from "../../../legacy/quranData.js";
import { findTafsir, tafsirBlocks, tafsirRangeNote, TAFSIR_NAME } from "../../../legacy/quranTafsir.js";
import { PARA_NAMES, showBismillahHeader, toBnDigits, ayahShareText, locateAyah, markKey, MARKS_MAX, rukuOf } from "../../../legacy/quranCore.js";

const { useState, useEffect, useRef, useCallback } = React;
const h = React.createElement;

export const PRIMARY = "var(--theme-primary, #0E4B43)";
export const TRANSLATOR = "মুহিউদ্দীন খান";
export const LINE = "rgba(128,128,128,0.28)";

export async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch (e) {
    try {
      const ta = document.createElement("textarea");
      ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
      document.body.appendChild(ta); ta.select();
      const ok = document.execCommand("copy");
      document.body.removeChild(ta);
      return ok;
    } catch (e2) { return false; }
  }
}

// বুকমার্ক ও পছন্দের আইকন: সংরক্ষিত থাকলে ভরাট।
export const BookmarkSvg = ({ on, size = 17 }) => h(Icon, { size }, h("path", { d: "M6 3h12v18l-6-4-6 4z", fill: on ? "currentColor" : "none" }));
export const HeartSvg = ({ on, size = 17 }) => h(Icon, { size }, h("path", { d: "M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1 1.1L12 21l7.8-7.5 1-1.1a5.5 5.5 0 0 0 0-7.8z", fill: on ? "currentColor" : "none" }));

export const actBtn = (color) => ({ display: "inline-flex", alignItems: "center", gap: 6, minHeight: 40, padding: "0 12px", borderRadius: 10, fontSize: 13, color, background: "transparent", border: "none", cursor: "pointer" });

export const MoreSvg = () => h(Icon, { size: 20 }, [5, 12, 19].map((cx) => h("circle", { key: cx, cx, cy: 12, r: 1.7, fill: "currentColor" })));
const iconBtn = (color, on) => ({ display: "inline-flex", alignItems: "center", justifyContent: "center", minWidth: 44, minHeight: 44, borderRadius: 12, color, background: on ? "rgba(128,128,128,0.16)" : "transparent", border: "none", cursor: "pointer" });

// আয়াতের নিচের আইকন-সারি: শেয়ার, বুকমার্ক, ⋯ (খুললে কপি ও পছন্দ)। লেখা নেই; অবস্থা aria-label-এ।
export function AyahActions({ a, surah, th, trSize, accent, flash, bm, fav, onCopy, onShare, onMark }) {
  const [more, setMore] = useState(false);
  const [showTafsir, setShowTafsir] = useState(false);
  const n = toBnDigits(a.n);
  return h("div", null, h("div", { style: { display: "flex", flexWrap: "wrap", alignItems: "center", gap: 2, marginTop: 4, marginLeft: -10 } },
    h("button", { type: "button", onClick: () => onShare(a), style: iconBtn(accent), "aria-label": "আয়াত " + n + " শেয়ার করুন" }, h(ShareIcon, { size: 20 })),
    h("button", { type: "button", onClick: () => onMark(a, "b"), style: iconBtn(accent, bm), "aria-pressed": bm, "aria-label": "আয়াত " + n + (bm ? " বুকমার্ক থেকে সরান" : " বুকমার্ক করুন") }, h(BookmarkSvg, { on: bm, size: 20 })),
    surah && h("button", { type: "button", onClick: () => setShowTafsir((v) => !v), style: { ...actBtn(accent), fontWeight: showTafsir ? 700 : 400 }, "aria-expanded": showTafsir, "aria-label": "আয়াত " + n + (showTafsir ? " তাফসির লুকান" : " তাফসির দেখুন") }, showTafsir ? "তাফসির ▲" : "তাফসির"),
    h("button", { type: "button", onClick: () => setMore((v) => !v), style: iconBtn(accent, more), "aria-expanded": more, "aria-label": "আরও" }, h(MoreSvg)),
    more && h("button", { type: "button", onClick: () => onCopy(a), style: iconBtn(accent), "aria-label": "আয়াত " + n + " কপি করুন" }, h(CopyIcon, { size: 20 })),
    more && h("button", { type: "button", onClick: () => onMark(a, "f"), style: iconBtn(accent, fav), "aria-pressed": fav, "aria-label": "আয়াত " + n + (fav ? " পছন্দ থেকে সরান" : " পছন্দের তালিকায় রাখুন") }, h(HeartSvg, { on: fav, size: 20 })),
    (flash === "copy" || flash === "fail") && h("span", { style: { fontSize: 12, color: accent, marginLeft: 6 } }, flash === "copy" ? "কপি হয়েছে ✓" : "কপি করা যায়নি")
  ), surah && showTafsir && h(TafsirBody, { surah, ayah: a, th, accent, trSize }));
}

export function Stepper({ label, value, lim, th, onChange }) {
  const btn = (txt, delta, dis) => h("button", {
    type: "button", disabled: dis, onClick: () => onChange(value + delta),
    style: { width: 44, height: 44, borderRadius: 12, border: "1px solid " + LINE, background: "transparent", color: th.fg, fontSize: 20, opacity: dis ? 0.35 : 1 },
    "aria-label": label + (delta > 0 ? " বাড়ান" : " কমান"),
  }, txt);
  return h("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "8px 0" } },
    h("span", { style: { fontSize: 14 } }, label),
    h("span", { style: { display: "flex", alignItems: "center", gap: 10 } },
      btn("−", -lim.step, value <= lim.min),
      h("span", { style: { minWidth: 28, textAlign: "center", fontWeight: 600 } }, toBnDigits(value)),
      btn("+", lim.step, value >= lim.max))
  );
}

// ───── আরবি ফন্ট-বাছাই (লাইভ প্রিভিউসহ) ─────
// বাছলেই পাঠ-পর্দায় বদলে যায়; ফন্ট নামার সময় আমিরি দেখায়, না নামলে জানায় ও আমিরিতেই চলে।
export function useEnsureFont(fontId) {
  useEffect(() => { ensureFont(fontId); }, [fontId]);
}

// ───── আরবি লেখার ধরন (Simple / উসমানি) ─────
// বদলালে পাঠ-পর্দা নতুন লেখা নামায়; ফন্ট বেমানান হলে ওই ধরনের ডিফল্ট ফন্ট বসে। বুকমার্ক/শেষ পাঠ সূরা:আয়াত ধরে, তাই অক্ষত।
export function ScriptPicker({ prefs, th, accent, onPrefs }) {
  return h("div", null,
    h("div", { style: { fontSize: 14, marginBottom: 8 } }, "আরবি লেখার ধরন"),
    h("div", { role: "radiogroup", "aria-label": "আরবি লেখার ধরন", style: { display: "flex", flexDirection: "column", gap: 6 } },
      SCRIPTS.map((sc) => {
        const on = prefs.arScript === sc.id;
        return h("button", {
          key: sc.id, type: "button", role: "radio", "aria-checked": on, onClick: () => { if (!on) onPrefs(switchScript(prefs, sc.id)); },
          style: { display: "flex", alignItems: "center", justifyContent: "space-between", minHeight: 44, padding: "6px 12px", borderRadius: 12, textAlign: "left", color: th.fg, background: "transparent", border: on ? "2px solid " + accent : "1px solid " + LINE },
        },
          h("span", null, h("span", { style: { display: "block", fontSize: 14, fontWeight: 600 } }, sc.name), h("span", { style: { display: "block", fontSize: 11, opacity: 0.6 } }, sc.note)),
          h("span", { style: { fontSize: 12, color: accent } }, on ? "বাছা ✓" : ""));
      })));
}

// রিডিং/মুসহাফের লাইন-সাজানো: এলাইন ও লাইন-ফাঁক (তালিকা-মোডে প্রযোজ্য নয়)।
export function LayoutPicker({ prefs, th, accent, onPrefs }) {
  const row = (title, key, list) => h("div", { style: { marginBottom: 8 } },
    h("div", { style: { fontSize: 13, opacity: 0.8, marginBottom: 6 } }, title),
    h("div", { role: "radiogroup", "aria-label": title, style: { display: "flex", gap: 6 } },
      list.map(([id, label]) => {
        const on = prefs[key] === id;
        return h("button", {
          key: id, type: "button", role: "radio", "aria-checked": on, onClick: () => !on && onPrefs({ ...prefs, [key]: id }),
          style: { flex: 1, minHeight: 44, borderRadius: 12, fontSize: 13, fontWeight: 600, color: on ? accent : th.fg, background: on ? th.bar : "transparent", border: on ? "2px solid " + accent : "1px solid " + LINE },
        }, label);
      })));
  return h("div", null,
    h("div", { style: { fontSize: 14, marginBottom: 8 } }, "রিডিং ও মুসহাফের লাইন-সাজানো"),
    row("এলাইন", "arAlign", ALIGNS),
    row("লাইনের ফাঁক", "arGap", GAPS));
}

export function FontPicker({ prefs, th, accent, script, onPrefs }) {
  const [st, setSt] = useState({ id: "", status: "" }); // status: loading | fail
  const alive = useRef(true);
  useEffect(() => () => { alive.current = false; }, []);
  const pick = (id) => {
    if (id === prefs.arFont) return;
    onPrefs({ ...prefs, arFont: id });
    setSt({ id, status: "loading" });
    ensureFont(id).then((ok) => { if (alive.current) setSt({ id, status: ok ? "" : "fail" }); });
  };
  const sc = scriptById(script) || scriptById(DEFAULT_SCRIPT);
  const list = fontsForScript(sc.id);
  return h("div", null,
    h("div", { style: { fontSize: 14, marginBottom: 8 } }, "আরবি ফন্ট"),
    h("div", { dir: "rtl", lang: "ar", "aria-label": "ফন্টের প্রিভিউ", style: { fontFamily: fontStack(prefs.arFont), fontSize: Math.min(prefs.arSize, 34), lineHeight: 2.1, textAlign: "center", padding: "6px 8px", borderRadius: 12, background: th.bar, color: th.fg } }, sc.sample),
    h("div", { role: "radiogroup", "aria-label": "আরবি ফন্ট", style: { display: "flex", flexDirection: "column", gap: 6, marginTop: 8 } },
      list.map((f) => {
        const on = prefs.arFont === f.id;
        return h("button", {
          key: f.id, type: "button", role: "radio", "aria-checked": on, onClick: () => pick(f.id),
          style: { display: "flex", alignItems: "center", justifyContent: "space-between", minHeight: 44, padding: "0 12px", borderRadius: 12, textAlign: "left", color: th.fg, background: "transparent", border: on ? "2px solid " + accent : "1px solid " + LINE },
        },
          h("span", null, h("span", { style: { fontSize: 14, fontWeight: 600 } }, f.name), h("span", { style: { fontSize: 11, opacity: 0.6, marginLeft: 8 } }, f.family)),
          h("span", { style: { fontSize: 12, color: accent } }, on ? (st.id === f.id && st.status === "loading" ? "নামছে…" : "বাছা ✓") : ""));
      })),
    st.status === "fail" && h("div", { style: { color: "#D64545", fontSize: 12, marginTop: 6 } }, "ফন্টটা নামানো যায়নি (ইন্টারনেট দেখুন)। আপাতত আমিরি কুরআনে দেখানো হচ্ছে।")
  );
}

// ───── পাঠ-সেটিংস (রিডার ও কুরআন-হোম একই অংশ ব্যবহার করে; পছন্দ একটাই, সব সূরায় প্রযোজ্য) ─────
export function readerTheme(prefs) {
  return { th: THEMES[prefs.theme] || THEMES[0], accent: prefs.theme === 2 ? "#9FD4C4" : PRIMARY };
}

const rule = (margin) => h("div", { style: { borderTop: "1px solid " + LINE, margin } });

function ThemePicker({ prefs, accent, onPrefs }) {
  return h("div", { style: { display: "flex", gap: 8 } },
    ["সাদা", "সেপিয়া", "ডার্ক"].map((label, idx) => {
      const t = THEMES[idx];
      const on = prefs.theme === idx;
      return h("button", {
        key: idx, type: "button", onClick: () => onPrefs({ ...prefs, theme: idx }), "aria-pressed": on,
        style: { flex: 1, minHeight: 44, borderRadius: 12, background: t.bg, color: t.fg, fontSize: 13, fontWeight: 600, border: on ? "2px solid " + accent : "1px solid " + LINE },
      }, label);
    }));
}

function ModePicker({ prefs, th, accent, onPrefs }) {
  return h("div", { style: { display: "flex", gap: 8 } },
    [["list", "তালিকা (অনুবাদসহ)"], ["read", "রিডিং (শুধু আরবি)"]].map(([id, label]) => {
      const on = prefs.mode === id;
      return h("button", {
        key: id, type: "button", onClick: () => !on && onPrefs({ ...prefs, mode: id }), "aria-pressed": on,
        style: { flex: 1, minHeight: 44, borderRadius: 12, fontSize: 13, fontWeight: 600, color: on ? accent : th.fg, background: on ? th.bar : "transparent", border: on ? "2px solid " + accent : "1px solid " + LINE },
      }, label);
    }));
}

// switches: আরবি/অনুবাদ সুইচ দেখাবে কি; showMode: "তালিকা/রিডিং" বাছাই দেখাবে কি।
export function ReaderPrefsBody({ prefs, th, accent, onPrefs, switches, showMode }) {
  const toggle = (key, other, label) => {
    const lastOne = prefs[key] && !prefs[other]; // একমাত্র চালু সুইচটা বন্ধ করা যাবে না
    return h("label", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 0", fontSize: 14, opacity: lastOne ? 0.6 : 1 } },
      label,
      h("input", { type: "checkbox", checked: prefs[key], disabled: lastOne, onChange: (e) => onPrefs({ ...prefs, [key]: e.target.checked }), style: { width: 22, height: 22, accentColor: "#2F9E44" } })
    );
  };
  return h(React.Fragment, null,
    h(Stepper, { label: "আরবি লেখার আকার", value: prefs.arSize, lim: AR_SIZE, th, onChange: (v) => onPrefs({ ...prefs, arSize: v }) }),
    h(Stepper, { label: "অনুবাদের আকার", value: prefs.trSize, lim: TR_SIZE, th, onChange: (v) => onPrefs({ ...prefs, trSize: v }) }),
    showMode && rule("6px 0 10px"),
    showMode && h("div", { style: { fontSize: 14, marginBottom: 8 } }, "পড়ার ধরন"),
    showMode && h(ModePicker, { prefs, th, accent, onPrefs }),
    switches && rule("6px 0 0"),
    switches && toggle("showAr", "showTr", "আরবি দেখান"),
    switches && toggle("showTr", "showAr", "বাংলা অনুবাদ দেখান"),
    switches && h("label", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 0 2px", fontSize: 14, opacity: wbwSupported(prefs.arScript) ? 1 : 0.6 } },
      "শব্দে শব্দে অর্থ (ইংরেজি)",
      h("input", { type: "checkbox", checked: !!prefs.wbw && wbwSupported(prefs.arScript), disabled: !wbwSupported(prefs.arScript), onChange: (e) => onPrefs({ ...prefs, wbw: e.target.checked }), style: { width: 22, height: 22, accentColor: "#2F9E44" } })
    ),
    switches && h("p", { style: { fontSize: 11, opacity: 0.6, lineHeight: 1.6, margin: "0 0 4px" } }, wbwSupported(prefs.arScript) ? "শুধু তালিকা-মোডে দেখায়। কিছু আয়াতে শব্দ মেলে না, সেগুলো সাধারণভাবে দেখায়।" : "এটা উসমানি বা ইন্দো-পাক লেখায় চালু করা যায়।"),
    switches && h("label", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 0 2px", fontSize: 14 } },
      "তাফসির দেখান (ইবনে কাসীর)",
      h("input", { type: "checkbox", checked: prefs.tafsir !== false, onChange: (e) => onPrefs({ ...prefs, tafsir: e.target.checked }), style: { width: 22, height: 22, accentColor: "#2F9E44" } })
    ),
    switches && h("p", { style: { fontSize: 11, opacity: 0.6, lineHeight: 1.6, margin: "0 0 4px" } }, "চালু থাকলে প্রতি আয়াতে \"তাফসির\" বোতাম আসে। প্রথমবার খুললে ওই সূরার তাফসির নামে।"),
    rule("6px 0 10px"),
    h("div", { style: { fontSize: 14, marginBottom: 8 } }, "পাতার রং"),
    h(ThemePicker, { prefs, accent, onPrefs }),
    rule("14px 0 10px"),
    h(LayoutPicker, { prefs, th, accent, onPrefs }),
    rule("10px 0"),
    h(ScriptPicker, { prefs, th, accent, onPrefs }),
    rule("10px 0"),
    h(FontPicker, { prefs, th, accent, script: prefs.arScript, onPrefs })
  );
}

// নিচ থেকে ওঠা শিট। children = শিটের শেষে বাড়তি অংশ (যেমন রিডারে "আয়াতে যান")।
export function SettingsSheet({ title, prefs, th, accent, onPrefs, onClose, switches, showMode, children }) {
  return h("div", { style: { position: "absolute", inset: 0, zIndex: 5, display: "flex", flexDirection: "column", justifyContent: "flex-end", background: "rgba(0,0,0,0.4)" }, onClick: onClose },
    h("div", { onClick: (e) => e.stopPropagation(), style: { background: th.bg, color: th.fg, borderRadius: "18px 18px 0 0", padding: "14px 18px 22px", maxHeight: "85%", overflowY: "auto" } },
      h("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 } },
        h("strong", { style: { fontSize: 16 } }, title),
        h("button", { type: "button", onClick: onClose, style: { minHeight: 40, padding: "0 12px", color: accent, fontWeight: 600 } }, "বন্ধ করুন")
      ),
      h(ReaderPrefsBody, { prefs, th, accent, onPrefs, switches, showMode }),
      children
    )
  );
}

// কুরআন-হোমের সেটিং-আইকন থেকে খোলে। পছন্দ আগেই বদলে রাখা যায়; পরে যেকোনো সূরা/মুসহাফে একই পছন্দে খোলে।
export function QuranSettingsOverlay({ prefs, onPrefs, onClose }) {
  useBackLayer(true, onClose);
  useEnsureFont(prefs.arFont);
  const { th, accent } = readerTheme(prefs);
  return h("div", { style: { position: "fixed", inset: 0, zIndex: 80, fontFamily: "'Hind Siliguri', sans-serif" } },
    h(SettingsSheet, { title: "কুরআন-সেটিংস", prefs, th, accent, onPrefs, onClose, switches: true, showMode: true },
      h("p", { style: { fontSize: 11, opacity: 0.6, marginTop: 14, lineHeight: 1.6 } }, "এই পছন্দ সব সূরা ও মুসহাফে একই থাকবে।"))
  );
}

// ───── অলংকরণ: গোল নম্বর-চিহ্ন (আয়াত/সূরা/পৃষ্ঠা) ও সূরার ব্যানার ─────
// size/font px বা em (CSS-এর মান)। ring = রেখা-বর্ডার; bg = ভেতরের রং।
export function Rosette({ n, size, font, color, bg, margin, ring }) {
  const long = String(n).length >= 3;
  return h("span", { dir: "ltr", style: { display: "inline-flex", alignItems: "center", justifyContent: "center", flexShrink: 0, boxSizing: "border-box", width: size, height: size, margin, borderRadius: 999, border: ring ? "1.5px solid " + color : "none", background: bg, color, fontFamily: "'Hind Siliguri', sans-serif", fontSize: long ? "calc(" + font + " * 0.82)" : font, fontWeight: 600, lineHeight: 1, verticalAlign: "middle" } }, n);
}

export function SurahBanner({ s, font, th, accent, extra }) {
  return h("div", { style: { border: "4px double " + accent, borderRadius: 14, padding: "6px 12px", background: "linear-gradient(180deg, " + th.bar + ", " + th.bg + ")", color: accent, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10 } },
    h("div", { style: { minWidth: 0, display: "flex", alignItems: "center", gap: 8 } },
      h(Rosette, { n: toBnDigits(s.n), size: 34, font: "12px", color: accent, bg: th.bg, ring: true }),
      h("div", { style: { minWidth: 0 } },
        h("div", { style: { fontSize: 14, fontWeight: 600 } }, s.bn),
        extra && h("div", { style: { fontSize: 11.5, opacity: 0.85 } }, extra))),
    h("span", { dir: "rtl", lang: "ar", style: { fontFamily: fontStack(font), fontSize: 26, lineHeight: 1.7, flexShrink: 0 } }, "سورة " + s.ar));
}

// ───── অবিচ্ছিন্ন আরবি লেখা ─────
// items: [{s, n, ar}] (ক্রমানুসারে, একাধিক সূরা থাকতে পারে)।
// headers: সূরার শিরোনাম + বিসমিল্লাহ বসবে কি (মুসহাফে হ্যাঁ; রিডারে নিজের শিরোনাম আছে, তাই না)।
// dividers: পৃষ্ঠা/পারার শুরুতে ডিভাইডার (রিডিং মোডে)।
// withIds: স্ক্রলে যাওয়া ও অবস্থান-ট্র্যাকিংয়ের জন্য id/data-a (শুধু একসূরার রিডারে)।
export function AyahFlow({ items, meta, markers, th, accent, arSize, font, script, align, gap, activeKey, onTap, headers, dividers, withIds }) {
  const blocks = [];
  let run = [];
  const lay = flowLayout(script, align, gap);
  const flush = (k) => {
    if (!run.length) return;
    blocks.push(h("div", { key: "p" + k, dir: "rtl", lang: "ar", style: { fontFamily: fontStack(font), fontSize: Math.round(arSize * lay.sizeScale), lineHeight: lay.lineHeight, textAlign: lay.textAlign, textAlignLast: lay.textAlignLast, color: th.fg, margin: "4px 0" } }, run));
    run = [];
  };
  items.forEach((it, i) => {
    const key = it.s + ":" + it.n;
    const pageNo = markers.page.get(key) || (i === 0 && dividers ? locateAyah(meta, it.s, it.n).page : 0);
    const juzNo = markers.juz.get(key) || 0;
    if (dividers && (pageNo || juzNo)) {
      flush(key);
      blocks.push(h("div", { key: "d" + key, style: { margin: "14px 0 8px", padding: "4px 10px", textAlign: "center", background: th.bar, color: accent, fontSize: 12, fontWeight: 600, borderRadius: 8 } },
        (pageNo ? "পৃষ্ঠা " + toBnDigits(pageNo) : "") + (pageNo && juzNo ? " · " : "") + (juzNo ? "পারা " + toBnDigits(juzNo) + " · " + PARA_NAMES[juzNo - 1] : "") + (rukuOf(meta, it.s, it.n) ? " · রুকু " + toBnDigits(rukuOf(meta, it.s, it.n)) : "")));
    }
    if (headers && it.n === 1) {
      flush(key);
      const sm = meta.surahs[it.s - 1];
      blocks.push(h("div", { key: "h" + key, style: { textAlign: "center", margin: "14px 0 6px" } },
        h(SurahBanner, { s: sm, font, th, accent }),
        showBismillahHeader(it.s) && meta.bismillah && h("div", { dir: "rtl", lang: "ar", style: { fontFamily: fontStack(font), fontSize: arSize, lineHeight: 2.2, color: th.fg, padding: "6px 0 0" } }, (scriptById(script) || scriptById(DEFAULT_SCRIPT)).bismillah)));
    }
    const active = activeKey === key;
    run.push(h("span", {
      key, ...(withIds ? { id: "q-a-" + it.n, "data-a": it.n } : {}),
      onClick: () => onTap(it),
      style: { background: active ? th.bar : "transparent", borderRadius: 8, cursor: "pointer", boxShadow: active ? "0 0 0 3px " + th.bar : "none" },
    },
      it.ar,
      markers.sajda.has(key) ? " ۩" : "",
      " ",
      h(Rosette, { n: toBnDigits(it.n), size: toBnDigits(it.n).length >= 3 ? "2.1em" : "1.7em", font: "0.5em", color: accent, bg: th.bar, margin: "0 0.35em", ring: true }),
      " "));
  });
  flush("end");
  return h("div", null, blocks);
}

// ───── আয়াতে ট্যাপ করলে নিচের শিট: অনুবাদ, কপি, শেয়ার, বুকমার্ক, পছন্দ ─────
// তাফসির-অংশ: সূরার ফাইল প্রথমবার চাইলে নামে; ব্যর্থ হলে "আবার চেষ্টা"।
function TafsirBody({ surah, ayah, th, accent, trSize }) {
  const [st, setSt] = useState({ s: "load" });
  const [tick, setTick] = useState(0);
  useEffect(() => {
    let live = true;
    setSt({ s: "load" });
    loadTafsir(surah).then((p) => { if (live) setSt({ s: "ok", item: findTafsir(p, ayah.n) }); }).catch(() => { if (live) setSt({ s: "err" }); });
    return () => { live = false; };
  }, [surah.n, ayah.n, tick]);
  const box = { borderTop: "1px solid " + LINE, marginTop: 8, paddingTop: 10 };
  if (st.s === "load") return h("div", { style: { ...box, fontSize: 13, opacity: 0.75 }, role: "status" }, "তাফসির আনা হচ্ছে…");
  if (st.s === "err" || !st.item) {
    return h("div", { style: { ...box, fontSize: 13 }, role: "alert" },
      "তাফসির আনা যায়নি। ইন্টারনেট দেখে আবার চেষ্টা করুন।",
      h("button", { type: "button", onClick: () => setTick((t) => t + 1), style: actBtn(accent) }, "আবার চেষ্টা"));
  }
  const note = tafsirRangeNote(st.item, toBnDigits);
  const blocks = tafsirBlocks(st.item.html);
  return h("div", { style: box },
    h("div", { style: { fontSize: 12, opacity: 0.7, marginBottom: 6 } }, TAFSIR_NAME + (note ? " · " + note : "")),
    blocks.map((segs, i) => h("p", { key: i, style: { fontSize: trSize, lineHeight: 1.95, margin: "0 0 10px" } },
      segs.map((x, j) => (x.b ? h("strong", { key: j }, x.t) : x.t)))));
}

export function AyahSheet({ surah, ayah, th, accent, trSize, tafsir = true, flash, bm, fav, onCopy, onShare, onMark, onClose }) {
  useBackLayer(true, onClose);
  const [showTafsir, setShowTafsir] = useState(false);
  const n = toBnDigits(ayah.n);
  return h("div", { style: { position: "absolute", inset: 0, zIndex: 6, display: "flex", flexDirection: "column", justifyContent: "flex-end", background: "rgba(0,0,0,0.4)" }, onClick: onClose },
    h("div", { onClick: (e) => e.stopPropagation(), style: { background: th.bg, color: th.fg, borderRadius: "18px 18px 0 0", padding: "14px 18px 20px", maxHeight: "80%", overflowY: "auto" } },
      h("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 } },
        h("strong", { style: { fontSize: 15 } }, "সূরা " + surah.bn + " " + toBnDigits(surah.n) + ":" + n),
        h("button", { type: "button", onClick: onClose, style: { minHeight: 40, padding: "0 12px", color: accent, fontWeight: 600 } }, "বন্ধ করুন")
      ),
      h("p", { style: { fontSize: trSize, lineHeight: 1.8, opacity: 0.92, margin: "4px 0 8px" } }, ayah.tr),
      h("div", { style: { fontSize: 11, opacity: 0.6, marginBottom: 6 } }, "অনুবাদ: " + TRANSLATOR),
      h("div", { style: { display: "flex", flexWrap: "wrap", gap: 4, borderTop: "1px solid " + LINE, paddingTop: 6 } },
        tafsir && h("button", { type: "button", onClick: () => setShowTafsir((v) => !v), style: { ...actBtn(accent), fontWeight: showTafsir ? 700 : 400 }, "aria-expanded": showTafsir, "aria-label": "আয়াত " + n + (showTafsir ? " তাফসির লুকান" : " তাফসির দেখুন") }, showTafsir ? "তাফসির ▲" : "তাফসির"),
        h("button", { type: "button", onClick: () => onCopy(ayah), style: actBtn(accent), "aria-label": "আয়াত " + n + " কপি করুন" },
          h(CopyIcon, { size: 17 }), flash === "copy" ? "কপি হয়েছে ✓" : flash === "fail" ? "কপি করা যায়নি" : "কপি"),
        h("button", { type: "button", onClick: () => onShare(ayah), style: actBtn(accent), "aria-label": "আয়াত " + n + " শেয়ার করুন" }, h(ShareIcon, { size: 17 }), "শেয়ার"),
        h("button", { type: "button", onClick: () => onMark(ayah, "b"), style: actBtn(accent), "aria-pressed": bm, "aria-label": "আয়াত " + n + (bm ? " বুকমার্ক থেকে সরান" : " বুকমার্ক করুন") }, h(BookmarkSvg, { on: bm }), bm ? "বুকমার্কড" : "বুকমার্ক"),
        h("button", { type: "button", onClick: () => onMark(ayah, "f"), style: actBtn(accent), "aria-pressed": fav, "aria-label": "আয়াত " + n + (fav ? " পছন্দ থেকে সরান" : " পছন্দের তালিকায় রাখুন") }, h(HeartSvg, { on: fav }), "পছন্দ")
      ),
      flash === "full" && h("div", { style: { fontSize: 12, color: "#D64545", marginTop: 2 } }, "সংরক্ষণের সীমা (" + toBnDigits(MARKS_MAX) + "টি) পূর্ণ। আগে কিছু সরান।"),
      tafsir && showTafsir && h(TafsirBody, { surah, ayah, th, accent, trSize })
    )
  );
}

// মুসহাফের জন্য কপি/শেয়ার/মার্ক-হুক। আয়াত = {s, n, ar, tr}; surahs = meta.surahs।
export function useAyahActions(surahs, onMark) {
  const [flash, setFlash] = useState({ key: "", kind: "" });
  const timer = useRef(null);
  const onMarkRef = useRef(onMark);
  onMarkRef.current = onMark;
  useEffect(() => () => clearTimeout(timer.current), []);
  const flashFor = useCallback((key, kind) => {
    setFlash({ key, kind });
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setFlash({ key: "", kind: "" }), 1500);
  }, []);
  const textOf = (a) => ayahShareText(surahs[a.s - 1], a, { showAr: true, showTr: true }, TRANSLATOR);
  const onCopy = useCallback(async (a) => {
    flashFor(a.s + ":" + a.n, (await copyText(textOf(a))) ? "copy" : "fail");
  }, [surahs, flashFor]);
  const onShare = useCallback(async (a) => {
    const text = textOf(a);
    if (navigator.share) {
      try { await navigator.share({ text }); return; } catch (e) {
        if (e && e.name === "AbortError") return;
      }
    }
    flashFor(a.s + ":" + a.n, (await copyText(text)) ? "copy" : "fail");
  }, [surahs, flashFor]);
  const toggle = useCallback((a, kind) => {
    const r = onMarkRef.current(a.s, a.n, kind);
    if (r && r.full) flashFor(a.s + ":" + a.n, "full");
  }, [flashFor]);
  return { flash, onCopy, onShare, toggle };
}

export { markKey };
