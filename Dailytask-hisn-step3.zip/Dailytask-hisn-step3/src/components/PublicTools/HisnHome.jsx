// HisnHome.jsx — "আমল, যিকির ও দু'আ" কার্ডের মূল পেজ (হিসনুল মুসলিম): দ্রুত-যান চিপ, বিশেষ সংকলন সারি,
// বিষয়ভিত্তিক ভাঁজযোগ্য গ্রুপ, অধ্যায় পেজ। ডেটা hisnLoad.js থেকে lazy; গ্রুপ hisnGroups.js (pure)।
// React global(window.React, globals.js)।

import { PageHeader, VerseCard } from "./ToolGrid.jsx";
import { ToolIcon } from "./ToolIcons.jsx";
import { HisnDuaCard } from "./HisnDuaCard.jsx";
import { readPrefs } from "../../legacy/quranState.js";
import { loadHisn } from "../../legacy/hisnLoad.js";
import { WHEN_FILTERS, filterByWhen, toBn } from "../../legacy/hisnCore.js";
import { QUICK_CHIPS, groupChapters, neighbors, groupOf, chapterBySwipe } from "../../legacy/hisnGroups.js";
import { readHisnView, writeHisnView, stepArSize, toggleView } from "../../legacy/hisnPrefs.js";
import { swipeDelta } from "../../legacy/swipeMonth.js";
import { useBackLayer } from "../../legacy/backNav.js";
import { ChevronLeft } from "../icons.jsx";

const { useState, useEffect, useMemo } = React;
const h = React.createElement;
const PRIMARY = "var(--theme-primary, #0E4B43)";
const GOLD = "#C89B3C";
const BN_FONT = "'Noto Serif Bengali', serif";
const OPEN_KEY = "dt_hisn_open_group";
const touch = { x: 0, y: 0, ok: false }; // সোয়াইপের শুরুর বিন্দু (re-render-এর মাঝে হারায় না)

const readOpen = () => { try { return window.sessionStorage.getItem(OPEN_KEY) || ""; } catch (e) { return ""; } };
const writeOpen = (k) => { try { window.sessionStorage.setItem(OPEN_KEY, k); } catch (e) { /* ignore */ } };

// collections = [{key, icon, label}] (বিশেষ সংকলন সারি); onSelectItem(key) = হাবের আইটেম খোলা।
export function HisnHome({ collections, onSelectItem, onBack }) {
  const [state, setState] = useState({ status: "loading", chapters: [], source: "" });
  const [openGroup, setOpenGroup] = useState(readOpen);
  const [chId, setChId] = useState(null);
  const [when, setWhen] = useState("all");
  const prefs = useMemo(() => readPrefs(), []);
  const [view, setViewState] = useState(() => readHisnView(prefs.arSize));
  const setView = (v) => { setViewState(v); writeHisnView(v); };

  useEffect(() => {
    let alive = true;
    loadHisn().then(
      (r) => { if (alive) setState({ status: "ready", chapters: r.chapters, source: r.source }); },
      () => { if (alive) setState({ status: "error", chapters: [], source: "" }); }
    );
    return () => { alive = false; };
  }, []);

  useBackLayer(chId !== null, () => setChId(null));
  useEffect(() => { try { window.scrollTo(0, 0); } catch (e) { /* ignore */ } }, [chId]);

  const groups = useMemo(() => groupChapters(state.chapters), [state.chapters]);
  const toggle = (k) => { const next = openGroup === k ? "" : k; setOpenGroup(next); writeOpen(next); };
  const openChapter = (id) => { setWhen("all"); setChId(id); };

  const ch = chId !== null ? state.chapters.find((c) => c.id === chId) : null;
  if (ch) return chapterView({ ch, groups, prefs, view, setView, when, setWhen, openChapter, close: () => setChId(null), source: state.source });

  const chips = QUICK_CHIPS.filter((c) => state.chapters.some((x) => x.id === c.id));
  return h("div", null,
    onBack && h("button", { type: "button", onClick: onBack, className: "flex items-center gap-1 mb-2 text-sm font-semibold text-emerald-950" }, h(ChevronLeft, { size: 16 }), "সহায়িকা"),
    h(PageHeader, { title: "আমল, যিকির ও দু'আ", subtitle: "দৈনন্দিন জীবনে আল্লাহর স্মরণ" }),

    chips.length > 0 && h("div", { className: "mb-1" },
      h("div", { className: "text-xs font-semibold text-slate-500 pb-1.5" }, "দ্রুত যান"),
      h("div", { className: "flex gap-2 overflow-x-auto pb-2 -mx-4 px-4", "data-no-swipe": true },
        chips.map((c) => h("button", { key: c.id, type: "button", onClick: () => openChapter(c.id), className: "shrink-0 px-3 py-1.5 rounded-full text-[13px] font-semibold border bg-white active:scale-95 transition-transform", style: { color: PRIMARY, borderColor: "var(--theme-line, #D3E3DD)", fontFamily: BN_FONT } }, c.label))
      )
    ),

    collections.length > 0 && h("div", { className: "mb-3" },
      h("div", { className: "text-xs font-semibold text-slate-500 pb-1.5" }, "বিশেষ সংকলন"),
      h("div", { className: "flex gap-2.5 overflow-x-auto pb-2 -mx-4 px-4", "data-no-swipe": true },
        collections.map((c) => h("button", { key: c.key, type: "button", onClick: () => onSelectItem(c.key), className: "shrink-0 w-[84px] flex flex-col items-center gap-1.5 bg-white rounded-2xl border border-slate-200/80 shadow-sm px-1.5 py-2.5 active:scale-95 transition-transform" },
          h("div", { className: "w-10 h-10 rounded-full flex items-center justify-center", style: { background: "var(--theme-soft, #E8F0EE)" } }, h(ToolIcon, { name: c.icon, size: 19, color: PRIMARY })),
          h("span", { className: "text-[11.5px] leading-snug text-center text-slate-700", style: { display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden" } }, c.label)
        ))
      )
    ),

    h("div", { className: "text-xs font-semibold text-slate-500 pb-1.5" }, "বিষয় অনুযায়ী"),
    state.status === "loading" && h("div", { className: "text-sm text-slate-500 py-4" }, "লোড হচ্ছে…"),
    state.status === "error" && h("div", { className: "text-sm text-red-600 py-4" }, "ডেটা লোড করা যায়নি। ইন্টারনেট দেখে আবার চেষ্টা করুন।"),
    groups.map((g) => {
      const open = openGroup === g.key;
      return h("div", { key: g.key, className: "bg-white rounded-2xl border border-slate-200/80 shadow-sm mb-2.5 overflow-hidden" },
        h("button", { type: "button", onClick: () => toggle(g.key), "aria-expanded": open, className: "w-full flex items-center gap-3 px-4 py-3.5 text-left" },
          h("span", { className: "flex-1 text-[15px] font-semibold text-emerald-950", style: { fontFamily: BN_FONT } }, g.title),
          h("span", { className: "text-xs text-slate-500" }, toBn(g.chapters.length) + " অধ্যায়"),
          h("span", { style: { display: "inline-flex", transform: open ? "rotate(90deg)" : "none", transition: "transform .15s" } }, h(ToolIcon, { name: "chevronRight", size: 15, color: GOLD }))
        ),
        open && h("div", { className: "px-3 pb-3 border-t border-slate-100" },
          g.key === "salah" && h("button", { type: "button", onClick: () => onSelectItem("prayerAdhkar"), className: "w-full flex items-center gap-3 py-2.5 px-1 text-left border-b border-slate-100" },
            h("span", { className: "w-8 h-8 rounded-full flex items-center justify-center shrink-0", style: { background: "var(--theme-soft, #E8F0EE)" } }, h(ToolIcon, { name: "dua", size: 16, color: PRIMARY })),
            h("span", { className: "flex-1 text-[14px] font-semibold text-emerald-950", style: { fontFamily: BN_FONT } }, "নামাজের দু'আ (সংক্ষেপে)"),
            h(ToolIcon, { name: "chevronRight", size: 14, color: GOLD })
          ),
          g.chapters.map((c) => h("button", { key: c.id, type: "button", onClick: () => openChapter(c.id), className: "w-full flex items-center gap-3 py-2.5 px-1 text-left border-b border-slate-100 last:border-b-0 active:bg-slate-50" },
            h("span", { className: "w-8 h-8 rounded-full text-white text-[13px] font-semibold flex items-center justify-center shrink-0", style: { background: PRIMARY } }, toBn(c.id)),
            h("span", { className: "flex-1 text-[14px] text-emerald-950", style: { fontFamily: BN_FONT } }, c.title),
            h("span", { className: "text-xs text-slate-500" }, toBn(c.duas.length) + "টি")
          ))
        )
      );
    }),
    state.status === "ready" && h("div", { className: "text-[11px] text-slate-500 pb-3", style: { fontFamily: BN_FONT } }, "উৎস: " + state.source + "। বাংলা উচ্চারণ ও অর্থ আলেম-যাচাই হয়নি; আরবি ডেটাসেট থেকে অপরিবর্তিত।"),
    h(VerseCard, { text: "“আল্লাহর স্মরণেই হৃদয় প্রশান্ত হয়।”", source: "— সূরা আর-রা'দ ১৩:২৮" })
  );
}

function chapterView({ ch, groups, prefs, view, setView, when, setWhen, openChapter, close, source }) {
  const grp = groupOf(groups, ch.id);
  const nb = neighbors(groups, ch.id);
  const isMorningEvening = ch.id === 27;
  const duas = isMorningEvening ? filterByWhen(ch.duas, when) : ch.duas;
  const navBtn = (id, label) => id === null
    ? h("div", { className: "flex-1" })
    : h("button", { type: "button", onClick: () => openChapter(id), className: "flex-1 py-2.5 rounded-xl text-[13px] font-semibold border border-slate-200 bg-white text-slate-700 active:bg-slate-50" }, label);
  const onStart = (e) => {
    const tg = e.target;
    touch.ok = !(tg && tg.closest && tg.closest("[data-no-swipe], input, textarea, select, summary"));
    const p = e.touches && e.touches[0];
    if (p) { touch.x = p.clientX; touch.y = p.clientY; }
  };
  const onEnd = (e) => {
    const p = e.changedTouches && e.changedTouches[0];
    if (!touch.ok || !p) return;
    const to = chapterBySwipe(groups, ch.id, swipeDelta(p.clientX - touch.x, p.clientY - touch.y));
    if (to !== null) openChapter(to);
  };
  const chip = (key, label) => h("button", { key, type: "button", onClick: () => setView(toggleView(view, key)), "aria-pressed": view[key], className: "px-3 py-1 rounded-full text-[12.5px] font-semibold border " + (view[key] ? "text-white border-transparent" : "text-slate-600 border-slate-200 bg-white"), style: view[key] ? { background: PRIMARY } : undefined }, label);
  const sizeBtn = (dir, label) => h("button", { type: "button", onClick: () => setView(stepArSize(view, dir)), "aria-label": dir > 0 ? "আরবি বড় করুন" : "আরবি ছোট করুন", className: "w-9 h-8 rounded-lg border border-slate-200 bg-white text-slate-700 font-semibold active:bg-slate-50", style: { fontSize: dir > 0 ? 16 : 12 } }, label);
  const controls = h("div", { className: "flex items-center gap-1.5 pb-3 flex-wrap", "data-no-swipe": true },
    sizeBtn(-1, "আ"), sizeBtn(1, "আ"),
    h("span", { className: "w-px h-5 bg-slate-200 mx-1" }),
    chip("showAr", "আরবি"), chip("showTr", "উচ্চারণ"), chip("showBn", "অর্থ")
  );
  return h("div", { onTouchStart: onStart, onTouchEnd: onEnd, style: { minHeight: "70vh" } },
    h("button", { type: "button", onClick: close, className: "flex items-center gap-1 mb-2 text-sm font-semibold text-emerald-950" }, h(ChevronLeft, { size: 16 }), grp ? grp.title : "আমল, যিকির ও দু'আ"),
    h("div", { className: "pb-3 text-lg font-semibold", style: { color: PRIMARY, fontFamily: BN_FONT } }, toBn(ch.id) + ". " + ch.title),
    isMorningEvening && h("div", { className: "flex gap-2 pb-3" }, WHEN_FILTERS.map((f) =>
      h("button", { key: f.key, type: "button", onClick: () => setWhen(f.key), className: "flex-1 py-1.5 rounded-xl text-sm font-semibold border " + (when === f.key ? "text-white border-transparent" : "text-slate-600 border-slate-200 bg-white"), style: when === f.key ? { background: PRIMARY } : undefined }, f.label)
    )),
    controls,
    duas.map((d) => h(HisnDuaCard, { key: d.id, d, prefs, view })),
    h("div", { className: "flex gap-2 pt-1 pb-3" }, navBtn(nb.prev, "‹ আগের অধ্যায়"), navBtn(nb.next, "পরের অধ্যায় ›")),
    h("div", { className: "text-[11px] text-slate-400 text-center pb-1" }, "ডানে-বামে সোয়াইপ করেও অধ্যায় বদলানো যায়"),
    h("div", { className: "text-[11px] text-slate-500 pb-2", style: { fontFamily: BN_FONT } }, "উৎস: " + source + "।")
  );
}
