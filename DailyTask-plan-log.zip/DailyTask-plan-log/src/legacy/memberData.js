// memberData.js — Member/Entry/Weekly Firestore data-layer (CRUD, stampLastActive, entry history).
import { dbModular as db, authModular as auth } from "./firebaseConfig.js";
import { collection, doc, getDoc, getDocs, addDoc, setDoc, deleteDoc, writeBatch, Timestamp, query, orderBy, limit, deleteField, updateDoc } from "firebase/firestore";
import { monthPrefix } from "./appHelpers.js";
import { getFamilyCode, getFamilyId, appStorage, resolvePathContext } from "./familyIdentity.js";

function meetingKey(year, month0) {
  return `meeting_rows_v2:${monthPrefix(year, month0)}`;
}

async function saveMeetingData(year, month0, data) {
  await appStorage.set(meetingKey(year, month0), JSON.stringify(data), true);
  // Data Lifecycle Policy: family-level activity stamp. Meeting doc lives in
  // getCollectionName() (v2 schema migration deferred — see roadmap), so this
  // is a separate write, not part of that batch.
  setDoc(doc(db, "families", getFamilyId()), {
    lastActiveAt: Timestamp.now()
  }, { merge: true }).catch(() => {});
}
async function loadWeekly(migrationState, memberId, year, month0) {
  try {
    const ctx = resolvePathContext(migrationState, getFamilyCode(), getFamilyId());
    const docSnap = await getDoc(doc(ctx.weeklyRef, ctx.weeklyDocId(memberId, monthPrefix(year, month0))));
    if (!docSnap.exists()) return {};
    return JSON.parse(docSnap.data().value);
  } catch {
    return {};
  }
}
function stampLastActive(batch, memberRef, familyId, uid) {
  const ts = Timestamp.now();
  if (memberRef) {
    const payload = { lastActiveAt: ts };
    batch.set(memberRef, payload, { merge: true });
  }
  if (familyId) batch.set(doc(db, "families", familyId), { lastActiveAt: ts }, { merge: true });
}
// member:<id> — প্রতিটা সদস্য একটা আলাদা Firestore ডক (সরল top-level ফিল্ড)।
function memberDocId(id) {
  return `member:${id}`;
}

async function loadMembersV2(migrationState) {
  try {
    const ctx = resolvePathContext(migrationState, getFamilyCode(), getFamilyId());
    const snap = await getDocs(ctx.membersRef);
    return snap.docs.map(d => ({
      id: d.id,
      ...d.data()
    }));
  } catch (err) {
    // Access Approval Gate — Step 4: permission-denied আলাদাভাবে চিনতে
    // হবে যাতে caller "সদস্য নেই" আর "access নেই" গুলিয়ে না ফেলে।
    // অন্য সব error (network ইত্যাদি) আগের মতোই [] fallback।
    if (err && err.code === "permission-denied") {
      const tagged = new Error("access-denied");
      tagged.accessDenied = true;
      throw tagged;
    }
    return [];
  }
}
async function deleteMemberDoc(migrationState, id) {
  const ctx = resolvePathContext(migrationState, getFamilyCode(), getFamilyId());
  await deleteDoc(doc(ctx.membersRef, ctx.memberDocId(id)));
}


// Phase-5: v1 (legacy array-doc) ফলব্যাক সরানো হয়েছে; এখন শুধু v2 সদস্য-ডক পড়ে।
async function migrateMembersIfNeeded(migrationState) {
  return loadMembersV2(migrationState);
}
async function loadCustomFields() {
  try {
    const res = await appStorage.get("custom_fields", true);
    return res ? JSON.parse(res.value) : [];
  } catch {
    return [];
  }
}

// §লেবেল ম্যানেজ (ধাপ গ, owner-approved): family-স্তরের ঐচ্ছিক "field_overrides" doc —
// custom_fields-এর হুবহু একই storage-পথ (appStorage shared), তাই নতুন Rules লাগে না।
async function loadFieldOverrides() {
  try {
    const res = await appStorage.get("field_overrides", true);
    return res ? JSON.parse(res.value) : {};
  } catch {
    return {};
  }
}

// §তাযকিরাহ ম্যানেজ (ধাপ খ, owner-approved): family-স্তরের ঐচ্ছিক "tazkirah_custom" doc —
// custom_fields/field_overrides-এর হুবহু একই storage-পথ (appStorage shared), তাই নতুন Rules লাগে না।
async function loadTazkirahCustom() {
  try {
    const res = await appStorage.get("tazkirah_custom", true);
    return res ? JSON.parse(res.value) : null;
  } catch {
    return null;
  }
}

async function loadEntry(migrationState, memberId, key) {
  try {
    const ctx = resolvePathContext(migrationState, getFamilyCode(), getFamilyId());
    const docSnap = await getDoc(doc(ctx.entriesRef, ctx.entryDocId(memberId, key)));
    if (!docSnap.exists()) return null;
    return JSON.parse(docSnap.data().value);
  } catch {
    return null;
  }
}
async function saveEntry(migrationState, memberId, key, data, ownerUid) {
  // ownerUid is stamped from the member's CURRENT ownerUid at save time (not
  // the writer's own uid) so the entry stays consistent with claim state and
  // future Firestore rules can check request.auth.uid == resource.data.ownerUid
  // directly on this same document (no extra get() lookup needed).
  const ctx = resolvePathContext(migrationState, getFamilyCode(), getFamilyId());
  const batch = writeBatch(db);
  batch.set(doc(ctx.entriesRef, ctx.entryDocId(memberId, key)), {
    value: JSON.stringify(data),
    updatedAt: Date.now(),
    ownerUid: ownerUid ?? null,
    // TTL dry-run audit(২৫ আগস্ট ২০২৬) finding fix: এতদিন entry doc-এ
    // lastActiveAt কখনো stamp হতো না (শুধু family+member-এ হতো) — ফলে
    // Firestore TTL policy entry-তে কখনো trigger হতো না। existing
    // Timestamp.now() pattern(দ্রষ্টব্য লাইন ৪০৫৯/৪২২৭) reuse করে এখানে যোগ।
    lastActiveAt: Timestamp.now()
  }, {
    merge: true
  });
  stampLastActive(batch, doc(ctx.membersRef, ctx.memberDocId(memberId)), getFamilyId(), auth.currentUser ? auth.currentUser.uid : null);
  await batch.commit();
}
function entryDocId(memberId, key) {
  return `entry:${memberId}:${key}`;
}

// §Motivational Layer — Phase 1.5(owner-approved, নতুন): bestScoreEver
// denormalized field — dailyInsight.js-এর "সেরা দিন" insight-কে পুরো ইতিহাস
// scan না করে O(1) read-এ "সর্বকালের সেরা" বলতে দেয়। pushEntryHistory()-এর
// একই "best-effort convenience layer" pattern(নিচে দেখুন) — saveEntry()/
// stampLastActive()-এর মূল batch সম্পূর্ণ অপরিবর্তিত, ইচ্ছাকৃতভাবে সম্পূর্ণ
// আলাদা, independent write। ব্যর্থ হলে মূল entry-save-কে প্রভাবিত করে না —
// dailyInsight তখন শুধু "এই মাসে"-স্কোপ fallback-এ ফিরে যাবে (নিচে dailyInsight.js
// দ্রষ্টব্য)। Rules-এ monotonic guard(bestScoreEver কখনো কমতে পারবে না) থাকায়
// দেরি-হওয়া/out-of-order কল থেকেও data-corruption ঝুঁকি নেই।
async function updateBestScoreIfNeeded(migrationState, memberId, todayScorePct) {
  try {
    const ctx = resolvePathContext(migrationState, getFamilyCode(), getFamilyId());
    const memberRef = doc(ctx.membersRef, ctx.memberDocId(memberId));
    const snap = await getDoc(memberRef);
    const current = snap.exists() && typeof snap.data().bestScoreEver === "number" ? snap.data().bestScoreEver : 0;
    if (todayScorePct > current) {
      await setDoc(memberRef, { bestScoreEver: todayScorePct, updatedAt: Date.now() }, { merge: true });
    }
  } catch {
    // Best-effort convenience layer — ব্যর্থ হলে silently ignore(pushEntryHistory()-এর
    // মতোই), মূল entry-save flow-কে কখনো block/fail করাবে না।
  }
}

// §Motivational Layer — Phase 2(owner-approved, নতুন): tomorrowFocus —
// সদস্য নিজে (বা admin, unclaimed proxy member-এর জন্য) পরদিনের Focus বেছে
// নেন/বদলান। saveEntry()-এর batch-এর অংশ না, সরাসরি explicit user-action-এ
// (TomorrowFocusPicker.jsx) ট্রিগার হয় — তাই ব্যর্থ হলে caller নিজেই error
// দেখাবে (entry-save flow-এর সাথে কোনো সম্পর্ক নেই)।
async function saveTomorrowFocus(migrationState, memberId, focus) {
  const ctx = resolvePathContext(migrationState, getFamilyCode(), getFamilyId());
  const memberRef = doc(ctx.membersRef, ctx.memberDocId(memberId));
  await setDoc(memberRef, {
    tomorrowFocus: {
      fieldKey: focus.fieldKey,
      targetDateKey: focus.targetDateKey,
      source: focus.source,
      setAt: Date.now()
    },
    updatedAt: Date.now()
  }, { merge: true });
}

// §কাস্টম টাস্ক (সদস্যভিত্তিক, owner-approved): member-ডকের ঐচ্ছিক customTasks ফিল্ড।
// explicit user-action, saveEntry() batch-এর অংশ না।
async function saveCustomTasks(migrationState, memberId, tasks) {
  const ctx = resolvePathContext(migrationState, getFamilyCode(), getFamilyId());
  const memberRef = doc(ctx.membersRef, ctx.memberDocId(memberId));
  await setDoc(memberRef, {
    customTasks: tasks.map(t => ({ id: t.id, label: t.label, ...(t.src ? { src: t.src } : {}), ...(t.archived ? { archived: true } : {}) })),
    updatedAt: Date.now()
  }, { merge: true });
}

// §কুরআন প্ল্যান (খতম/হিফজ, owner-approved): member-ডকের ঐচ্ছিক quranPlans: { khatam?, hifz? }।
// explicit user-action, saveEntry() batch-এর অংশ না। plan=null মানে ওই মোডের প্ল্যান মোছা। শুধু বদলানো মোড লেখা হয়।
async function saveQuranPlan(migrationState, memberId, mode, plan) {
  if (mode !== "khatam" && mode !== "hifz") throw new Error("bad plan mode");
  const ctx = resolvePathContext(migrationState, getFamilyCode(), getFamilyId());
  const memberRef = doc(ctx.membersRef, ctx.memberDocId(memberId));
  // dotted-path updateDoc: ওই মোডের পুরো প্ল্যান বদলে যায় (merge নয়), তাই দিনের লগ থেকে মোছা দিনও ক্লাউডে মোছে।
  const val = plan ? {
    v: 1, from: { s: plan.from.s, a: plan.from.a }, to: { s: plan.to.s, a: plan.to.a },
    perDay: plan.perDay, done: plan.done, last: plan.last, createdAt: plan.createdAt,
    ...(plan.log && Object.keys(plan.log).length ? { log: plan.log } : {}),
    ...(plan.log && plan.lastDay ? { lastDay: plan.lastDay } : {}),
  } : deleteField();
  await updateDoc(memberRef, { ["quranPlans." + mode]: val, updatedAt: Date.now() });
}

async function pushEntryHistory(migrationState, memberId, key, oldData) {
  try {
    const ctx = resolvePathContext(migrationState, getFamilyCode(), getFamilyId());
    const histRef = collection(doc(ctx.entriesRef, ctx.entryDocId(memberId, key)), "history");
    await addDoc(histRef, {
      value: JSON.stringify(oldData),
      editedAt: Date.now()
    });
    const snap = await getDocs(query(histRef, orderBy("editedAt", "desc")));
    if (snap.size > 5) {
      const excess = snap.docs.slice(5);
      const batch = writeBatch(db);
      excess.forEach(d => batch.delete(d.ref));
      await batch.commit();
    }
  } catch {
    // History is a best-effort convenience layer — a failure here should
    // never block the actual save of the day's entry.
  }
}
async function fetchEntryHistory(migrationState, memberId, key) {
  try {
    const ctx = resolvePathContext(migrationState, getFamilyCode(), getFamilyId());
    const histRef = collection(doc(ctx.entriesRef, ctx.entryDocId(memberId, key)), "history");
    const snap = await getDocs(query(histRef, orderBy("editedAt", "desc"), limit(5)));
    return snap.docs.map(d => ({
      id: d.id,
      editedAt: d.data().editedAt,
      value: d.data().value
    }));
  } catch {
    return [];
  }
}

export {
  meetingKey,
  saveMeetingData,
  loadWeekly,
  stampLastActive,
  memberDocId,
  loadMembersV2,
  deleteMemberDoc,
  migrateMembersIfNeeded,
  loadCustomFields,
  loadFieldOverrides,
  loadTazkirahCustom,
  loadEntry,
  saveEntry,
  entryDocId,
  pushEntryHistory,
  fetchEntryHistory,
  updateBestScoreIfNeeded,
  saveTomorrowFocus,
  saveCustomTasks,
  saveQuranPlan
};
