import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  countsOf, posToIdx, idxToPos, makePlan, sanitizePlan, todayPortion, markDone, undoDone, markDoneN, posAfterN, planMigration, localDateKey, sanitizeLog, todayCount,
  setPerDay, statsOf, perDayForDays, planKey, HIFZ_KEY, KHATAM_KEY, totalOf, makeGoto, readGoto, clampPerDay, GOTO_TTL_MS,
} from "../src/legacy/hifzPlan.js";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const meta = JSON.parse(fs.readFileSync(path.join(root, "public", "quran", "v1", "meta.json"), "utf8"));
const C = countsOf(meta.surahs);

test("posToIdx/idxToPos ঘুরে মেলে; অবৈধ -1/null", () => {
  assert.equal(C.length, 114);
  assert.equal(posToIdx(C, 1, 1), 0);
  assert.equal(posToIdx(C, 2, 1), C[0]);
  assert.deepEqual(idxToPos(C, C[0]), { s: 2, a: 1 });
  const last = C.reduce((x, y) => x + y, 0) - 1;
  assert.deepEqual(idxToPos(C, last), { s: 114, a: C[113] });
  assert.equal(idxToPos(C, last + 1), null);
  assert.equal(posToIdx(C, 2, 0), -1);
  assert.equal(posToIdx(C, 2, C[1] + 1), -1);
  assert.equal(posToIdx(C, 115, 1), -1);
  assert.equal(posToIdx([], 1, 1), -1);
});

test("makePlan: উল্টো/অবৈধ পরিসর null; perDay সীমায়", () => {
  assert.equal(makePlan(C, { s: 2, a: 5 }, { s: 2, a: 4 }, 5, 1), null);
  assert.equal(makePlan(C, { s: 2, a: 5 }, { s: 200, a: 1 }, 5, 1), null);
  assert.equal(makePlan(C, null, { s: 2, a: 4 }, 5, 1), null);
  assert.equal(makePlan(C, { s: 1, a: 1 }, { s: 1, a: 7 }, 0, 1).perDay, 1);
  assert.equal(clampPerDay(99999), 1000);
  assert.equal(clampPerDay("x"), 5);
});

test("আজকের পাঠ সূরা পেরিয়ে যায়, শেষে ছোট হয়, শেষ হলে null", () => {
  // ফাতিহা (৭) + বাকারার প্রথম ৩, দৈনিক ৫
  let p = makePlan(C, { s: 1, a: 1 }, { s: 2, a: 3 }, 5, 1);
  assert.equal(totalOf(p, C), 10);
  assert.deepEqual(todayPortion(p, C), { from: { s: 1, a: 1 }, to: { s: 1, a: 5 }, n: 5 });
  p = markDone(p, C);
  assert.equal(p.done, 5);
  assert.deepEqual(todayPortion(p, C), { from: { s: 1, a: 6 }, to: { s: 2, a: 3 }, n: 5 });
  p = markDone(p, C);
  assert.equal(todayPortion(p, C), null);
  assert.equal(markDone(p, C), p); // শেষে আর বাড়ে না
  assert.equal(statsOf(p, C).finished, true);
});

test("ছোট শেষ-ধাপ: ১০ আয়াত, দৈনিক ৪ → ৪,৪,২", () => {
  let p = makePlan(C, { s: 114, a: 1 }, { s: 114, a: 6 }, 4, 1);
  assert.equal(todayPortion(p, C).n, 4);
  p = markDone(p, C);
  assert.equal(todayPortion(p, C).n, 2);
  p = markDone(p, C);
  assert.equal(p.done, 6);
});

test("undo একবারই; setPerDay অগ্রগতি অক্ষত", () => {
  let p = makePlan(C, { s: 1, a: 1 }, { s: 1, a: 7 }, 3, 1);
  p = markDone(p, C);
  p = undoDone(p);
  assert.equal(p.done, 0);
  assert.equal(undoDone(p).done, 0);
  p = markDone(p, C);
  const q = setPerDay(p, 2);
  assert.equal(q.done, 3);
  assert.equal(q.perDay, 2);
});

test("statsOf", () => {
  let p = makePlan(C, { s: 1, a: 1 }, { s: 1, a: 7 }, 3, 1);
  p = markDone(p, C);
  assert.deepEqual(statsOf(p, C), { total: 7, done: 3, remaining: 4, percent: 42, daysLeft: 2, finished: false });
});

test("sanitizePlan: অবৈধ → null; done সীমায়; last done-এর বেশি নয়", () => {
  assert.equal(sanitizePlan(null, C), null);
  assert.equal(sanitizePlan({ from: { s: 0, a: 1 }, to: { s: 1, a: 1 } }, C), null);
  const p = sanitizePlan({ from: { s: 1, a: 1 }, to: { s: 1, a: 7 }, perDay: 3, done: 99, last: 50 }, C);
  assert.equal(p.done, 7);
  assert.equal(p.last, 7);
  assert.equal(sanitizePlan({ from: { s: 1, a: 1 }, to: { s: 1, a: 7 }, done: -4 }, C).done, 0);
});

test("হ্যান্ডঅফ: তাজা ও বৈধ হলেই; পুরনো/ভবিষ্যৎ/অবৈধ null", () => {
  const g = makeGoto(2, 6, 1000);
  assert.deepEqual(readGoto(g, C, 1000 + 5), { s: 2, a: 6 });
  assert.equal(readGoto(g, C, 1000 + GOTO_TTL_MS + 1), null);
  assert.equal(readGoto(g, C, 900), null);
  assert.equal(readGoto({ s: 2, a: 9999, t: 1000 }, C, 1001), null);
  assert.equal(readGoto(null, C, 1), null);
});

test("খতম: পুরো কুরআন ৩০ দিনে → দৈনিক ২০৮; পরিসর ৬২৩৬ আয়াত", () => {
  const total = C.reduce((x, y) => x + y, 0);
  assert.equal(total, 6236);
  assert.equal(perDayForDays(total, 30), 208);
  assert.equal(perDayForDays(total, 0), 5);
  const p = makePlan(C, { s: 1, a: 1 }, { s: 114, a: C[113] }, 208, 1);
  assert.equal(totalOf(p, C), 6236);
  assert.equal(statsOf(p, C).daysLeft, 30);
  assert.equal(planKey("khatam"), KHATAM_KEY);
  assert.equal(planKey("hifz"), HIFZ_KEY);
  assert.notEqual(KHATAM_KEY, HIFZ_KEY);
});

test("markDoneN: আসল পরিমাণ বসে, পরের পাঠ সেখান থেকেই শুরু", () => {
  const p = makePlan(C, { s: 1, a: 1 }, { s: 114, a: 6 }, 208, 0);
  const q = markDoneN(p, C, 150);
  assert.equal(q.done, 150);
  assert.equal(q.last, 150);
  assert.deepEqual(todayPortion(q, C).from, idxToPos(C, 150));
  assert.equal(markDoneN(q, C, 300).done, 450);
  assert.equal(undoDone(markDoneN(q, C, 300)).done, 150);
});

test("markDoneN: অবৈধ মান অপরিবর্তিত, বাকির বেশি হলে বাকিটুকুই", () => {
  const p = makePlan(C, { s: 113, a: 1 }, { s: 114, a: 6 }, 5, 0); // মোট ১১
  assert.equal(markDoneN(p, C, 0), p);
  assert.equal(markDoneN(p, C, -3), p);
  assert.equal(markDoneN(p, C, "abc"), p);
  const q = markDoneN(p, C, 500);
  assert.equal(q.done, 11);
  assert.equal(statsOf(q, C).finished, true);
  assert.equal(markDoneN(q, C, 1), q);
});

test("posAfterN: n আয়াত পরে শেষ পড়া আয়াত", () => {
  const p = makePlan(C, { s: 1, a: 1 }, { s: 114, a: 6 }, 208, 0);
  assert.deepEqual(posAfterN(p, C, 7), { s: 1, a: 7 });
  assert.deepEqual(posAfterN(p, C, 8), { s: 2, a: 1 });
  assert.equal(posAfterN(p, C, 0), null);
});

test("planMigration: ক্লাউডে বৈধ প্ল্যান থাকলে সেটাই জেতে, আপলোড নেই", () => {
  const remote = { khatam: makePlan(C, { s: 1, a: 1 }, { s: 114, a: 6 }, 100, 5) };
  const local = { khatam: makePlan(C, { s: 1, a: 1 }, { s: 114, a: 6 }, 50, 9), hifz: null };
  const r = planMigration(remote, local, {}, C);
  assert.equal(r.plans.khatam.perDay, 100);
  assert.deepEqual(r.upload, []);
});

test("planMigration: ক্লাউডে নেই + আগে সিংক হয়নি → ফোনের প্ল্যান ওঠে", () => {
  const local = { khatam: makePlan(C, { s: 1, a: 1 }, { s: 114, a: 6 }, 50, 9), hifz: null };
  const r = planMigration({}, local, { khatam: false, hifz: false }, C);
  assert.equal(r.plans.khatam.perDay, 50);
  assert.deepEqual(r.upload, ["khatam"]);
  assert.equal(r.plans.hifz, null);
});

test("planMigration: আগে সিংক হয়েছে + ক্লাউডে নেই → বাসি ফোনের কপি ফেরে না", () => {
  const local = { khatam: makePlan(C, { s: 1, a: 1 }, { s: 114, a: 6 }, 50, 9), hifz: null };
  const r = planMigration({}, local, { khatam: true }, C);
  assert.equal(r.plans.khatam, null);
  assert.deepEqual(r.upload, []);
});

test("planMigration: অবৈধ ক্লাউড-ডেটা/null ইনপুটে crash নয়", () => {
  assert.deepEqual(planMigration(null, null, null, C), { plans: { khatam: null, hifz: null }, upload: [] });
  const r = planMigration({ khatam: { from: 1, to: 2 } }, { khatam: null, hifz: null }, {}, C);
  assert.equal(r.plans.khatam, null);
});

test("দিনের লগ: একই দিনের জমা এক জায়গায়, dayKey ছাড়া লগ-ফিল্ডই নেই", () => {
  const p = makePlan(C, { s: 1, a: 1 }, { s: 114, a: 6 }, 100, 0);
  const a = markDone(p, C, "2026-11-21");
  assert.deepEqual(a.log, { "2026-11-21": 100 });
  assert.equal(a.lastDay, "2026-11-21");
  const b = markDoneN(a, C, 30, "2026-11-21");
  assert.equal(b.log["2026-11-21"], 130);
  assert.equal(todayCount(b, "2026-11-21"), 130);
  assert.equal(todayCount(b, "2026-11-22"), 0);
  const c = markDone(p, C);
  assert.equal("log" in c, false);
  assert.equal("lastDay" in c, false);
  assert.equal(markDoneN(p, C, 5, "bad-date").log, undefined);
});

test("দিনের লগ: শেষ ধাপ বাতিলে ওই দিনের সংখ্যা কমে, শূন্য হলে দিনটাই যায়", () => {
  const p = makePlan(C, { s: 1, a: 1 }, { s: 114, a: 6 }, 100, 0);
  const a = markDoneN(markDone(p, C, "2026-11-20"), C, 30, "2026-11-21");
  const u = undoDone(a);
  assert.equal(u.done, 100);
  assert.deepEqual(u.log, { "2026-11-20": 100 });
  assert.equal("lastDay" in u, false);
  const z = undoDone(markDone(p, C, "2026-11-21"));
  assert.equal("log" in z, false);
  assert.equal(z.done, 0);
});

test("sanitizeLog ও sanitizePlan: অবৈধ কী/মান বাদ, ৪০০ দিনের বেশি ছাঁটা, লগ টিকে থাকে", () => {
  assert.deepEqual(sanitizeLog({ "2026-11-21": 5, "x": 3, "2026-11-22": 0, "2026-11-23": 1.5, "2026-11-24": 9999 }), { "2026-11-21": 5 });
  assert.deepEqual(sanitizeLog(null), {});
  const big = {};
  for (let i = 0; i < 450; i++) big[new Date(Date.UTC(2025, 0, 1 + i)).toISOString().slice(0, 10)] = 1;
  const out = sanitizeLog(big);
  assert.equal(Object.keys(out).length, 400);
  const p = makePlan(C, { s: 1, a: 1 }, { s: 114, a: 6 }, 100, 0);
  const a = markDone(p, C, "2026-11-21");
  assert.deepEqual(sanitizePlan(JSON.parse(JSON.stringify(a)), C), a);
  assert.equal("log" in sanitizePlan(p, C), false);
});

test("localDateKey: স্থানীয় YYYY-MM-DD", () => {
  assert.equal(localDateKey(new Date(2026, 10, 5, 23, 59)), "2026-11-05");
  assert.equal(localDateKey(new Date(2026, 0, 1, 0, 0)), "2026-01-01");
});
